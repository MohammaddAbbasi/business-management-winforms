﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class ActionViewModel
    {
        public string PersonallNumber { get; set; }
        public string Fullname { get; set; }
        public int Mahiyat { get; set; }
        public decimal Mony { get; set; }
        public DateTime Date { get; set; }
        public DateTime dateTimetostring { get; set; }
    }
}
