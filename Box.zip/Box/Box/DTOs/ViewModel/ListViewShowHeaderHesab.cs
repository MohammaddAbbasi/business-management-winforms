﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class ListViewShowHeaderHesab
    {
        public int HeaderId { get; set; }
        public string Title { get; set; }
        public DateTime dateTime { get; set; }
        public decimal Money { get; set; }
        public int Count { get; set; }
        public DateTime dateTimetostring { get; set; }
    }
}
