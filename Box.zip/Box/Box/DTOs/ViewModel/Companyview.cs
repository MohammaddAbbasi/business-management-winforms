﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class Companyview
    {
        public string Titel { get; set; }
        public decimal Mony { get; set; }
    }
}
