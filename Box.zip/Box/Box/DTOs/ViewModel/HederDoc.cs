﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class HederDoc
    {
        public int HeaderId { get; set; }
        public string HeaderName { get; set; }
        public int count { get; set; }
        public decimal variz { get; set; }
        public decimal bardasht { get; set; }
        public DateTime dateTime { get; set; }
        public DateTime dateTimetostring { get; set; }
    }
}
