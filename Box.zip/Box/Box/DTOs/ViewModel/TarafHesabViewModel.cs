﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class TarafHesabViewModel
    {
        public int TarafId { get; set; }
        public string CodeHesab { get; set; }
        public string NameTarafHesab { get; set; }
        public string NumberHesab { get; set; }
        public string NumberSheba { get; set; }
    }
}
