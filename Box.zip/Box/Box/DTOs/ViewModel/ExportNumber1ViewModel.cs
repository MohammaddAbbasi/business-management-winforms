﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class ExportNumber1ViewModel
    {
        public string ShPersonall { get; set; }
        public string Name { get; set; }
        public string Vahed { get; set; }
        public string Semat { get; set; }
        public DateTime dateTime { get; set; }
        public DateTime dateTimetostring { get; set; }
        public string TypeId { get; set; }
        public string Mahiyat { get; set; }
        public decimal Mony { get; set; }
        public int status { get; set; }
        public decimal SumVam { get; set; }
        public decimal SumQest { get; set; }
        public decimal Box { get; set; }
        public decimal SumVariz { get; set; }
        public decimal SumBardasht { get; set; }
    }
}
