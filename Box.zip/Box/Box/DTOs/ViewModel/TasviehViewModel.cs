﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class TasviehViewModel
    {
        public int TasvieId { get; set; }
        public string SematName { get; set; }
        public decimal Money { get; set; }
        public int Mahiyat { get; set; }
        public DateTime dateTime { get; set; }
        public DateTime datetimeToString { get; set; }
        public string DesCription { get; set; }
        public int SematId { get; set; }

    }
}
