﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class ViewModelShowHesabList
    {
        public int HesabId { get; set; }
        public string Fullname { get; set; }
        public string SematName { get; set; }
        public decimal Money { get; set; }
    }
}
