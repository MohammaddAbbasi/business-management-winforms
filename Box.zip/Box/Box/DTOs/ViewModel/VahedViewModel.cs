﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class VahedViewModel
    {
        public int VahedId { get; set; }
        public int CompanyId { get; set; }
        public string VahedTitle { get; set; }
        public string CompanyTitle { get; set; }
    }
}
