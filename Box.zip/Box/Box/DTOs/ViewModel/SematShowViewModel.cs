﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class SematShowViewModel
    {
        public int sematID { get; set; }
        public string SematName { get; set; }
        public string PersonalName { get; set; }
        public string VahedName { get; set; }
        public string Status { get; set; }
    }
}
