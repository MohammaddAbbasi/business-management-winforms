﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class SematViewModel
    {
        public int SematId { get; set; }
        public string SematName { get; set; }
        public int PersonalId { get; set; }
        public int Vahed_Id { get; set; }
        public int Status { get; set; }
    }
}
