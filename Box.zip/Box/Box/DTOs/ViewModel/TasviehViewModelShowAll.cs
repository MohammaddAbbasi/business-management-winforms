﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class TasviehViewModelShowAll
    {
        public int TasvieId { get; set; }
        public string FullName { get; set; }
        public string SematName { get; set; }
        public string Mahiyat { get; set; }
        public decimal Money { get; set; }
        public DateTime dateTime { get; set; }
        public DateTime dateTimetostring { get; set; }
        public string DesCription { get; set; }
        public int SematId { get; set; }
        public decimal SumVariz { get; set; }
        public decimal SumBardasht { get; set; }
    }
}
