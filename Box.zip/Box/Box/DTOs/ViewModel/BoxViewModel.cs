﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class BoxViewModel
    {
        public int HeaderId { get; set; }
        public string Subject { get; set; }
        public DateTime dateTime { get; set; }
        public int TypeHesab { get; set; }
    }
}
