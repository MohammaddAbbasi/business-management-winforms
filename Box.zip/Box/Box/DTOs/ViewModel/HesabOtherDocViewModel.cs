﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class HesabOtherDocViewModel
    {
        public int HeaderId { get; set; }
        public string TitleOfNameHesab { get; set; }
        public string Stats { get; set; }
        public decimal Mony { get; set; }
        public string ShomareHesab { get; set; }
        public string ShomareSheba { get; set; }
    }
}
