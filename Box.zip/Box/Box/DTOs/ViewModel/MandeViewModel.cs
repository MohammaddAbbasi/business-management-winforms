﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class MandeViewModel
    {
        public decimal Mande { get; set; }
    }
}
