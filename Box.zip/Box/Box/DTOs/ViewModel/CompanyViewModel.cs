﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class CompanyViewModel
    {
        //نام هرکدام در جدول دیتابیس زیر مقادیر قید شده
        //CompanyId
        public int Id { get; set; }
        //CompanyName
        public string CompanyName { get; set; }
        //Sh_Eqtesadi
        public string ShomareEqtesadi { get; set; }
        //Shomare_Telofon
        public string ShomareTelefon { get; set; }
        //Address
        public string Addrs { get; set; }
        //Name_Modir
        public string ModirAmel { get; set; }
        //Logo
        public string Pictrue { get; set; }

    }
}
