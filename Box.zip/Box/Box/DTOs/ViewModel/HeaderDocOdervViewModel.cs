﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class HeaderDocOdervViewModel
    {
        public int Headid { get; set; }
        public string title { get; set; }
        public DateTime dateTime { get; set; }
    }
}
