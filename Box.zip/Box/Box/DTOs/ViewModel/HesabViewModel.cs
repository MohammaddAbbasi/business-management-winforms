﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class HesabViewModel
    {
        public int HesabId { get; set; }
        public int HeaderId { get; set; }
        public decimal Money { get; set; }
        public int SematId { get; set; }
    }
}
