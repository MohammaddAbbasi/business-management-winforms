﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class OtherDocBarAsasCompany
    {
        public string CodeHesab { get; set; }
        public string Title { get; set; }
        public string Mahiat { get; set; }
        public decimal Variz { get; set; }
        public decimal Bardasht { get; set; }
        public decimal MandeHesab { get; set; }

    }
}
