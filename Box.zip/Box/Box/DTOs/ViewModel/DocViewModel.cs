﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class DocViewModel
    {
        public int DocId { get; set; }
        public decimal Money { get; set; }
        public int Mahiyat { get; set; }
        public int TarafId { get; set; }
        public string Description { get; set; }
        public int HeadId { get; set; }
    }
}
