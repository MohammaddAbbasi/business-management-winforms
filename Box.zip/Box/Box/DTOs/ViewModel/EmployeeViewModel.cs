﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.ViewModel
{
    internal class EmployeeViewModel
    {
        //نام هرکدام در جدول دیتابیس زیر مقادیر قید شده
        public int Id { get; set; }
        //PersonallId
        public string PersonalNumber { get; set; }
        //Sh_Personeli
        public string FullName { get; set; }
        //Name
        public string CompanyName { get; set; }
        //Semat
        public int VahedId { get; set; }
        //Vahed-Id
        public DateTime Estekhdam_Date { get; set; }
        public DateTime dateTimetostring { get; set; }
        public int IdCompany { get; set; }
        //CompanyId
        public string Usernamee { get; set; }
        //Username
        public string Password { get; set; }
        //Password
    }
}
