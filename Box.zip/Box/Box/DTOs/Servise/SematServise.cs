﻿using Box.DataLayer;
using Box.DTOs.IServise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.Servise
{
    internal class SematServise : ISemat
    {
        DataClassesDataContext db = new DataClassesDataContext();
        public bool AddSemat(SematViewModel sematViewModel)
        {
            if (sematViewModel != null)
            {
                var Semat = new Semat_Tbl();
                Semat.SematName = sematViewModel.SematName;
                Semat.PersonalId = sematViewModel.PersonalId;
                Semat.Vahed_Id = sematViewModel.Vahed_Id;
                Semat.Status = sematViewModel.Status;
                db.Semat_Tbls.InsertOnSubmit(Semat);
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public bool DeleteSemat(int SematId)
        {
            var Semat = GetSemayByID(SematId);
            if (Semat != null)
            {
                db.Semat_Tbls.DeleteOnSubmit(Semat);
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public List<SematShowViewModel> GetAll()
        {
            var Result =
         from s in db.Semat_Tbls
         join v in db.Vahed_Tbls
        on s.Vahed_Id equals v.VahedId
         join p in db.Personal_Tbls
          on s.PersonalId equals p.PersonalId
         select new SematShowViewModel
         {
             PersonalName = p.Name,
             SematName = s.SematName,
             VahedName = v.Vahed_Title,
             Status = s.Status == 1 ? "فعال"
            : s.Status == 2 ? "غیرفعال"
            : "بدون عنوان",
             sematID = s.SematId
         };
            return Result.OrderByDescending(x => x.Status).ToList();
        }
        public List<EmployeeViewModel> GetPersonal()
        {
            var res = db.Personal_Tbls.Select(x => new EmployeeViewModel
            {
                FullName = $"{x.Name}-شماره پرسنلی:{x.Sh_Personal}",
                Id = x.PersonalId,
            });
            return res.ToList();
        }

        public Semat_Tbl GetSemayByID(int SematId)
        {
            return db.Semat_Tbls.FirstOrDefault(x => x.SematId == SematId);
        }

        public List<VahedViewModel> GetVahed()
        {
            var result = db.Vahed_Tbls.Select(x => new VahedViewModel
            {
                VahedTitle = $"نام واحد:{x.Vahed_Title}-شماره شرکت:{x.Company_Id}",
                VahedId = x.VahedId

            });
            return result.ToList();
        }

        public bool UpdateSemat(SematViewModel sematViewModel)
        {
            if (sematViewModel != null)
            {
                var Semat = GetSemayByID(sematViewModel.SematId);
                Semat.Status = sematViewModel.Status;
                Semat.SematName = sematViewModel.SematName;
                Semat.Vahed_Id = sematViewModel.Vahed_Id;
                Semat.PersonalId = sematViewModel.PersonalId;
                Semat.SematId = sematViewModel.SematId;
                db.SubmitChanges();
                return true;
            }
            return false;
        }
    }
}
