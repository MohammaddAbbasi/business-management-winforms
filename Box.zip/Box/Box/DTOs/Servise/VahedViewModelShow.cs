﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.Servise
{
    internal class VahedViewModelShow
    {
        public string VahedName { get; set; }

        public DateTime dateTime { get; set; }

        public string Type { get; set; }

        public string Mahiyat { get; set; }

        public decimal Money { get; set; }
        public DateTime dateTimetostring { get; set; }

    }
}
