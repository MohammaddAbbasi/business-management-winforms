﻿
using Box.DataLayer;
using Box.DTOs.IServise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.Servise
{
    internal class CompanyServise : ICompany
    {
        DataClassesDataContext db = new DataClassesDataContext();
        public bool AddCompany(CompanyViewModel companyViewModel)
        {
            if (companyViewModel != null)
            {
                var Company = new Company_Tbl();
                Company.Title = companyViewModel.CompanyName;
                Company.Address = companyViewModel.Addrs;
                Company.Sh_Eqtesadi = companyViewModel.ShomareEqtesadi;
                Company.Shomare_Telofon = companyViewModel.ShomareTelefon;
                Company.Name_Modir = companyViewModel.ModirAmel;
                Company.Logo = companyViewModel.Pictrue;
                db.Company_Tbls.InsertOnSubmit(Company);
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public bool DeleteCompany(int id)
        {
            var Company = db.Company_Tbls.FirstOrDefault(x => x.CompanyId == id);
            if (Company != null)
            {
                db.Company_Tbls.DeleteOnSubmit(Company);
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public bool EditCompany(CompanyViewModel companyViewModel)
        {
            if (companyViewModel != null)
            {
                var Company = GetCompanyById(companyViewModel.Id);
                Company.Title = companyViewModel.CompanyName;
                Company.Address = companyViewModel.Addrs;
                Company.Shomare_Telofon = companyViewModel.ShomareTelefon;
                Company.Sh_Eqtesadi = companyViewModel.ShomareEqtesadi;
                Company.Name_Modir = companyViewModel.ModirAmel;
                Company.Logo = companyViewModel.Pictrue;
                Company.CompanyId = companyViewModel.Id;
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public List<Company_Tbl> getAll()
        {
            return db.Company_Tbls.ToList();
        }

        public Company_Tbl GetCompanyById(int id)
        {
            return db.Company_Tbls.FirstOrDefault(x => x.CompanyId == id);
        }
    }
}
