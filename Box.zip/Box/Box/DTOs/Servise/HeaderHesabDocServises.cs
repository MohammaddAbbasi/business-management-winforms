﻿using Box.DataLayer;
using Box.DTOs.IServise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.DTOs.Servise
{
    internal class HeaderHesabDocServises : IHeaderHesabDoc
    {
        DataClassesDataContext db = new DataClassesDataContext();
        public bool AddHeaderHesabDoc(HeaderDocOdervViewModel headerDocOdervViewModel)
        {
            if (headerDocOdervViewModel != null)
            {
                var dOC = new HeaderDocOther_Tbl();
                dOC.Title = headerDocOdervViewModel.title;
                dOC.Date = headerDocOdervViewModel.dateTime;
                db.HeaderDocOther_Tbls.InsertOnSubmit(dOC);
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public bool CheckHesab(int HeaderId)
        {
            return db.HeaderHesab_Tbls.Any(c => c.HeaderId == HeaderId);
        }

        public bool DeleteHeaderHesabDoc(int HeaderId)
        {
            if (CheckHesab(HeaderId))
            {
                MessageBox.Show("برای حذف این سربرگ ابتدا حساب‌های داخل آن را حذف کنید");
                return false;
            }

            var header = getHeaderById(HeaderId);

            if (header == null)
                return false;

            db.HeaderDocOther_Tbls.DeleteOnSubmit(header);
            db.SubmitChanges();

            return true;
        }

        public bool EditHeaderHesabDoc(HeaderDocOdervViewModel headerDocOdervViewModel)
        {

            var res = getHeaderById(headerDocOdervViewModel.Headid);
            if (res != null)
            {
                res.HeadId = headerDocOdervViewModel.Headid;
                res.Title = headerDocOdervViewModel.title;
                res.HeadId = headerDocOdervViewModel.Headid;
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public List<HederDoc> GetAll(string name)
        {
            var res = db.HeaderDocOther_Tbls.AsQueryable();
            if (!string.IsNullOrWhiteSpace(name))
                res = res.Where(x => x.Title.Contains(name));
            var result = res.Select(x => new HederDoc
            {
                HeaderId = x.HeadId,
                HeaderName = x.Title,
                dateTime = x.Date,

                count = db.DocOther_Tbls.Count(h => h.HeadId == x.HeadId),

                bardasht = db.DocOther_Tbls
                    .Where(h => h.HeadId == x.HeadId && h.Mahiyat == 2)
                    .Sum(h => (decimal?)h.Money) ?? 0,

                variz = db.DocOther_Tbls
                    .Where(h => h.HeadId == x.HeadId && h.Mahiyat == 1)
                    .Sum(h => (decimal?)h.Money) ?? 0
            });

            return result.ToList();
        }

        public HeaderDocOther_Tbl getHeaderById(int HeaderDoc)
        {
            return db.HeaderDocOther_Tbls.FirstOrDefault(x => x.HeadId == HeaderDoc);
        }
    }
}
