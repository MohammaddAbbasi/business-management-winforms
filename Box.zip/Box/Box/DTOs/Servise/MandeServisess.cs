﻿using Box.DTOs.IServise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using Box.DataLayer;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.Servise
{
    internal class MandeServisess : IMande
    {
        DataClassesDataContext db=new DataClassesDataContext();
        public List<MandeViewModel> GetMande()
        {
            throw new NotImplementedException();
        }
    }
}
