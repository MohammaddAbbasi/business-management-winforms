﻿using Box.DataLayer;
using Box.DTOs.IServise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.Servise
{
    internal class TarafServises : ITarafhesab
    {
        DataClassesDataContext db = new DataClassesDataContext(DBContext.ConectionString);
        public bool AddTarafHesab(TarafHesabViewModel tarafHesabViewModel)
        {
            if (tarafHesabViewModel != null)
            {
                var Taraf = new TarafHesab_Tbl();
                Taraf.NameTarafHesab = tarafHesabViewModel.NameTarafHesab;
                Taraf.CodeHesab = tarafHesabViewModel.CodeHesab;
                Taraf.NumberHesab = tarafHesabViewModel.NumberHesab;
                Taraf.NumberSheba = tarafHesabViewModel.NumberSheba;
                db.TarafHesab_Tbls.InsertOnSubmit(Taraf);
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public bool DeleteTarafHesab(int TarafID)
        {
            var taraf = GetTarafHesabByid(TarafID);
            if (taraf != null)
            {
                db.TarafHesab_Tbls.DeleteOnSubmit(taraf);
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public bool EditTarafHesab(TarafHesabViewModel tarafHesabViewModel)
        {
            var res = GetTarafHesabByid(tarafHesabViewModel.TarafId);
            if (res != null)
            {
                res.TarafId = tarafHesabViewModel.TarafId;
                res.NameTarafHesab = tarafHesabViewModel.NameTarafHesab;
                res.CodeHesab = tarafHesabViewModel.CodeHesab;
                res.NumberHesab = tarafHesabViewModel.NumberHesab;
                res.NumberSheba = tarafHesabViewModel.NumberSheba;
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public List<TarafHesab_Tbl> GetAll()
        {
            return db.TarafHesab_Tbls.ToList();
        }
        public TarafHesab_Tbl GetTarafHesabByid(int TarafID)
        {
            return db.TarafHesab_Tbls.FirstOrDefault(x => x.TarafId == TarafID);
        }
    }
}
