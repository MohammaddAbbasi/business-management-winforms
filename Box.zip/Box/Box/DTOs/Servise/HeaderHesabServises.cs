﻿using Box.DataLayer;
using Box.DTOs.IServise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Box.DTOs.Servise
{
    internal class HeaderHesabServises : IHeaderHesab
    {
        DataClassesDataContext db = new DataClassesDataContext(DBContext.ConectionString);
        public bool AddHesabHeader(BoxViewModel boxViewModel)
        {
            if (boxViewModel != null)
            {
                var headerHesab = new HeaderHesab_Tbl();
                headerHesab.TypeHesab = boxViewModel.TypeHesab;
                headerHesab.Subject = boxViewModel.Subject;
                headerHesab.Date = boxViewModel.dateTime;
                db.HeaderHesab_Tbls.InsertOnSubmit(headerHesab);
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public bool CheckHesab(int HeaderId)
        {
            return db.Hesab_Tbls.Any(c => c.HeaderId == HeaderId);
        }

        public bool EditHesabHeader(BoxViewModel boxViewModel)
        {
            var res = GetHesabById(boxViewModel.HeaderId);
            if (res != null)
            {
                res.HeaderId = boxViewModel.HeaderId;
                res.Subject = boxViewModel.Subject;
                res.TypeHesab = boxViewModel.TypeHesab;
                res.Date = boxViewModel.dateTime;
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public List<ListViewShowHeaderHesab> GetAll(int? typeId = null, string name = null)
        {
            var res = db.HeaderHesab_Tbls.AsQueryable();

            if (typeId != null)
                res = res.Where(x => x.TypeHesab == typeId);

            if (!string.IsNullOrWhiteSpace(name))
                res = res.Where(x => x.Subject.Contains(name));

            var result = res.Select(x => new ListViewShowHeaderHesab
            {
                HeaderId = x.HeaderId,
                Title = x.Subject,
                dateTime = x.Date,
              
                Count = db.Hesab_Tbls.Count(h => h.HeaderId == x.HeaderId),

                Money = db.Hesab_Tbls
                          .Where(h => h.HeaderId == x.HeaderId)
                          .Sum(h => (decimal?)h.Money) ?? 0
            });

            return result.ToList();
        }

        public HeaderHesab_Tbl GetHesabById(int HeaderId)
        {
            return db.HeaderHesab_Tbls.FirstOrDefault(x => x.HeaderId == HeaderId);
        }

        public bool RemoveHesabHeader(int HeaderId)
        {
            if (CheckHesab(HeaderId))
            {
                MessageBox.Show("برای حذف این سربرگ ابتدا حساب‌های داخل آن را حذف کنید");
                return false;
            }

            var header = GetHesabById(HeaderId);

            if (header == null)
                return false;

            db.HeaderHesab_Tbls.DeleteOnSubmit(header);
            db.SubmitChanges();

            return true;
        }
    }
}
