﻿using Box.DataLayer;
using Box.DTOs.IServise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.Servise
{

    internal class VahedServise : IVahed
    {
        DataClassesDataContext db = new DataClassesDataContext();
        public bool AddVahed(VahedViewModel vahedViewModel)
        {
            if (vahedViewModel != null)
            {
                var vahed = new Vahed_Tbl();
                vahed.Vahed_Title = vahedViewModel.VahedTitle;
                vahed.Company_Id = vahedViewModel.CompanyId;
                db.Vahed_Tbls.InsertOnSubmit(vahed);
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public bool EditVahed(VahedViewModel vahedViewModel)
        {
            if (vahedViewModel != null)
            {
                var vahed = GetVahedById(vahedViewModel.VahedId);
                vahed.Vahed_Title = vahedViewModel.VahedTitle;
                vahed.Company_Id = vahedViewModel.CompanyId;
                vahed.VahedId = vahedViewModel.VahedId;
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public List<VahedViewModel> GetAll()
        {
            var res = from v in db.Vahed_Tbls
                      join c in db.Company_Tbls
                          on v.Company_Id equals c.CompanyId into sp
                      from c in sp.DefaultIfEmpty()
                      select new VahedViewModel
                      {
                          VahedId = v.VahedId,
                          VahedTitle = v.Vahed_Title,
                          CompanyTitle = c.Title,
                          CompanyId = c.CompanyId


                      };
            return res.ToList();
        }

        public Vahed_Tbl GetVahedById(int VahedId)
        {
            return db.Vahed_Tbls.FirstOrDefault(x => x.VahedId == VahedId);
        }

        public bool RemoveVahed(int vahedid)
        {
            var vahed = GetVahedById(vahedid);
            if (vahed != null)
            {
                db.Vahed_Tbls.DeleteOnSubmit(vahed);
                db.SubmitChanges();
                return true;
            }
            return false;
        }

    }
}
