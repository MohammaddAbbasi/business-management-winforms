﻿using Box.DataLayer;
using Box.DTOs.IServise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.Servise
{
    internal class DocServises : IDoc
    {
        DataClassesDataContext db = new DataClassesDataContext();
        public bool AddDoc(DocViewModel docViewModel)
        {
            if (docViewModel != null)
            {
                var dOC = new DocOther_Tbl();
                dOC.DocId = docViewModel.DocId;
                dOC.TarafId = docViewModel.TarafId;
                dOC.Mahiyat = docViewModel.Mahiyat;
                dOC.Money = docViewModel.Money;
                dOC.Description = docViewModel.Description;
                dOC.HeadId = docViewModel.HeadId;
                db.DocOther_Tbls.InsertOnSubmit(dOC);
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public bool EditDoc(DocViewModel docViewModel)
        {
            var Doc = GetDocById(docViewModel.DocId);
            if (Doc != null)
            {
                Doc.DocId = docViewModel.DocId;
                Doc.TarafId = docViewModel.TarafId;
                Doc.Mahiyat = docViewModel.Mahiyat;
                Doc.Money = docViewModel.Money;
                Doc.HeadId = docViewModel.HeadId;
                Doc.Description = docViewModel.Description;
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public List<HesabOtherDocViewModel> GetAll(int docId, string name)
        {
            var res = from d in db.DocOther_Tbls
                      join
                      t in db.TarafHesab_Tbls
                      on d.TarafId equals t.TarafId
                      into dt
                      from t in dt.DefaultIfEmpty()
                      where d.HeadId == docId
                      select new HesabOtherDocViewModel
                      {
                          HeaderId = d.DocId,
                          Mony = d.Money,
                          ShomareHesab = t.NumberHesab,
                          ShomareSheba = t.NumberSheba,
                          TitleOfNameHesab = t.NameTarafHesab,
                          Stats = d.Mahiyat == 1 ? "واریز"
                          : d.Mahiyat == 2 ? "برداشت"
                          : "بدون عنوان",
                      };
            if (!string.IsNullOrWhiteSpace(name))
            {
                res = res.Where(x => x.TitleOfNameHesab.Contains(name));
            }
            return res.ToList();
        }

        public DocOther_Tbl GetDocById(int DocId)
        {
            var res = db.DocOther_Tbls.FirstOrDefault(X => X.DocId == DocId);
            return res;
        }

        public List<TarafHesabViewModel> GetTrafId()
        {
            var res = db.TarafHesab_Tbls.Select(x => new TarafHesabViewModel
            {
                NameTarafHesab = $"نام طرف حساب:{x.NameTarafHesab} کد حساب:{x.CodeHesab}",
                TarafId = x.TarafId,
            });
            return res.ToList();
        }

        public bool RemoveDoc(int DocId)
        {
            var Doc = GetDocById(DocId);
            if (Doc != null)
            {
                db.DocOther_Tbls.DeleteOnSubmit(Doc);
                db.SubmitChanges();
                return true;
            }
            return false;
        }
    }
}
