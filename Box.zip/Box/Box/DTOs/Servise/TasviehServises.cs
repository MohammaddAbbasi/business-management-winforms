﻿using Box.DataLayer;
using Box.DTOs.IServise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.Servise
{
    internal class TasviehServises : ITasvieh
    {
        DataClassesDataContext db = new DataClassesDataContext();
        public bool AddTasvieh(TasviehViewModel tasviehViewModel)
        {
            if (tasviehViewModel != null)
            {
                var AddTasvieh = new Tasvieh();
                AddTasvieh.Money = tasviehViewModel.Money;
                AddTasvieh.Mahiyat = tasviehViewModel.Mahiyat;
                AddTasvieh.Date = tasviehViewModel.dateTime;
                AddTasvieh.DesCription = tasviehViewModel.DesCription;
                AddTasvieh.SematId = tasviehViewModel.SematId;
                db.Tasviehs.InsertOnSubmit(AddTasvieh);
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public bool DeleteTasvieh(int id)
        {
            var Tasvieh = Get(id);
            if (Tasvieh != null)
            {
                db.Tasviehs.DeleteOnSubmit(Tasvieh);
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public bool EditTasvieh(TasviehViewModel tasviehViewModel)
        {
            if (tasviehViewModel != null)
            {
                var AddTasvieh = Get(tasviehViewModel.TasvieId);
                AddTasvieh.Money = tasviehViewModel.Money;
                AddTasvieh.Mahiyat = tasviehViewModel.Mahiyat;
                AddTasvieh.Date = tasviehViewModel.dateTime;
                AddTasvieh.DesCription = tasviehViewModel.DesCription;
                AddTasvieh.SematId = tasviehViewModel.SematId;
                AddTasvieh.TasvieId = tasviehViewModel.TasvieId;
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public Tasvieh Get(int id)
        {
            return db.Tasviehs.FirstOrDefault(x => x.TasvieId == id);
        }

        public List<TasviehViewModelShowAll> GetAll(int? SematId, DateTime? fromdateTime = null, DateTime? ToDate = null)
        {
            var res = from t in db.Tasviehs
                      join s in db.Semat_Tbls
                          on t.SematId equals s.SematId into sp
                      from s in sp.DefaultIfEmpty()
                      join p in db.Personal_Tbls
          on s.PersonalId equals p.PersonalId into hs
                      from p in hs.DefaultIfEmpty()

                      where !SematId.HasValue || s.SematId == SematId
                      where (!fromdateTime.HasValue || t.Date >= fromdateTime)
                      where (!ToDate.HasValue || t.Date <= ToDate)

                      select new TasviehViewModelShowAll
                      {
                          TasvieId = t.TasvieId,
                          FullName = p.Name,
                          SematName = s.SematName,
                          Mahiyat = t.Mahiyat == 1 ? "واریز"
                          : t.Mahiyat == 2 ? "برداشت" : "بدون عنوان",
                          DesCription = t.DesCription,
                          Money = t.Money,
                          dateTime = t.Date,
                          SumVariz= t != null  && t.Mahiyat == 1 ? t.Money:0m,
                          SumBardasht= t != null && t.Mahiyat == 2 ? t.Money : 0m

                      };
            return res.ToList();
        }

        public List<Tasvieh> GetShowAll()
        {
            return db.Tasviehs.ToList();
        }
    }
}