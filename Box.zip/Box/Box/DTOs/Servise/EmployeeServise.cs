﻿using Box.DataLayer;
using Box.DTOs.IServise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs
{

    internal class EmployeeServise : IEmployee
    {
        DataClassesDataContext db = new DataClassesDataContext(DBContext.ConectionString);
        public bool AddPerson(EmployeeViewModel employeeViewModel)
        {
            if (employeeViewModel != null)
            {
                var Employee = new Personal_Tbl();
                Employee.Sh_Personal = employeeViewModel.PersonalNumber;
                Employee.Name = employeeViewModel.FullName;
                Employee.Estekhdam_Date = employeeViewModel.Estekhdam_Date;
                Employee.CompanyId = employeeViewModel.IdCompany;
                Employee.Username = employeeViewModel.Usernamee;
                Employee.VahedId = employeeViewModel.VahedId;
                Employee.Password = employeeViewModel.Password;
                db.Personal_Tbls.InsertOnSubmit(Employee);
                db.SubmitChanges();
                return true;
            }
            return false;
        }
        public bool DeletePerson(int id)
        {
            var user = GetUserById(id);
            if (user != null)
            {
                db.Personal_Tbls.DeleteOnSubmit(user);
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public bool EditPerson(EmployeeViewModel employeeViewModel)
        {
            if (employeeViewModel != null)
            {
                var user = GetUserById(employeeViewModel.Id);
                user.Name = employeeViewModel.FullName;
                user.CompanyId = employeeViewModel.IdCompany;
                user.Username = employeeViewModel.Usernamee;
                user.Password = employeeViewModel.Password;
                user.Estekhdam_Date = employeeViewModel.Estekhdam_Date;
                user.VahedId = employeeViewModel.VahedId;
                db.SubmitChanges();
                return true;
            }
            return false;
        }

        public List<EmployeeViewModel> GetAll()
        {
            var res = from p in db.Personal_Tbls
                      join c in db.Company_Tbls
                          on p.CompanyId equals c.CompanyId into sp
                      from c in sp.DefaultIfEmpty()
                      select new EmployeeViewModel
                      {
                          Id = p.PersonalId,
                          PersonalNumber = p.Sh_Personal,
                          FullName = p.Name,
                          VahedId = p.VahedId,
                          IdCompany = p.CompanyId,
                          Usernamee = p.Username,
                          Password = p.Password,
                          Estekhdam_Date = p.Estekhdam_Date,
                          CompanyName = c.Title
                      };
            return res.ToList();
        }

        public List<CompanyViewModel> GetcompanyById()
        {
            var res = db.Company_Tbls.Select(x => new CompanyViewModel
            {
                CompanyName = x.Title,
                Id = x.CompanyId
            });
            return res.ToList();
        }

        public Personal_Tbl GetUserById(int id)
        {
            return db.Personal_Tbls.FirstOrDefault(x => x.PersonalId == id);
        }
    }
}
