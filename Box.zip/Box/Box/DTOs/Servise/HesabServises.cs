﻿using Box.DataLayer;
using Box.DTOs.IServise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.Servise
{
    internal class HesabServises : IHesab
    {
        DataClassesDataContext DB = new DataClassesDataContext();
        public bool AddHesab(HesabViewModel hesabViewModel)
        {
            if (hesabViewModel != null)
            {
                var hSAB = new Hesab_Tbl();
                hSAB.HeaderId = hesabViewModel.HeaderId;
                hSAB.SematId = hesabViewModel.SematId;
                hSAB.Money = hesabViewModel.Money;
                DB.Hesab_Tbls.InsertOnSubmit(hSAB);
                DB.SubmitChanges();
                return true;
            }
            return false;

        }

        public bool DeleteHesab(int hesabId)
        {
            var hesab = DB.Hesab_Tbls.FirstOrDefault(x => x.HesabId == hesabId);
            if (hesab != null)
            {
                Console.WriteLine($"HesabId = {hesabId}");
                DB.Hesab_Tbls.DeleteOnSubmit(hesab);
                DB.SubmitChanges();
                return true;
            }
            return false;
        }

        public bool EditHesab(HesabViewModel hesabViewModel)
        {
            if (hesabViewModel != null)
            {
                var hSAB = GetHsab(hesabViewModel.HesabId);
                hSAB.HeaderId = hesabViewModel.HeaderId;
                hSAB.SematId = hesabViewModel.SematId;
                hSAB.Money = hesabViewModel.Money;
                hSAB.HesabId = hesabViewModel.HesabId;
                DB.SubmitChanges();
                return true;
            }
            return false;
        }

        public List<ViewModelShowHesabList> GetAll(int HeaderId,string name = null)
        {
            var res = from h in DB.Hesab_Tbls
                      join s in DB.Semat_Tbls
                      on h.SematId equals s.SematId
                      into hs
                      from s in hs.DefaultIfEmpty()

                      join p in DB.Personal_Tbls
                      on s.PersonalId equals p.PersonalId
                      into sp
                      from p in sp.DefaultIfEmpty()
                      where h.HeaderId == HeaderId
                      select new ViewModelShowHesabList
                      {
                          HesabId = h.HesabId,
                          Fullname = p.Name,
                          Money = h.Money,
                          SematName = s.SematName
                      };

            if (!string.IsNullOrWhiteSpace(name))
            {
                res = res.Where(x => x.Fullname.Contains(name));
            }

            return res.ToList();
        }

        public Hesab_Tbl GetHeaderBySematId(int SematId)
        {
            return DB.Hesab_Tbls.FirstOrDefault(x => x.SematId == SematId);
        }

        public Hesab_Tbl GetHsab(int hesabId)
        {
            return DB.Hesab_Tbls.FirstOrDefault(x => x.HesabId == hesabId);
        }

        public List<SematShowViewModel> GetSemat()
        {
            var Result =
         from s in DB.Semat_Tbls
         join P in DB.Personal_Tbls
        on s.PersonalId equals P.PersonalId
         select new SematShowViewModel
         {
             PersonalName = $"نام  پرسنل:{P.Name} سمت:{s.SematName}",
             sematID = s.SematId
         };
            return Result.ToList();
        }
    }

}

