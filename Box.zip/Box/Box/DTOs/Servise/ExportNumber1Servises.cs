﻿using Box.DataLayer;
using Box.DTOs.IServise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Box.DTOs.Servise
{
    internal class ExportServises : IExport
    {
        DataClassesDataContext db = new DataClassesDataContext();

        public List<ExportNumber1ViewModel> GetAllExportPersonall(int TypeId, int Status)
        {
            var res =
      from s in db.Semat_Tbls
      join p in db.Personal_Tbls
          on s.PersonalId equals p.PersonalId into sp
      from p in sp.DefaultIfEmpty()

      join v in db.Vahed_Tbls
          on s.Vahed_Id equals v.VahedId into vp
      from v in vp.DefaultIfEmpty()

      join h in db.Hesab_Tbls
          on s.SematId equals h.SematId into hs
      from h in hs.DefaultIfEmpty()

      join a in db.HeaderHesab_Tbls
          on h.HeaderId equals a.HeaderId into ha
      from a in ha.DefaultIfEmpty()
      where (Status == 3 || s.Status == Status)
      where a.TypeHesab == TypeId
      select new ExportNumber1ViewModel
      {
          ShPersonall = p != null ? p.Sh_Personal : null,
          Semat = s.SematName,
          Name = p != null ? p.Name : null,
          Vahed = v != null ? v.Vahed_Title : null,
          Mony = h != null ? h.Money : 0,
          dateTime = a.Date,
          TypeId = a.TypeHesab == 1 ? "صندوق"
              : a.TypeHesab == 2 ? "وام" :
              a.TypeHesab == 3 ? "قسط"
              : "بدون عنوان",
          Mahiyat = a.TypeHesab == 1 ? "بستانکار"
              : a.TypeHesab == 2 ? "بدهکار" :
              a.TypeHesab == 3 ? "بستانکار"
              : "بدون عنوان"
              ,
          status = s.Status,
          SumVam = a != null && h != null && a.TypeHesab == 2 ? h.Money : 0m,
          SumQest = a != null && h != null && a.TypeHesab == 3 ? h.Money : 0m,
          Box = a != null && h != null && a.TypeHesab == 1 ? h.Money : 0m,
      };
            return res.ToList();
        }

        public List<ExportNumber1ViewModel> GetAllExportNumber1(int SematId)
        {
            var tasviehQuery =
     from s in db.Semat_Tbls
     join t in db.Tasviehs on s.SematId equals t.SematId
     into st
     from t in st.DefaultIfEmpty()
     join p in db.Personal_Tbls on s.PersonalId equals p.PersonalId
     into ps
     from p in ps.DefaultIfEmpty()
     join v in db.Vahed_Tbls on s.Vahed_Id equals v.VahedId
     where s.SematId == SematId
     select new ExportNumber1ViewModel
     {
         ShPersonall = p.Sh_Personal,
         Semat = s.SematName,
         Name = p.Name,
         Vahed = v.Vahed_Title,
         Mony = t.Money,
         dateTime = t.Date,
         TypeId = "تسویه",
         Mahiyat = t.Mahiyat == 1 ? "بستانکار(واریز)" : "بدهکار(برداشت)",
         status = s.Status,
         SumVam = 0,
         SumQest = 0,
         Box = 0,
         SumVariz = t.Mahiyat == 1 ? t.Money : 0m,
         SumBardasht = t.Mahiyat == 2 ? t.Money : 0m
     };
            var hesabQuery =
    from s in db.Semat_Tbls
    join p in db.Personal_Tbls on s.PersonalId equals p.PersonalId into sp
    from p in sp.DefaultIfEmpty()

    join v in db.Vahed_Tbls on s.Vahed_Id equals v.VahedId into vp
    from v in vp.DefaultIfEmpty()

    join h in db.Hesab_Tbls on s.SematId equals h.SematId

    join a in db.HeaderHesab_Tbls on h.HeaderId equals a.HeaderId

    where s.SematId == SematId

    select new ExportNumber1ViewModel
    {
        ShPersonall = p != null ? p.Sh_Personal : null,
        Semat = s.SematName,
        Name = p != null ? p.Name : null,
        Vahed = v != null ? v.Vahed_Title : null,
        Mony = h.Money,
        dateTime = a.Date,
        TypeId =
            a.TypeHesab == 1 ? "صندوق" :
            a.TypeHesab == 2 ? "وام" :
            a.TypeHesab == 3 ? "قسط" :
            "بدون عنوان",

        Mahiyat =
            a.TypeHesab == 1 ? "بستانکار" :
            a.TypeHesab == 2 ? "بدهکار" :
            a.TypeHesab == 3 ? "بستانکار" :
            "بدون عنوان",

        status = s.Status,
        SumVam = a.TypeHesab == 2 ? h.Money : 0m,
        SumQest = a.TypeHesab == 3 ? h.Money : 0m,
        Box = a.TypeHesab == 1 ? h.Money : 0m,
        SumVariz = 0,
        SumBardasht = 0,
    };
            var result = hesabQuery.Union(tasviehQuery).ToList();
            return result;
        }

        public List<SematShowViewModel> GetSemat()
        {
            var Result =
         from s in db.Semat_Tbls
         join P in db.Personal_Tbls
        on s.PersonalId equals P.PersonalId
         select new SematShowViewModel
         {
             PersonalName = $"نام  پرسنل:{P.Name} سمت:{s.SematName}",
             sematID = s.SematId
         };
            return Result.ToList();
        }

        public List<ExportNumber1ViewModel> GetAllExport(int SematId, int TypeId)
        {
            var res =
     from s in db.Semat_Tbls
     join p in db.Personal_Tbls
         on s.PersonalId equals p.PersonalId into sp
     from p in sp.DefaultIfEmpty()

     join v in db.Vahed_Tbls
         on s.Vahed_Id equals v.VahedId into vp
     from v in vp.DefaultIfEmpty()

     join h in db.Hesab_Tbls
         on s.SematId equals h.SematId into hs
     from h in hs.DefaultIfEmpty()

     join a in db.HeaderHesab_Tbls
         on h.HeaderId equals a.HeaderId into ha
     from a in ha.DefaultIfEmpty()

     where s.SematId == SematId
     where a.TypeHesab == TypeId
     select new ExportNumber1ViewModel
     {
         ShPersonall = p != null ? p.Sh_Personal : null,
         Semat = s.SematName,
         Name = p != null ? p.Name : null,
         Vahed = v != null ? v.Vahed_Title : null,
         Mony = h != null ? h.Money : 0,
         dateTime = a.Date,
         TypeId = a.TypeHesab == 1 ? "صندوق"
             : a.TypeHesab == 2 ? "وام" :
             a.TypeHesab == 3 ? "قسط"
             : "بدون عنوان",
         Mahiyat = a.TypeHesab == 1 ? "بستانکار"
             : a.TypeHesab == 2 ? "بدهکار" :
             a.TypeHesab == 3 ? "بستانکار"
             : "بدون عنوان"
             ,
         status = s.Status,
         SumVam = a != null && h != null && a.TypeHesab == 2 ? h.Money : 0m,
         SumQest = a != null && h != null && a.TypeHesab == 3 ? h.Money : 0m,
         Box = a != null && h != null && a.TypeHesab == 1 ? h.Money : 0m,
     };
            return res.ToList();
        }

        public List<ExportNumber1ViewModel> GetAllExportPersonall(int TypeId, int Status, DateTime? fromdateTime, DateTime? ToDate = null)
        {
            var res =
      from s in db.Semat_Tbls
      join p in db.Personal_Tbls
          on s.PersonalId equals p.PersonalId into sp
      from p in sp.DefaultIfEmpty()

      join v in db.Vahed_Tbls
          on s.Vahed_Id equals v.VahedId into vp
      from v in vp.DefaultIfEmpty()

      join h in db.Hesab_Tbls
          on s.SematId equals h.SematId into hs
      from h in hs.DefaultIfEmpty()

      join a in db.HeaderHesab_Tbls
          on h.HeaderId equals a.HeaderId into ha
      from a in ha.DefaultIfEmpty()
      where (Status == 3 || s.Status == Status)
      where a.TypeHesab == TypeId
      where (!fromdateTime.HasValue || a.Date >= fromdateTime)
      where (!ToDate.HasValue || a.Date <= ToDate)
      select new ExportNumber1ViewModel
      {
          ShPersonall = p != null ? p.Sh_Personal : null,
          Semat = s.SematName,
          Name = p != null ? p.Name : null,
          Vahed = v != null ? v.Vahed_Title : null,
          Mony = h != null ? h.Money : 0,
          dateTime = a.Date,
          TypeId = a.TypeHesab == 1 ? "صندوق"
              : a.TypeHesab == 2 ? "وام" :
              a.TypeHesab == 3 ? "قسط"
              : "بدون عنوان",
          Mahiyat = a.TypeHesab == 1 ? "بستانکار"
              : a.TypeHesab == 2 ? "بدهکار" :
              a.TypeHesab == 3 ? "بستانکار"
              : "بدون عنوان"
              ,
          status = s.Status,
          SumVam = a != null && h != null && a.TypeHesab == 2 ? h.Money : 0m,
          SumQest = a != null && h != null && a.TypeHesab == 3 ? h.Money : 0m,
          Box = a != null && h != null && a.TypeHesab == 1 ? h.Money : 0m,
      };
            return res.ToList();
        }

        public List<VahedViewModelShow> GetVahe(int vahedID)
        {
            var hesabQuery =
    from s in db.Semat_Tbls

    join v in db.Vahed_Tbls
        on s.Vahed_Id equals v.VahedId

    join h in db.Hesab_Tbls
        on s.SematId equals h.SematId

    join a in db.HeaderHesab_Tbls
        on h.HeaderId equals a.HeaderId

    where v.VahedId == vahedID

    select new VahedViewModelShow
    {
        VahedName = v.Vahed_Title,
        dateTime = a.Date,
        Money = h.Money,

        Type =
            a.TypeHesab == 1 ? "صندوق" :
            a.TypeHesab == 2 ? "وام" :
            a.TypeHesab == 3 ? "قسط" :
            "نامشخص",

        Mahiyat =
            a.TypeHesab == 1 ? "بستانکار" :
            a.TypeHesab == 2 ? "بدهکار" :
            a.TypeHesab == 3 ? "بستانکار" :
            "نامشخص"
    };
            var tasviehQuery =
       from s in db.Semat_Tbls

       join v in db.Vahed_Tbls
           on s.Vahed_Id equals v.VahedId

       join t in db.Tasviehs
           on s.SematId equals t.SematId

       where v.VahedId == vahedID

       select new VahedViewModelShow
       {
           VahedName = v.Vahed_Title,
           dateTime = t.Date,
           Money = t.Money,

           Type = "تسویه",

           Mahiyat =
               t.Mahiyat == 1 ? "بستانکار" :
               t.Mahiyat == 2 ? "بدهکار" :
               "نامشخص"
       };
            var result = hesabQuery
    .Union(tasviehQuery)
    .OrderBy(x => x.dateTime)
    .ToList();
            return result;
        }

        public List<OtherDocBarAsasCompany> GetOderDoc()
        {
            var res = from t in db.TarafHesab_Tbls
                      join
                      D in db.DocOther_Tbls
                      on t.TarafId equals D.TarafId
                      into td
                      from D in td.DefaultIfEmpty()
                      select new OtherDocBarAsasCompany
                      {
                          CodeHesab = t.CodeHesab,
                          Title = t.NameTarafHesab,
                          Variz = D.Mahiyat == 1 ? D.Money : 0,
                          Bardasht = D.Mahiyat == 2 ? D.Money : 0,
                          Mahiat = (D.Mahiyat == 1 ? D.Money : 0) -
                           (D.Mahiyat == 2 ? D.Money : 0) > 0
                           ? "بستانکار"
                           : "بدهکار",
                          MandeHesab = (D.Mahiyat == 1 ? D.Money : 0) -
                           (D.Mahiyat == 2 ? D.Money : 0)


                      };
            return res.ToList();
        }

        public List<Companyview> GetCompany()
        {
            var res = from c in db.Company_Tbls
                      join p in db.Personal_Tbls on c.CompanyId equals p.CompanyId into cp
                      from p in cp.DefaultIfEmpty()

                      join s in db.Semat_Tbls on p.PersonalId equals s.PersonalId into sp
                      from s in sp.DefaultIfEmpty()

                      join h in db.Hesab_Tbls on s.SematId equals h.SematId into sh
                      from h in sh.DefaultIfEmpty()

                      group h by c.Title into g
                      select new Companyview
                      {
                          Titel = g.Key,
                          Mony = g.Sum(x => x != null ? x.Money : 0)
                      };

            return res.ToList();

        }
    }
}