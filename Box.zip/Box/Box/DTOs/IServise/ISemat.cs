﻿using Box.DataLayer;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.IServise
{
    internal interface ISemat
    {
        bool DeleteSemat(int SematId);
        bool AddSemat(SematViewModel sematViewModel);
        bool UpdateSemat(SematViewModel sematViewModel);
        Semat_Tbl GetSemayByID(int SematId);
        List<EmployeeViewModel> GetPersonal();
        List<VahedViewModel> GetVahed();
        List<SematShowViewModel> GetAll();

    }
}
