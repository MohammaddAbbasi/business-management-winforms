﻿using Box.DataLayer;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.IServise
{
    internal interface ITarafhesab
    {
        List<TarafHesab_Tbl> GetAll();
        TarafHesab_Tbl GetTarafHesabByid(int TarafID);
        bool DeleteTarafHesab(int TarafID);
        bool EditTarafHesab(TarafHesabViewModel tarafHesabViewModel);
        bool AddTarafHesab(TarafHesabViewModel tarafHesabViewModel);
    }
}
