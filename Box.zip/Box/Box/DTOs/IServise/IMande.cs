﻿using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.IServise
{
    internal interface IMande
    {
        List<MandeViewModel> GetMande();
    }
}
