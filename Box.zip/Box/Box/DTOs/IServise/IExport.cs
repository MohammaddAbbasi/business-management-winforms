﻿using Box.DTOs.Servise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.IServise
{
    internal interface IExport
    {
        List<ExportNumber1ViewModel> GetAllExportNumber1(int SematId);
        List<SematShowViewModel> GetSemat();
        List<ExportNumber1ViewModel> GetAllExport(int SematId, int TypeId);
        List<ExportNumber1ViewModel> GetAllExportPersonall(int TypeId, int Status, DateTime? fromdateTime = null, DateTime? ToDate = null);
        List<VahedViewModelShow> GetVahe(int vahedID);
        List<OtherDocBarAsasCompany> GetOderDoc();
        List<Companyview> GetCompany();
    }
}
