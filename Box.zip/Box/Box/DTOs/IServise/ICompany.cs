﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Box.DataLayer;
using Box.DTOs.ViewModel;

namespace Box.DTOs.IServise
{

    internal interface ICompany
    {
        List<Company_Tbl> getAll();
        Company_Tbl GetCompanyById(int CompanyId);
        bool DeleteCompany(int CompanyId);
        bool AddCompany(CompanyViewModel companyViewModel);
        bool EditCompany(CompanyViewModel companyViewModel);
    }
}
