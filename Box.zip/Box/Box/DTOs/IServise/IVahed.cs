﻿using Box.DataLayer;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.IServise
{
    internal interface IVahed
    {
        List<VahedViewModel> GetAll();
        bool AddVahed(VahedViewModel vahedViewModel);
        bool RemoveVahed(int vahedid);
        bool EditVahed(VahedViewModel vahedViewModel);
        Vahed_Tbl GetVahedById(int VahedId);
    }
}
