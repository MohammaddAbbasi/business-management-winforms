﻿using Box.DataLayer;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.IServise
{
    internal interface IHeaderHesab
    {
        bool AddHesabHeader(BoxViewModel boxViewModel);
        bool EditHesabHeader(BoxViewModel boxViewModel);
        List<ListViewShowHeaderHesab> GetAll(int? typeId = null, string name = null);
        HeaderHesab_Tbl GetHesabById(int HeaderId);
        bool RemoveHesabHeader(int HeaderId);
        bool CheckHesab(int HeaderId);
    }
}
