﻿using Box.DataLayer;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.IServise
{
    internal interface IHeaderHesabDoc
    {
        List<HederDoc> GetAll(string name);
        bool CheckHesab(int HeaderId);
        bool AddHeaderHesabDoc(HeaderDocOdervViewModel headerDocOdervViewModel);
        bool EditHeaderHesabDoc(HeaderDocOdervViewModel headerDocOdervViewModel);
        bool DeleteHeaderHesabDoc(int HeaderId);
        HeaderDocOther_Tbl getHeaderById(int HeaderDoc);
    }
}
