﻿using Box.DataLayer;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Box.DTOs.IServise
{
    internal interface IEmployee
    {
        List<EmployeeViewModel> GetAll();
        bool EditPerson(EmployeeViewModel employeeViewModel);
        bool AddPerson(EmployeeViewModel employeeViewModel);
        bool DeletePerson(int PersonalId);
        Personal_Tbl GetUserById(int PersonalId);
        List<CompanyViewModel> GetcompanyById();
    }
}
