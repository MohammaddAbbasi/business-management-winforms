﻿using Box.DataLayer;
using Box.DTOs.ViewModel;
using DevExpress.Office.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.IServise
{
    internal interface IHesab
    {
        List<ViewModelShowHesabList> GetAll(int HeaderId, string name);
        bool AddHesab(HesabViewModel hesabViewModel);
        bool EditHesab(HesabViewModel hesabViewModel);
        bool DeleteHesab(int hesabId);
        Hesab_Tbl GetHsab(int hesabId);
        Hesab_Tbl GetHeaderBySematId(int SematId);
        List<SematShowViewModel> GetSemat();

    }
}
