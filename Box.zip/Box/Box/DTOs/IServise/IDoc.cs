﻿using Box.DataLayer;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.IServise
{
    internal interface IDoc
    {
        List<HesabOtherDocViewModel> GetAll(int docId, string name);
        bool AddDoc(DocViewModel docViewModel);
        bool RemoveDoc(int DocId);
        bool EditDoc(DocViewModel docViewModel);
        DocOther_Tbl GetDocById(int DocId);
        List<TarafHesabViewModel> GetTrafId();
    }
}
