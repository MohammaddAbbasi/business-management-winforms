﻿using Box.DataLayer;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box.DTOs.IServise
{
    internal interface ITasvieh
    {
        List<TasviehViewModelShowAll> GetAll(int? SematId, DateTime? fromdateTime = null, DateTime? ToDate = null);
        List<Tasvieh> GetShowAll();
        Tasvieh Get(int id);
        bool AddTasvieh(TasviehViewModel tasviehViewModel);
        bool DeleteTasvieh(int id);
        bool EditTasvieh(TasviehViewModel tasviehViewModel);
    }
}
