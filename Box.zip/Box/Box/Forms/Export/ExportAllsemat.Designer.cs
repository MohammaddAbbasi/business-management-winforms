﻿namespace Box.Forms.Export
{
    partial class ExportAllsemat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExportAllsemat));
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.gridControlpsandaz = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.gridControlvam = new DevExpress.XtraGrid.GridControl();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.groupControl3 = new DevExpress.XtraEditors.GroupControl();
            this.gridControlqest = new DevExpress.XtraGrid.GridControl();
            this.gridView3 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.groupControl4 = new DevExpress.XtraEditors.GroupControl();
            this.gridControltasvie = new DevExpress.XtraGrid.GridControl();
            this.gridView4 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.groupControl5 = new DevExpress.XtraEditors.GroupControl();
            this.mandenahaie = new System.Windows.Forms.Label();
            this.txtMandeVam = new System.Windows.Forms.Label();
            this.samtasvie = new System.Windows.Forms.Label();
            this.txtAghsat = new System.Windows.Forms.Label();
            this.txtVarizVam = new System.Windows.Forms.Label();
            this.txtVarizPsAndaz = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxPersonall = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.simpleButtonShow = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlpsandaz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlvam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).BeginInit();
            this.groupControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlqest)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).BeginInit();
            this.groupControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControltasvie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl5)).BeginInit();
            this.groupControl5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.gridControlpsandaz);
            this.groupControl1.Location = new System.Drawing.Point(17, 77);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(564, 356);
            this.groupControl1.TabIndex = 0;
            this.groupControl1.Text = "پس انداز";
            // 
            // gridControlpsandaz
            // 
            this.gridControlpsandaz.Location = new System.Drawing.Point(5, 31);
            this.gridControlpsandaz.MainView = this.gridView1;
            this.gridControlpsandaz.Name = "gridControlpsandaz";
            this.gridControlpsandaz.Size = new System.Drawing.Size(554, 325);
            this.gridControlpsandaz.TabIndex = 0;
            this.gridControlpsandaz.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.gridControlpsandaz;
            this.gridView1.Name = "gridView1";
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.gridControlvam);
            this.groupControl2.Location = new System.Drawing.Point(587, 77);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(595, 356);
            this.groupControl2.TabIndex = 1;
            this.groupControl2.Text = "وام";
            // 
            // gridControlvam
            // 
            this.gridControlvam.Location = new System.Drawing.Point(5, 31);
            this.gridControlvam.MainView = this.gridView2;
            this.gridControlvam.Name = "gridControlvam";
            this.gridControlvam.Size = new System.Drawing.Size(578, 325);
            this.gridControlvam.TabIndex = 1;
            this.gridControlvam.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView2});
            // 
            // gridView2
            // 
            this.gridView2.GridControl = this.gridControlvam;
            this.gridView2.Name = "gridView2";
            // 
            // groupControl3
            // 
            this.groupControl3.Controls.Add(this.gridControlqest);
            this.groupControl3.Location = new System.Drawing.Point(17, 439);
            this.groupControl3.Name = "groupControl3";
            this.groupControl3.Size = new System.Drawing.Size(564, 536);
            this.groupControl3.TabIndex = 2;
            this.groupControl3.Text = "اقساط";
            // 
            // gridControlqest
            // 
            this.gridControlqest.Location = new System.Drawing.Point(5, 31);
            this.gridControlqest.MainView = this.gridView3;
            this.gridControlqest.Name = "gridControlqest";
            this.gridControlqest.Size = new System.Drawing.Size(545, 500);
            this.gridControlqest.TabIndex = 1;
            this.gridControlqest.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView3});
            // 
            // gridView3
            // 
            this.gridView3.GridControl = this.gridControlqest;
            this.gridView3.Name = "gridView3";
            // 
            // groupControl4
            // 
            this.groupControl4.Controls.Add(this.gridControltasvie);
            this.groupControl4.Location = new System.Drawing.Point(587, 439);
            this.groupControl4.Name = "groupControl4";
            this.groupControl4.Size = new System.Drawing.Size(595, 244);
            this.groupControl4.TabIndex = 3;
            this.groupControl4.Text = "تسویه";
            // 
            // gridControltasvie
            // 
            this.gridControltasvie.Location = new System.Drawing.Point(5, 31);
            this.gridControltasvie.MainView = this.gridView4;
            this.gridControltasvie.Name = "gridControltasvie";
            this.gridControltasvie.Size = new System.Drawing.Size(582, 208);
            this.gridControltasvie.TabIndex = 2;
            this.gridControltasvie.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView4});
            // 
            // gridView4
            // 
            this.gridView4.GridControl = this.gridControltasvie;
            this.gridView4.Name = "gridView4";
            // 
            // groupControl5
            // 
            this.groupControl5.Controls.Add(this.mandenahaie);
            this.groupControl5.Controls.Add(this.txtMandeVam);
            this.groupControl5.Controls.Add(this.samtasvie);
            this.groupControl5.Controls.Add(this.txtAghsat);
            this.groupControl5.Controls.Add(this.txtVarizVam);
            this.groupControl5.Controls.Add(this.txtVarizPsAndaz);
            this.groupControl5.Controls.Add(this.label6);
            this.groupControl5.Controls.Add(this.label7);
            this.groupControl5.Controls.Add(this.label5);
            this.groupControl5.Controls.Add(this.label4);
            this.groupControl5.Controls.Add(this.label3);
            this.groupControl5.Controls.Add(this.label2);
            this.groupControl5.Controls.Add(this.label1);
            this.groupControl5.Location = new System.Drawing.Point(587, 689);
            this.groupControl5.Name = "groupControl5";
            this.groupControl5.Size = new System.Drawing.Size(595, 314);
            this.groupControl5.TabIndex = 4;
            this.groupControl5.Text = "اطلاعات";
            // 
            // mandenahaie
            // 
            this.mandenahaie.AutoSize = true;
            this.mandenahaie.Location = new System.Drawing.Point(392, 293);
            this.mandenahaie.Name = "mandenahaie";
            this.mandenahaie.Size = new System.Drawing.Size(14, 16);
            this.mandenahaie.TabIndex = 1;
            this.mandenahaie.Text = "0";
            this.mandenahaie.Click += new System.EventHandler(this.mandenahaie_Click);
            // 
            // txtMandeVam
            // 
            this.txtMandeVam.AutoSize = true;
            this.txtMandeVam.Location = new System.Drawing.Point(392, 237);
            this.txtMandeVam.Name = "txtMandeVam";
            this.txtMandeVam.Size = new System.Drawing.Size(14, 16);
            this.txtMandeVam.TabIndex = 1;
            this.txtMandeVam.Text = "0";
            // 
            // samtasvie
            // 
            this.samtasvie.AutoSize = true;
            this.samtasvie.Location = new System.Drawing.Point(392, 185);
            this.samtasvie.Name = "samtasvie";
            this.samtasvie.Size = new System.Drawing.Size(14, 16);
            this.samtasvie.TabIndex = 1;
            this.samtasvie.Text = "0";
            // 
            // txtAghsat
            // 
            this.txtAghsat.AutoSize = true;
            this.txtAghsat.Location = new System.Drawing.Point(392, 145);
            this.txtAghsat.Name = "txtAghsat";
            this.txtAghsat.Size = new System.Drawing.Size(14, 16);
            this.txtAghsat.TabIndex = 1;
            this.txtAghsat.Text = "0";
            // 
            // txtVarizVam
            // 
            this.txtVarizVam.AutoSize = true;
            this.txtVarizVam.Location = new System.Drawing.Point(392, 97);
            this.txtVarizVam.Name = "txtVarizVam";
            this.txtVarizVam.Size = new System.Drawing.Size(14, 16);
            this.txtVarizVam.TabIndex = 1;
            this.txtVarizVam.Text = "0";
            // 
            // txtVarizPsAndaz
            // 
            this.txtVarizPsAndaz.AutoSize = true;
            this.txtVarizPsAndaz.Location = new System.Drawing.Point(392, 47);
            this.txtVarizPsAndaz.Name = "txtVarizPsAndaz";
            this.txtVarizPsAndaz.Size = new System.Drawing.Size(14, 16);
            this.txtVarizPsAndaz.TabIndex = 1;
            this.txtVarizPsAndaz.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(374, 262);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(217, 16);
            this.label6.TabIndex = 0;
            this.label6.Text = "______________________________";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Vazir", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(514, 288);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 21);
            this.label7.TabIndex = 0;
            this.label7.Text = "مانده نهایی:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Vazir", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(529, 232);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 21);
            this.label5.TabIndex = 0;
            this.label5.Text = "مانده وام:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Vazir", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(519, 184);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 21);
            this.label4.TabIndex = 0;
            this.label4.Text = "جمع تسویه:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Vazir", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(517, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 21);
            this.label3.TabIndex = 0;
            this.label3.Text = "جمع اقساط:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Vazir", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(529, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 21);
            this.label2.TabIndex = 0;
            this.label2.Text = "جمع وام:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Vazir", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(505, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "جمع پس انداز:";
            // 
            // comboBoxPersonall
            // 
            this.comboBoxPersonall.FormattingEnabled = true;
            this.comboBoxPersonall.Location = new System.Drawing.Point(153, 28);
            this.comboBoxPersonall.Name = "comboBoxPersonall";
            this.comboBoxPersonall.Size = new System.Drawing.Size(283, 32);
            this.comboBoxPersonall.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(48, 31);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(99, 24);
            this.label8.TabIndex = 6;
            this.label8.Text = "انتخاب پرسنل:";
            // 
            // simpleButtonShow
            // 
            this.simpleButtonShow.Appearance.Font = new System.Drawing.Font("Vazir", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleButtonShow.Appearance.Options.UseFont = true;
            this.simpleButtonShow.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("simpleButtonShow.ImageOptions.SvgImage")));
            this.simpleButtonShow.Location = new System.Drawing.Point(968, 12);
            this.simpleButtonShow.Name = "simpleButtonShow";
            this.simpleButtonShow.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.simpleButtonShow.Size = new System.Drawing.Size(214, 56);
            this.simpleButtonShow.TabIndex = 16;
            this.simpleButtonShow.Text = "نمایش";
            this.simpleButtonShow.Click += new System.EventHandler(this.simpleButtonShow_Click);
            // 
            // ExportAllsemat
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1196, 1004);
            this.Controls.Add(this.simpleButtonShow);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.comboBoxPersonall);
            this.Controls.Add(this.groupControl5);
            this.Controls.Add(this.groupControl4);
            this.Controls.Add(this.groupControl3);
            this.Controls.Add(this.groupControl2);
            this.Controls.Add(this.groupControl1);
            this.Font = new System.Drawing.Font("Vazir", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "ExportAllsemat";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "گزارش کلی";
            this.Load += new System.EventHandler(this.ExportAllsemat_Load);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControlpsandaz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControlvam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).EndInit();
            this.groupControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControlqest)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).EndInit();
            this.groupControl4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControltasvie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl5)).EndInit();
            this.groupControl5.ResumeLayout(false);
            this.groupControl5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraGrid.GridControl gridControlpsandaz;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraGrid.GridControl gridControlvam;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraEditors.GroupControl groupControl3;
        private DevExpress.XtraGrid.GridControl gridControlqest;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView3;
        private DevExpress.XtraEditors.GroupControl groupControl4;
        private DevExpress.XtraGrid.GridControl gridControltasvie;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView4;
        private DevExpress.XtraEditors.GroupControl groupControl5;
        private System.Windows.Forms.Label mandenahaie;
        private System.Windows.Forms.Label txtMandeVam;
        private System.Windows.Forms.Label samtasvie;
        private System.Windows.Forms.Label txtAghsat;
        private System.Windows.Forms.Label txtVarizVam;
        private System.Windows.Forms.Label txtVarizPsAndaz;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxPersonall;
        private System.Windows.Forms.Label label8;
        private DevExpress.XtraEditors.SimpleButton simpleButtonShow;
    }
}