﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Export
{
    public partial class Mojodi : DevExpress.XtraEditors.XtraForm
    {
        public Mojodi()
        {
            InitializeComponent();
        }
    }
}
