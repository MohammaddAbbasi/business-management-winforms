﻿using Box.DataLayer;
using Box.DTOs.IServise;
using Box.DTOs.Servise;
using DevExpress.XtraGrid.Views.Grid;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Export
{
    public partial class ExportAllsemat : DevExpress.XtraEditors.XtraForm
    {
        IExport export;
        ITasvieh tasvieh;
        decimal sumVarizPsAndaz = 0;
        decimal sumVarizVam = 0;
        decimal sumVarizQest = 0;
        decimal sumTasvie = 0;
        public ExportAllsemat()
        {
            tasvieh = new TasviehServises();
            export = new ExportServises();
            InitializeComponent();
        }

        private void ExportAllsemat_Load(object sender, EventArgs e)
        {
            var addSemat = export.GetSemat().ToList();
            comboBoxPersonall.DataSource = addSemat;
            comboBoxPersonall.DisplayMember = "PersonalName";
            comboBoxPersonall.ValueMember = "sematID";
        }

        private void simpleButtonShow_Click(object sender, EventArgs e)
        {
            gridControlpsandaz.DataSource = export.GetAllExport(Convert.ToInt32(comboBoxPersonall.SelectedValue), 1);
            gridControlqest.DataSource = export.GetAllExport(Convert.ToInt32(comboBoxPersonall.SelectedValue), 3);
            gridControlvam.DataSource = export.GetAllExport(Convert.ToInt32(comboBoxPersonall.SelectedValue), 2);
            gridControltasvie.DataSource = tasvieh.GetAll(Convert.ToInt32(comboBoxPersonall.SelectedValue));
            refresh();
            RefreshGrid(gridView1);
            RefreshGrid(gridView2);
            RefreshGrid(gridView3);
            RowCellDefaultAlignment();
            // متغیرهای جمع‌کننده
           ; // اگر نیاز دارید

            // تعداد ردیف‌ها را از هر GridView جداگانه بگیرید یا از کم‌ترین مقدار استفاده کنید
            int rowCount = Math.Min(gridView1.DataRowCount,
                           Math.Min(gridView2.DataRowCount, gridView3.DataRowCount));
            decimal SumBardasht = 0;
            for (int i = 0; i < gridView4.DataRowCount; i++)
            {
                var valueSumtasvie = gridView4.GetRowCellValue(i, "SumBardasht");
                sumTasvie += (decimal)valueSumtasvie;
                var valueSumTasviem = gridView4.GetRowCellValue(i, "SumVariz");
                SumBardasht += (decimal)valueSumTasviem;

            }
            decimal mandeh = sumTasvie - SumBardasht;
            samtasvie.Text = mandeh.ToString();
            for (int i = 0; i < rowCount; i++)
            {
                // خواندن مقدار با بررسی DBNull و تبدیل ایمن
                object val1 = gridView1.GetRowCellValue(i, "Box");
                if (val1 != null && val1 != DBNull.Value)
                    sumVarizPsAndaz += Convert.ToDecimal(val1);

                object val2 = gridView2.GetRowCellValue(i, "SumVam");
                if (val2 != null && val2 != DBNull.Value)
                    sumVarizVam += Convert.ToDecimal(val2);

                object val3 = gridView3.GetRowCellValue(i, "SumQest");
                if (val3 != null && val3 != DBNull.Value)
                    sumVarizQest += Convert.ToDecimal(val3);
            }

            // نمایش مقادیر در کنترل‌های مختلف (احتمالاً اشتباه تایپی داشته‌اید)
            txtVarizPsAndaz.Text = sumVarizPsAndaz.ToString("N0"); // یا کنترل مناسب
            txtVarizVam.Text = sumVarizVam.ToString("N0");
            txtAghsat.Text = sumVarizQest.ToString("N0");
            // اگر نیاز به نمایش Bardasht دارید:
            // txtBardasht.Text = sumBardasht.ToString("N0");

            // محاسبه مانده (با فرض اینکه معنی‌دار باشد)
            decimal mande = sumVarizVam - sumVarizQest;
            txtMandeVam.Text = mande.ToString("N0");
            decimal Nahaie=mande+mandeh;
            decimal Naohaie = Nahaie - sumVarizPsAndaz - sumVarizQest;
            mandenahaie.Text = Naohaie.ToString();

            
        }

        private void refresh()

        {
            DataTransfer(gridView4);
            gridView4.Columns[3].Caption = "ماهیت";
            gridView4.Columns[4].Caption = "مبلغ";
            gridView4.Columns["Money"].DisplayFormat.FormatType =
               DevExpress.Utils.FormatType.Numeric;
            gridView4.Columns["Money"].DisplayFormat.FormatString = "n0";
            gridView4.Columns[0].Visible = false;
            gridView4.Columns[1].Visible = false;
            gridView4.Columns[2].Visible = false;
            gridView4.Columns[6].Visible = false;
            gridView4.Columns[5].Visible = false;
            gridView4.Columns[7].Visible = false;
            gridView4.Columns[8].Visible = false;
            gridView4.Columns[9].Visible = false;
            gridView4.Columns[10].Visible = false;
        }

        private void RowCellDefaultAlignment()
        {
            gridView1.RowCellDefaultAlignment += GridView_RowCellDefaultAlignment;
            gridView2.RowCellDefaultAlignment += GridView_RowCellDefaultAlignment;
            gridView3.RowCellDefaultAlignment += GridView_RowCellDefaultAlignment;
            gridView4.RowCellDefaultAlignment += GridView_RowCellDefaultAlignment;
        }

        private void RefreshGrid(GridView view)
        {
            DataTransfer(view);
            view.Columns[0].Caption = "شماره پرسنلی";
            view.Columns[1].Caption = "نام و نام خانوادگی";
            view.Columns[2].Caption = "واحد";
            view.Columns[3].Caption = "سمت";
            view.Columns[4].Visible = false;
            view.Columns[5].Caption = "تاریخ";
            view.Columns[6].Caption = "نوع حساب";
            view.Columns[7].Caption = "ماهیت";

            view.Columns["Mony"].DisplayFormat.FormatType =
                DevExpress.Utils.FormatType.Numeric;
            view.Columns["Mony"].DisplayFormat.FormatString = "n0";

            view.Columns[8].Caption = "مبلغ";

            for (int i = 9; i <= 14; i++)
                view.Columns[i].Visible = false;
        }
        private void DataTransfer(GridView view)
        {
            if (view.DataRowCount > 0)
            {
                for (int i = 0; i < view.DataRowCount; i++)
                {
                    object value = view.GetRowCellValue(i, "dateTime");

                    if (value != null)
                    {
                        DateTime dateTime = Convert.ToDateTime(value);

                        PersianCalendar persian = new PersianCalendar();

                        string persianDate =
                            persian.GetYear(dateTime) + "/" +
                            persian.GetMonth(dateTime).ToString("00") + "/" +
                            persian.GetDayOfMonth(dateTime).ToString("00");

                        view.SetRowCellValue(i, "dateTimetostring", persianDate);
                    }
                }
            }
        }
        private void GridView_RowCellDefaultAlignment(object sender, DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventArgs e)

        {
            e.HorzAlignment = DevExpress.Utils.HorzAlignment.Center;
        }

        private void mandenahaie_Click(object sender, EventArgs e)
        {

        }
    }
}
