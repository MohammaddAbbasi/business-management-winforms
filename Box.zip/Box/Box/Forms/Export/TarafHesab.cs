﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using DevExpress.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Export
{
    public partial class TarafHesab : DevExpress.XtraEditors.XtraForm
    {
        IExport export;
        public TarafHesab()
        {
            export = new ExportServises();
            InitializeComponent();
        }


        private void TarafHesab_Load(object sender, EventArgs e)
        {
            gridControl1.DataSource = export.GetCompany();
            gridControl2.DataSource = export.GetOderDoc();
            refresh1();
            refresh();
            gridView1.RowCellDefaultAlignment += GridView_RowCellDefaultAlignment;
            gridView2.RowCellDefaultAlignment += GridView_RowCellDefaultAlignment;
            gridView2.RowCellStyle += gridView2_RowCellStyle;
            gridView1.RowCellStyle += gridView2_RowCellStyle;
            decimal SumCompany = 0;
            decimal mande = 0;
            for (int i = 0; i < gridView1.DataRowCount; i++)
            {
                var value = gridView1.GetRowCellValue(i, "Mony");
                SumCompany += (decimal)value;
            }
            for (int i = 0; i < gridView2.DataRowCount; i++)
            {
                var value = gridView2.GetRowCellValue(i, "MandeHesab");
                mande += (decimal)value;
            }
            labelPasAndaz.Text = SumCompany.ToString();
            OtherDoc.Text = mande.ToString();
            NumberFormatInfo nfi = new NumberFormatInfo();
            nfi.NumberGroupSeparator = ".";
            foreach (Control c in this.Controls)
            {
                if (c is Label lbl && long.TryParse(lbl.Text, out long num))
                {
                    lbl.Text = num.ToString("#,0", nfi);
                }
            }

        }
        private void refresh1()
        {
            gridView1.Columns[0].Caption = "نام شرکت";
            gridView1.Columns[1].Caption = "مبلغ";
            gridView1.Columns["Mony"].DisplayFormat.FormatType =
            DevExpress.Utils.FormatType.Numeric;
            gridView1.Columns["Mony"].DisplayFormat.FormatString = "n0";
        }
        private void refresh()
        {
            gridView2.Columns[0].Caption = "کد حساب";
            gridView2.Columns[1].Caption = "نام طرف حساب";
            gridView2.Columns[2].Caption = "ماهیت حساب";
            gridView2.Columns[3].Caption = "واریز";
            gridView2.Columns[4].Caption = "برداشت";
            gridView2.Columns[5].Caption = "مانده حساب";
            gridView2.Columns["Variz"].DisplayFormat.FormatType =
            DevExpress.Utils.FormatType.Numeric;
            gridView2.Columns["Variz"].DisplayFormat.FormatString = "n0";
            gridView2.Columns["Bardasht"].DisplayFormat.FormatType =
                  DevExpress.Utils.FormatType.Numeric;
            gridView2.Columns["Bardasht"].DisplayFormat.FormatString = "n0";
            gridView2.Columns["MandeHesab"].DisplayFormat.FormatType =
                  DevExpress.Utils.FormatType.Numeric;
            gridView2.Columns["MandeHesab"].DisplayFormat.FormatString = "n0";
        }
        private void GridView_RowCellDefaultAlignment(object sender, DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventArgs e)

        {
            e.HorzAlignment = DevExpress.Utils.HorzAlignment.Center;
        }
        private void gridView2_RowCellStyle(object sender, DevExpress.XtraGrid.Views.Grid.RowCellStyleEventArgs e)
        {
            if (e.Column.FieldName == "MandeHesab")
            {
                var value = Convert.ToDecimal(gridView2.GetRowCellValue(e.RowHandle, "MandeHesab"));

                if (value < 0)
                {
                    e.Appearance.ForeColor = Color.Red;
                    e.Appearance.Font = new Font(e.Appearance.Font, FontStyle.Bold);
                }
                else if (value > 0)
                {
                    e.Appearance.ForeColor = Color.Green;
                    e.Appearance.Font = new Font(e.Appearance.Font, FontStyle.Bold);
                }
            }


            if (e.Column.FieldName == "Variz")
            {
                e.Appearance.ForeColor = Color.Green;
            }

            if (e.Column.FieldName == "Bardasht")
            {
                e.Appearance.ForeColor = Color.Red;
            }
        }

        private void چاپToolStripMenuItem_Click(object sender, EventArgs e)
        {
            gridView1.ShowPrintPreview();
            gridView2.ShowPrintPreview();
        }

        private void اکسلToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Excel Files|*.xlsx";
            sfd.Title = "ذخیره فایل اکسل";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string path = sfd.FileName;

                gridView1.ExportToXlsx(path);
                gridView2.ExportToXlsx(path);

                MessageBox.Show("فایل با موفقیت ذخیره شد");
            }
        }
    }
}
