﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Export
{
    public partial class ExportAll : DevExpress.XtraEditors.XtraForm
    {
        IExport export;
        DateTime? fromDate;
        DateTime? toDate;
        public ExportAll()
        {
            export = new ExportServises();
            InitializeComponent();
        }

        private void radioButtonBox_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                farsiCalendar1.Visible = true;
                farsiCalendar2.Visible = true;
            }
            else
            {
                farsiCalendar1.Visible = false;
                farsiCalendar2.Visible = false;
            }
        }

        private void ExportAll_Load(object sender, EventArgs e)
        {

            var date = farsiCalendar1.Value.GregorianSelectedDate;
            var items = new[]
           {
                new {Text = "فعال", Value = 1},
                new { Text = "غیرفعال", Value = 2 },
                new { Text = "همه", Value = 3 }
            };
            comboBoxStatsPersonall.DataSource = items;
            comboBoxStatsPersonall.DisplayMember = "Text";
            comboBoxStatsPersonall.ValueMember = "Value";
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            fromDate = farsiCalendar1.Value?.GregorianSelectedDate;
            toDate = farsiCalendar2.Value?.GregorianSelectedDate;

            LoadData(checkBox1.Checked);
        }

        private void LoadData(bool useDateFilter)
        {
            int personnelStatus = Convert.ToInt32(comboBoxStatsPersonall.SelectedValue);

            gridControl1.DataSource = useDateFilter
                ? export.GetAllExportPersonall(GetState(), personnelStatus, fromDate, toDate)
                : export.GetAllExportPersonall(GetState(), personnelStatus);

            ConfigureGrid();
        }

        private void ConfigureGrid()
        {
            datatransfer();

            gridView1.Columns[0].Caption = "شماره پرسنلی";
            gridView1.Columns[1].Caption = "نام و نام خانوادگی";
            gridView1.Columns[2].Caption = "واحد";
            gridView1.Columns[3].Caption = "سمت";
            gridView1.Columns[5].Caption = "تاریخ";
            gridView1.Columns[6].Caption = "نوع حساب";
            gridView1.Columns[7].Caption = "ماهیت";
            gridView1.Columns[8].Caption = "مبلغ";

            gridView1.Columns["Mony"].DisplayFormat.FormatType =
                DevExpress.Utils.FormatType.Numeric;
            gridView1.Columns["Mony"].DisplayFormat.FormatString = "n0";

            gridView1.Columns[4].Visible = false;
            gridView1.Columns[9].Visible = false;
            gridView1.Columns[10].Visible = false;
            gridView1.Columns[11].Visible = false;
            gridView1.Columns[12].Visible = false;
            gridView1.Columns[13].Visible = false;
            gridView1.Columns[14].Visible = false;
        }

        private void datatransfer()
        {
            if (gridView1.DataRowCount > 0)
            {
                for (int i = 0; i < gridView1.DataRowCount; i++)
                {
                    object SellectValue = gridView1.GetRowCellValue(i, "dateTime");
                    DateTime dateTime = Convert.ToDateTime(SellectValue);
                    PersianCalendar persian = new PersianCalendar();
                    string persianDate = persian.GetYear(dateTime) + "/" + persian.GetMonth(dateTime) + "/" + persian.GetDayOfMonth(dateTime);
                    gridView1.SetRowCellValue(i, "dateTimetostring", persianDate);

                }
            }
        }

        private int GetState()
        {
            if (radioButtonVam.Checked)
                return 2;
            if (radioButtonBox.Checked)
                return 1;
            if (radioButtonQest.Checked)
                return 3;
            return 0;
        }

        private void gridView1_RowCellDefaultAlignment(object sender, DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventArgs e)
        {
            e.HorzAlignment = DevExpress.Utils.HorzAlignment.Center;
        }
    }
}
