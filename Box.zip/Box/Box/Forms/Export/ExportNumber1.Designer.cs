﻿namespace Box.Forms.ExportNumber1
{
    partial class ExportNumber1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExportNumber1));
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelTasvieh = new System.Windows.Forms.Label();
            this.labelMande = new System.Windows.Forms.Label();
            this.labelStats = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.چاپToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.اکسلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labelSumVam = new System.Windows.Forms.Label();
            this.labelSumQest = new System.Windows.Forms.Label();
            this.labelpasandaz = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "انتخاب کاربر:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(115, 49);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(194, 29);
            this.comboBox1.TabIndex = 1;
            // 
            // simpleButton1
            // 
            this.simpleButton1.Appearance.Font = new System.Drawing.Font("Vazir", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleButton1.Appearance.Options.UseFont = true;
            this.simpleButton1.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("simpleButton1.ImageOptions.SvgImage")));
            this.simpleButton1.Location = new System.Drawing.Point(747, 34);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.simpleButton1.Size = new System.Drawing.Size(214, 47);
            this.simpleButton1.TabIndex = 2;
            this.simpleButton1.Text = "نمایش";
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // gridControl1
            // 
            this.gridControl1.Location = new System.Drawing.Point(16, 97);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(945, 379);
            this.gridControl1.TabIndex = 3;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.RowCellDefaultAlignment += new DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventHandler(this.gridView1_RowCellDefaultAlignment);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 479);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 21);
            this.label2.TabIndex = 4;
            this.label2.Text = "پس انداز:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 578);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 21);
            this.label3.TabIndex = 4;
            this.label3.Text = "وام:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 528);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 21);
            this.label4.TabIndex = 4;
            this.label4.Text = "اقساط:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(194, 479);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 21);
            this.label5.TabIndex = 5;
            this.label5.Text = "تسویه:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(194, 528);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 21);
            this.label6.TabIndex = 6;
            this.label6.Text = "مانده:";
            // 
            // labelTasvieh
            // 
            this.labelTasvieh.AutoSize = true;
            this.labelTasvieh.Location = new System.Drawing.Point(335, 479);
            this.labelTasvieh.Name = "labelTasvieh";
            this.labelTasvieh.Size = new System.Drawing.Size(17, 21);
            this.labelTasvieh.TabIndex = 7;
            this.labelTasvieh.Text = "0";
            // 
            // labelMande
            // 
            this.labelMande.AutoSize = true;
            this.labelMande.Location = new System.Drawing.Point(325, 528);
            this.labelMande.Name = "labelMande";
            this.labelMande.Size = new System.Drawing.Size(17, 21);
            this.labelMande.TabIndex = 8;
            this.labelMande.Text = "0";
            // 
            // labelStats
            // 
            this.labelStats.AutoSize = true;
            this.labelStats.ForeColor = System.Drawing.Color.Lime;
            this.labelStats.Location = new System.Drawing.Point(637, 49);
            this.labelStats.Name = "labelStats";
            this.labelStats.Size = new System.Drawing.Size(0, 21);
            this.labelStats.TabIndex = 9;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.چاپToolStripMenuItem,
            this.اکسلToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextMenuStrip1.Size = new System.Drawing.Size(114, 52);
            // 
            // چاپToolStripMenuItem
            // 
            this.چاپToolStripMenuItem.Name = "چاپToolStripMenuItem";
            this.چاپToolStripMenuItem.Size = new System.Drawing.Size(113, 24);
            this.چاپToolStripMenuItem.Text = "چاپ";
            this.چاپToolStripMenuItem.Click += new System.EventHandler(this.چاپToolStripMenuItem_Click);
            // 
            // اکسلToolStripMenuItem
            // 
            this.اکسلToolStripMenuItem.Name = "اکسلToolStripMenuItem";
            this.اکسلToolStripMenuItem.Size = new System.Drawing.Size(113, 24);
            this.اکسلToolStripMenuItem.Text = "اکسل";
            this.اکسلToolStripMenuItem.Click += new System.EventHandler(this.اکسلToolStripMenuItem_Click);
            // 
            // labelSumVam
            // 
            this.labelSumVam.AutoSize = true;
            this.labelSumVam.Location = new System.Drawing.Point(94, 578);
            this.labelSumVam.Name = "labelSumVam";
            this.labelSumVam.Size = new System.Drawing.Size(21, 26);
            this.labelSumVam.TabIndex = 10;
            this.labelSumVam.Text = "0";
            // 
            // labelSumQest
            // 
            this.labelSumQest.AutoSize = true;
            this.labelSumQest.Location = new System.Drawing.Point(98, 528);
            this.labelSumQest.Name = "labelSumQest";
            this.labelSumQest.Size = new System.Drawing.Size(17, 21);
            this.labelSumQest.TabIndex = 10;
            this.labelSumQest.Text = "0";
            // 
            // labelpasandaz
            // 
            this.labelpasandaz.AutoSize = true;
            this.labelpasandaz.Location = new System.Drawing.Point(111, 479);
            this.labelpasandaz.Name = "labelpasandaz";
            this.labelpasandaz.Size = new System.Drawing.Size(17, 21);
            this.labelpasandaz.TabIndex = 11;
            this.labelpasandaz.Text = "0";
            // 
            // ExportNumber1
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(973, 634);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.labelpasandaz);
            this.Controls.Add(this.labelSumQest);
            this.Controls.Add(this.labelSumVam);
            this.Controls.Add(this.labelStats);
            this.Controls.Add(this.labelMande);
            this.Controls.Add(this.labelTasvieh);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.gridControl1);
            this.Controls.Add(this.simpleButton1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Vazir", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "ExportNumber1";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "گزارش شماره1";
            this.Load += new System.EventHandler(this.ExportNumber1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelTasvieh;
        private System.Windows.Forms.Label labelMande;
        private System.Windows.Forms.Label labelStats;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem چاپToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem اکسلToolStripMenuItem;
        private System.Windows.Forms.Label labelSumVam;
        private System.Windows.Forms.Label labelSumQest;
        private System.Windows.Forms.Label labelpasandaz;
    }
}