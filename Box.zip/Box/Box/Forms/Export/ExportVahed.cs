﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using DevExpress.ClipboardSource.SpreadsheetML;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Export
{
    public partial class ExportVahed : DevExpress.XtraEditors.XtraForm
    {
        IVahed vahedService = new VahedServise();
        IExport export;
        public ExportVahed()
        {
            export = new ExportServises();
            InitializeComponent();
        }

        private void ExportVahed_Load(object sender, EventArgs e)

        {
            var vahedList = vahedService.GetAll();
            comboBox1.DataSource = vahedList;
            comboBox1.DisplayMember = "VahedTitle";
            comboBox1.ValueMember = "VahedId";

        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {

            gridControl1.DataSource = export.GetVahe(Convert.ToInt32(comboBox1.SelectedValue));
            datatransfer();
            gridView1.Columns[0].Caption = "عنوان واحد";
            gridView1.Columns[5].Caption = " تاریخ ثبت";
            gridView1.Columns[2].Caption = "نوع گزارش";
            gridView1.Columns[3].Caption = "ماهیت";
            gridView1.Columns[4].Caption = "مبلغ";
            gridView1.Columns[1].Visible = false;
            gridView1.Columns["Money"].DisplayFormat.FormatType =
              DevExpress.Utils.FormatType.Numeric;
            gridView1.Columns["Money"].DisplayFormat.FormatString = "n0";
        }
        private void datatransfer()
        {
            if (gridView1.DataRowCount > 0)
            {
                for (int i = 0; i < gridView1.DataRowCount; i++)
                {
                    object SellectValue = gridView1.GetRowCellValue(i, "dateTime");
                    DateTime dateTime = Convert.ToDateTime(SellectValue);
                    PersianCalendar persian = new PersianCalendar();
                    string persianDate =
    $"{persian.GetYear(dateTime)}/{persian.GetMonth(dateTime):00}/{persian.GetDayOfMonth(dateTime):00}";
                    gridView1.SetRowCellValue(i, "dateTimetostring", persianDate);
                }
            }
        }

        private void gridView1_RowCellDefaultAlignment(object sender, DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventArgs e)
        {
            e.HorzAlignment = DevExpress.Utils.HorzAlignment.Center;
        }
    }
}
