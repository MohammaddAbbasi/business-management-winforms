﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.DTOs.ViewModel;
using DevExpress.Data.Mask.Internal;
using DevExpress.XtraGrid;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.ExportNumber1
{
    public partial class ExportNumber1 : DevExpress.XtraEditors.XtraForm
    {
        IExport export;
        List<ExportNumber1ViewModel> exportNumber1ViewModels;
        public ExportNumber1()
        {
            export = new ExportServises();
            InitializeComponent();
        }

        private void ExportNumber1_Load(object sender, EventArgs e)
        {
            var RES = export.GetSemat();
            comboBox1.DataSource = RES;
            comboBox1.DisplayMember = "PersonalName";
            comboBox1.ValueMember = "sematID";
            NumberFormatInfo nfi = new NumberFormatInfo();
            nfi.NumberGroupSeparator = ".";
            foreach (Control c in this.Controls)
            {
                if (c is Label lbl && long.TryParse(lbl.Text, out long num))
                {
                    lbl.Text = num.ToString("#,0", nfi);
                }
            }
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            refresh();
            int status = Convert.ToInt32(gridView1.GetRowCellValue(1, "status"));
            if (status == 1)
            {
                labelStats.Text = "کاربر فعال است";
                labelStats.ForeColor = Color.Green;
            }
            else
            {
                labelStats.Text = "کاربر فعال نیست";
                labelStats.ForeColor = Color.Red;

            }
            decimal SumVam = 0;
            decimal SumQest = 0;
            decimal PasAndaz = 0;
            decimal SumVariz = 0;
            decimal SumBardasht=0;
            for (int i = 0; i < gridView1.DataRowCount; i++)
            {
                var valueSumVam = gridView1.GetRowCellValue(i, "SumVam");
                SumVam += (decimal)valueSumVam;
                var valueSumQest = gridView1.GetRowCellValue(i, "SumQest");
                SumQest += (decimal)valueSumQest;
                var pasandaz = gridView1.GetRowCellValue(i, "Box");
                PasAndaz += (decimal)pasandaz;
                var valueSumvariz = gridView1.GetRowCellValue(i, "SumVariz");
                SumVariz += (decimal)valueSumvariz;
                var valuseSumBardasht = gridView1.GetRowCellValue(i, "SumBardasht");
                SumBardasht += (decimal)valuseSumBardasht;
            }
            labelSumVam.Text = SumVam.ToString();
            labelSumQest.Text = SumQest.ToString();
            labelpasandaz.Text = PasAndaz.ToString();
            decimal Mande = PasAndaz - SumQest - SumVam;
            labelMande.Text = Mande.ToString();
            decimal Tasvie = SumVariz - SumBardasht;
            labelTasvieh.Text= Tasvie.ToString();
            NumberFormatInfo nfi = new NumberFormatInfo();
            nfi.NumberGroupSeparator = ".";
            foreach (Control c in this.Controls)
            {
                if (c is Label lbl && long.TryParse(lbl.Text, out long num))
                {
                    lbl.Text = num.ToString("#,0", nfi);
                }
            }
        }

        private void refresh()
        {
            exportNumber1ViewModels = export.GetAllExportNumber1(Convert.ToInt32(comboBox1.SelectedValue));
            gridControl1.DataSource = exportNumber1ViewModels;
            gridView1.Columns[0].Caption = "شماره پرسنلی";
            datatransfer();
            gridView1.Columns[1].Caption = "نام و نام خانوادگی";
            gridView1.Columns[2].Caption = "واحد";
            gridView1.Columns[3].Caption = "سمت";
            gridView1.Columns[4].Visible = false;
            gridView1.Columns[5].Caption = "تاریخ";
            gridView1.Columns[6].Caption = "نوع حساب";
            gridView1.Columns[7].Caption = "ماهیت";
            gridView1.Columns[8].Caption = "مبلغ";
            gridView1.Columns["Mony"].DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            gridView1.Columns["Mony"].DisplayFormat.FormatString = "n0";
            gridView1.Columns[9].Visible = false;
            gridView1.Columns[10].Visible = false;
            gridView1.Columns[11].Visible = false;
            gridView1.Columns[12].Visible = false;
            gridView1.Columns[13].Visible = false;
            gridView1.Columns[14].Visible = false;

        }

        private void datatransfer()
        {
            if (gridView1.DataRowCount > 0)
            {
                for (int i = 0; i < gridView1.DataRowCount; i++)
                {
                    object SellectValue = gridView1.GetRowCellValue(i, "dateTime");
                    DateTime dateTime = Convert.ToDateTime(SellectValue);
                    PersianCalendar persian = new PersianCalendar();
                    string persianDate = persian.GetYear(dateTime) + "/" + persian.GetMonth(dateTime) + "/" + persian.GetDayOfMonth(dateTime);
                    gridView1.SetRowCellValue(i, "dateTimetostring", persianDate);

                }
            }
        }

        private void gridView1_RowCellDefaultAlignment(object sender, DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventArgs e)
        {
            e.HorzAlignment = DevExpress.Utils.HorzAlignment.Center;
        }

        private void اکسلToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Excel Files|*.xlsx";
            sfd.Title = "ذخیره فایل اکسل";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string path = sfd.FileName;

                gridView1.ExportToXlsx(path);

                MessageBox.Show("فایل با موفقیت ذخیره شد");
            }
        }

        private void چاپToolStripMenuItem_Click(object sender, EventArgs e)
        {
            gridView1.ShowPrintPreview();
        }
    }
}
