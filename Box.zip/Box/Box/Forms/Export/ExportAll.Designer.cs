﻿namespace Box.Forms.Export
{
    partial class ExportAll
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            AmirCalendar.FarsiDate farsiDate1 = new AmirCalendar.FarsiDate();
            AmirCalendar.FarsiDate farsiDate2 = new AmirCalendar.FarsiDate();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExportAll));
            this.groupBox = new System.Windows.Forms.GroupBox();
            this.radioButtonQest = new System.Windows.Forms.RadioButton();
            this.radioButtonVam = new System.Windows.Forms.RadioButton();
            this.radioButtonBox = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.farsiCalendar1 = new AmirCalendar.FarsiCalendar();
            this.farsiCalendar2 = new AmirCalendar.FarsiCalendar();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.comboBoxStatsPersonall = new System.Windows.Forms.ComboBox();
            this.groupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox
            // 
            this.groupBox.Controls.Add(this.radioButtonQest);
            this.groupBox.Controls.Add(this.radioButtonVam);
            this.groupBox.Controls.Add(this.radioButtonBox);
            this.groupBox.Location = new System.Drawing.Point(12, 12);
            this.groupBox.Name = "groupBox";
            this.groupBox.Size = new System.Drawing.Size(352, 100);
            this.groupBox.TabIndex = 2;
            this.groupBox.TabStop = false;
            this.groupBox.Text = "نوع گزارش";
            // 
            // radioButtonQest
            // 
            this.radioButtonQest.AutoSize = true;
            this.radioButtonQest.Location = new System.Drawing.Point(66, 38);
            this.radioButtonQest.Name = "radioButtonQest";
            this.radioButtonQest.Size = new System.Drawing.Size(64, 25);
            this.radioButtonQest.TabIndex = 2;
            this.radioButtonQest.TabStop = true;
            this.radioButtonQest.Text = "اقساط";
            this.radioButtonQest.UseVisualStyleBackColor = true;
            this.radioButtonQest.Click += new System.EventHandler(this.radioButtonBox_Click);
            // 
            // radioButtonVam
            // 
            this.radioButtonVam.AutoSize = true;
            this.radioButtonVam.Location = new System.Drawing.Point(187, 38);
            this.radioButtonVam.Name = "radioButtonVam";
            this.radioButtonVam.Size = new System.Drawing.Size(48, 25);
            this.radioButtonVam.TabIndex = 1;
            this.radioButtonVam.TabStop = true;
            this.radioButtonVam.Text = "وام";
            this.radioButtonVam.UseVisualStyleBackColor = true;
            this.radioButtonVam.Click += new System.EventHandler(this.radioButtonBox_Click);
            // 
            // radioButtonBox
            // 
            this.radioButtonBox.AutoSize = true;
            this.radioButtonBox.Location = new System.Drawing.Point(276, 38);
            this.radioButtonBox.Name = "radioButtonBox";
            this.radioButtonBox.Size = new System.Drawing.Size(70, 25);
            this.radioButtonBox.TabIndex = 0;
            this.radioButtonBox.TabStop = true;
            this.radioButtonBox.Text = "صندوق";
            this.radioButtonBox.UseVisualStyleBackColor = true;
            this.radioButtonBox.Click += new System.EventHandler(this.radioButtonBox_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(370, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(179, 21);
            this.label1.TabIndex = 3;
            this.label1.Text = "فیلتر بر اساس وضعیت کارکنان:";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(12, 139);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(157, 25);
            this.checkBox1.TabIndex = 5;
            this.checkBox1.Text = "جستجو بر اساس تاریخ:";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(177, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 21);
            this.label2.TabIndex = 6;
            this.label2.Text = "از تاریخ:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(579, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 21);
            this.label3.TabIndex = 7;
            this.label3.Text = "تا تاریخ:";
            // 
            // farsiCalendar1
            // 
            this.farsiCalendar1.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.farsiCalendar1.Location = new System.Drawing.Point(249, 136);
            this.farsiCalendar1.Name = "farsiCalendar1";
            this.farsiCalendar1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.farsiCalendar1.Size = new System.Drawing.Size(280, 25);
            this.farsiCalendar1.TabIndex = 8;
            farsiDate1.FarsiSelectedDate = "1405/03/26";
            this.farsiCalendar1.Value = farsiDate1;
            this.farsiCalendar1.Visible = false;
            // 
            // farsiCalendar2
            // 
            this.farsiCalendar2.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.farsiCalendar2.Location = new System.Drawing.Point(653, 136);
            this.farsiCalendar2.Name = "farsiCalendar2";
            this.farsiCalendar2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.farsiCalendar2.Size = new System.Drawing.Size(280, 25);
            this.farsiCalendar2.TabIndex = 8;
            farsiDate2.FarsiSelectedDate = "1405/03/26";
            this.farsiCalendar2.Value = farsiDate2;
            this.farsiCalendar2.Visible = false;
            // 
            // simpleButton1
            // 
            this.simpleButton1.Appearance.Font = new System.Drawing.Font("Vazir", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleButton1.Appearance.Options.UseFont = true;
            this.simpleButton1.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("simpleButton1.ImageOptions.SvgImage")));
            this.simpleButton1.Location = new System.Drawing.Point(785, 33);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.simpleButton1.Size = new System.Drawing.Size(197, 55);
            this.simpleButton1.TabIndex = 9;
            this.simpleButton1.Text = "نمایش";
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // gridControl1
            // 
            this.gridControl1.Location = new System.Drawing.Point(12, 194);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(982, 464);
            this.gridControl1.TabIndex = 10;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.RowCellDefaultAlignment += new DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventHandler(this.gridView1_RowCellDefaultAlignment);
            // 
            // comboBoxStatsPersonall
            // 
            this.comboBoxStatsPersonall.FormattingEnabled = true;
            this.comboBoxStatsPersonall.Location = new System.Drawing.Point(555, 30);
            this.comboBoxStatsPersonall.Name = "comboBoxStatsPersonall";
            this.comboBoxStatsPersonall.Size = new System.Drawing.Size(159, 29);
            this.comboBoxStatsPersonall.TabIndex = 11;
            // 
            // ExportAll
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1006, 670);
            this.Controls.Add(this.comboBoxStatsPersonall);
            this.Controls.Add(this.gridControl1);
            this.Controls.Add(this.simpleButton1);
            this.Controls.Add(this.farsiCalendar2);
            this.Controls.Add(this.farsiCalendar1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox);
            this.Font = new System.Drawing.Font("Vazir", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "ExportAll";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "گزارش جامع";
            this.Load += new System.EventHandler(this.ExportAll_Load);
            this.groupBox.ResumeLayout(false);
            this.groupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox;
        private System.Windows.Forms.RadioButton radioButtonQest;
        private System.Windows.Forms.RadioButton radioButtonVam;
        private System.Windows.Forms.RadioButton radioButtonBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private AmirCalendar.FarsiCalendar farsiCalendar1;
        private AmirCalendar.FarsiCalendar farsiCalendar2;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private System.Windows.Forms.ComboBox comboBoxStatsPersonall;
    }
}