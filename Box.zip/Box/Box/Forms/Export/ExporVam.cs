﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Exls
{
    public partial class ExporVam : DevExpress.XtraEditors.XtraForm
    {
        IExport export;
        int typedId;
        public ExporVam(int typedId)
        {
            export = new ExportServises();
            InitializeComponent();
            this.typedId = typedId;
        }

        private void ExporVam_Load(object sender, EventArgs e)
        {
            var RES = export.GetSemat();
            comboBox1.DataSource = RES;
            comboBox1.DisplayMember = "PersonalName";
            comboBox1.ValueMember = "sematID";
            
        }

        private void refresh()
        {
            gridControl1.DataSource = export.GetAllExport(Convert.ToInt32(comboBox1.SelectedValue), typedId);
            datatransfer();
            gridView1.Columns[0].Caption = "شماره پرسنلی";
            gridView1.Columns[1].Caption = "نام و نام خانوادگی";
            gridView1.Columns[2].Caption = "واحد";
            gridView1.Columns[3].Caption = "سمت";
            gridView1.Columns[4].Visible = false;
            gridView1.Columns[5].Caption = "تاریخ";
            gridView1.Columns[6].Caption = "نوع حساب";
            gridView1.Columns[7].Caption = "ماهیت";
            gridView1.Columns["Mony"].DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            gridView1.Columns["Mony"].DisplayFormat.FormatString = "n0";
            gridView1.Columns[8].Caption = "مبلغ";
            gridView1.Columns[9].Visible = false;
            gridView1.Columns[10].Visible = false;
            gridView1.Columns[11].Visible = false;
            gridView1.Columns[12].Visible = false;
            gridView1.Columns[13].Visible = false;
            gridView1.Columns[14].Visible = false;
        }

        private void datatransfer()
        {
            if (gridView1.DataRowCount > 0)
            {
                for (int i = 0; i < gridView1.DataRowCount; i++)
                {
                    object SellectValue = gridView1.GetRowCellValue(i, "dateTime");
                    DateTime dateTime = Convert.ToDateTime(SellectValue);
                    PersianCalendar persian = new PersianCalendar();
                    string persianDate = persian.GetYear(dateTime) + "/" + persian.GetMonth(dateTime) + "/" + persian.GetDayOfMonth(dateTime);
                    gridView1.SetRowCellValue(i, "dateTimetostring", persianDate);

                }
            }
        }

        private void simpleButton1_Click(object sender, EventArgs e)

        {
            refresh();
            int status = Convert.ToInt32(gridView1.GetRowCellValue(1, "status"));
            if (status == 1)
            {
                labelStats.Text = "کاربر فعال است";
                labelStats.ForeColor = Color.Green;
            }
            else
            {
                labelStats.Text = "کاربر فعال نیست";
                labelStats.ForeColor = Color.Red;

            }
            decimal SumVam = 0;
            decimal SumQest = 0;
            decimal PasAndaz = 0;
            for (int i = 0; i < gridView1.DataRowCount; i++)
            {
                var valueSumVam = gridView1.GetRowCellValue(i, "SumVam");
                SumVam += (decimal)valueSumVam;
                var valueSumQest = gridView1.GetRowCellValue(i, "SumQest");
                SumQest += (decimal)valueSumQest;
                var pasandaz = gridView1.GetRowCellValue(i, "Box");
                PasAndaz += (decimal)pasandaz;
            }
            if (typedId == 1)
            {
                labelVam.Text = PasAndaz.ToString();
            }
            else if(typedId == 2)
            {
                labelVam.Text = SumVam.ToString();
            }
            else if (typedId == 3)
            {
                labelVam.Text = SumQest.ToString();
            }
            NumberFormatInfo nfi = new NumberFormatInfo();
            nfi.NumberGroupSeparator = ".";
            foreach (Control c in this.Controls)
            {
                if (c is Label lbl && long.TryParse(lbl.Text, out long num))
                {
                    lbl.Text = num.ToString("#,0", nfi);
                }
            }
        }

        private void gridView1_RowCellDefaultAlignment(object sender, DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventArgs e)
        {
            e.HorzAlignment = DevExpress.Utils.HorzAlignment.Center;
        }
    }
}
