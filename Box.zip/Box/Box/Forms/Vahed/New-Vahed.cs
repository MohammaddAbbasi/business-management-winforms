﻿using Box.DTOs;
using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Vahed
{
    public partial class New_Vahed : DevExpress.XtraEditors.XtraForm
    {
        int vahedID;
        IVahed vahed;
        IEmployee Employee;
        public New_Vahed(int vahedId)
        {
            this.vahedID = vahedId;
            Employee = new EmployeeServise();
            vahed = new VahedServise();
            InitializeComponent();
        }

        private void simpleButtonCancell_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textEdit1.Text))
            {
                MessageBox.Show("اطلاعات را کامل وارد کنید", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
             if (vahedID == 0)
            {
                VahedViewModel vahedViewModel = new VahedViewModel();
                vahedViewModel.VahedTitle = textEdit1.Text;
                vahedViewModel.CompanyId = Convert.ToInt32(comboBox1.SelectedValue);
                if (vahed.AddVahed(vahedViewModel) == true)
                {
                    MessageBox.Show("ثبت نام با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("اطلاعات  ثبت نشد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                VahedViewModel Vhed = new VahedViewModel();
                Vhed.VahedTitle = textEdit1.Text;
                Vhed.CompanyId = Convert.ToInt32(comboBox1.SelectedValue);
                Vhed.VahedId = vahedID;
                if (vahed.EditVahed(Vhed) == true)
                {
                    MessageBox.Show("ویرایش با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("اطلاعات  ثبت نشد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void New_Vahed_Load(object sender, EventArgs e)
        {
            var res = Employee.GetcompanyById();
            comboBox1.DataSource = res;
            comboBox1.DisplayMember = "CompanyName";
            comboBox1.ValueMember = "Id";
            if (vahedID != 0)
            {
                this.Text = "ویرایش";
                var vaheed = vahed.GetVahedById(vahedID);
                textEdit1.Text = vaheed.Vahed_Title;
                comboBox1.DataSource = res;
                comboBox1.DisplayMember = "CompanyName";
                comboBox1.ValueMember = "Id";
            }
        }
    }
}
