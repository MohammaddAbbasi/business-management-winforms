﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using DevExpress.XtraGrid;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Vahed
{
    public partial class ListVahed : DevExpress.XtraEditors.XtraForm
    {
        IVahed vahed;
        public ListVahed()
        {
            vahed = new VahedServise();
            InitializeComponent();
        }

        private void ListVahed_Load(object sender, EventArgs e)
        {
            gridControl1.ContextMenuStrip = contextMenuStrip1;
            refresh();

        }

        private void refresh()
        {
            gridControl1.DataSource = vahed.GetAll();
            gridView1.Columns[0].Visible = false;
            gridView1.Columns[1].Visible = false;
            gridView1.Columns[2].Caption = "نام واحد";
            gridView1.Columns[3].Caption = " نام شرکت";

        }

        private void افزودنToolStripMenuItem_Click(object sender, EventArgs e)
        {
            New_Vahed new_Vahed = new New_Vahed(0);
            new_Vahed.ShowDialog();
        }

        private void ویرایشToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int groupid = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "VahedId"));
            New_Vahed new_Vahed = new New_Vahed(groupid);
            new_Vahed.ShowDialog();
        }

        private void حذفToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int groupid = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "VahedId"));
            DialogResult dialog = MessageBox.Show("آیا از حذف این کاربر مطمئن هستید؟", "پیغام", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dialog == DialogResult.OK)
            {
                if (vahed.RemoveVahed(groupid) == true)
                {
                    MessageBox.Show("کابر با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    refresh();
                }
                else
                {
                    MessageBox.Show("اطلاعات با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void gridView1_RowCellDefaultAlignment(object sender, DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventArgs e)
        {
            e.HorzAlignment = DevExpress.Utils.HorzAlignment.Center;

        }
    }
}
