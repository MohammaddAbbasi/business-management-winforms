﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Qest
{
    public partial class New_Qes : DevExpress.XtraEditors.XtraForm
    {
        int HedeaerId;
        IHeaderHesab box;
        public New_Qes(int hedeaerId)
        {
            box = new HeaderHesabServises();
            InitializeComponent();
            this.HedeaerId = hedeaerId;
        }

        private void New_Qes_Load(object sender, EventArgs e)
        {
            if (HedeaerId != 0)
            {
                this.Text = "ویرایش";
                var headerHesab_ = box.GetHesabById(HedeaerId);
                textEdit1.Text = headerHesab_.Subject;
            }
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textEdit1.Text))
            {
                MessageBox.Show("اطلاعات را کامل وارد کنید", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (HedeaerId == 0)
            {
                BoxViewModel boxViewModel = new BoxViewModel();
                boxViewModel.Subject = textEdit1.Text;
                boxViewModel.dateTime = farsiCalendar1.Value.GregorianSelectedDate;
                boxViewModel.TypeHesab = 3;
                if (box.AddHesabHeader(boxViewModel) == true)
                {
                    MessageBox.Show("ثبت نام با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("اطلاعات  ثبت نشد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                BoxViewModel boxViewModel = new BoxViewModel();
                boxViewModel.Subject = textEdit1.Text;
                boxViewModel.HeaderId = HedeaerId;
                boxViewModel.dateTime = farsiCalendar1.Value.GregorianSelectedDate;
                boxViewModel.TypeHesab = 3;
                if (box.EditHesabHeader(boxViewModel) == true)
                {
                    MessageBox.Show("ویرایش با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("اطلاعات  ثبت نشد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
