﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.Forms.Box;
using Box.Forms.Hesab;
using DevExpress.XtraGrid.Views.Grid;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Qest
{
    public partial class Qest_List : DevExpress.XtraEditors.XtraForm
    {
        IHeaderHesab box;
        public Qest_List()
        {
            box = new HeaderHesabServises();
            InitializeComponent();
        }

        private void افزودنToolStripMenuItem_Click(object sender, EventArgs e)
        {
            New_Qes new_Qes = new New_Qes(0);
            new_Qes.ShowDialog();
        }

        private void ویرایشToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int HeaderId = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "HeaderId"));
            New_Qes new_Qes = new New_Qes(HeaderId);
            new_Qes.ShowDialog();
        }

        private void حذفToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int HeaderId = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "HeaderId"));
            DialogResult dialog = MessageBox.Show("آیا از حذف این کاربر مطمئن هستید؟", "پیغام", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dialog == DialogResult.OK)
            {
                if (box.RemoveHesabHeader(HeaderId) == true)
                {
                    MessageBox.Show("کابر با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else
                {
                    MessageBox.Show("حذف اطلاعات با شکست مواجه شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void Qest_List_Load(object sender, EventArgs e)
        {
            refresh();
        }
        private void refresh()
        {
            gridControl1.DataSource = box.GetAll(3, textEdit1.Text?.Trim());
            gridView1.Columns[0].Visible = false;
            gridView1.Columns[2].Visible = false;
            dataTransfer();
            gridView1.Columns[1].Caption = "عنوان ";
            gridView1.Columns[5].Caption = "تاریخ سند";
            gridView1.Columns[3].Caption = "مجموع";
            gridView1.Columns[4].Caption = "تعداد سندهای ثبت شده";
            gridView1.Columns["Money"].DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            gridView1.Columns["Money"].DisplayFormat.FormatString = "n0";
        }
        private void dataTransfer()
        {
            if (gridView1.DataRowCount > 0)
            {
                for (int i = 0; i < gridView1.DataRowCount; i++)
                {
                    object SellectValue = gridView1.GetRowCellValue(i, "dateTime");
                    DateTime dateTime = Convert.ToDateTime(SellectValue);
                    PersianCalendar persian = new PersianCalendar();
                    string persianDate = persian.GetYear(dateTime) + "/" + persian.GetMonth(dateTime) + "/" + persian.GetDayOfMonth(dateTime);
                    gridView1.SetRowCellValue(i, "dateTimetostring", persianDate);

                }
            }
        }
        private void gridView1_RowCellClick(object sender, RowCellClickEventArgs e)
        {

        }

        private void gridView1_DoubleClick(object sender, EventArgs e)
        {
            if (gridView1.DataRowCount > 0)
            {
                try
                {
                    int index = gridView1.FocusedRowHandle;
                    int id = Convert.ToInt32(gridView1.GetRowCellValue(index, "HeaderId"));
                    Hesab_List hesab_List = new Hesab_List(2, id);
                    hesab_List.ShowDialog();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void gridView1_RowCellDefaultAlignment(object sender, DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventArgs e)
        {
            e.HorzAlignment = DevExpress.Utils.HorzAlignment.Center;
        }

        private void textEdit1_TextChanged(object sender, EventArgs e)
        {
            gridControl1.DataSource = box.GetAll(3, textEdit1.Text?.Trim());
        }
    }
}
