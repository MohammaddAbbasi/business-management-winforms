﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.DTOs.ViewModel;
using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.OtherDoc
{
    public partial class NewOderDoc : DevExpress.XtraEditors.XtraForm
    {
        IDoc doc;
        int EditDoc;
        int HeadId;
        public NewOderDoc(int EditDoc, int HeadId)
        {
            doc = new DocServises();
            this.EditDoc = EditDoc;
            this.HeadId = HeadId;
            InitializeComponent();
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            GetMoney();
            if (calcEdit.Value == 0)
            {
                MessageBox.Show("اطلاعات را کامل وارد کنید", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (EditDoc == 0)
                {
                    DocViewModel docViewModel = new DocViewModel();
                    docViewModel.TarafId = Convert.ToInt32(comboBoxCompsny.SelectedValue);
                    docViewModel.Money = Convert.ToDecimal(calcEdit.EditValue);
                    docViewModel.Description = textBoxDescripition.Text;
                    docViewModel.Mahiyat = Convert.ToInt32(Mahiyat.SelectedValue);
                    docViewModel.HeadId = HeadId;
                    if (doc.AddDoc(docViewModel) == true)
                    {
                        MessageBox.Show("ثبت نام با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("اطلاعات  ثبت نشد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    DocViewModel docViewModel = new DocViewModel();
                    docViewModel.TarafId = Convert.ToInt32(comboBoxCompsny.SelectedIndex);
                    docViewModel.Money = Convert.ToDecimal(calcEdit.EditValue);
                    docViewModel.Description = textBoxDescripition.Text;
                    docViewModel.DocId = EditDoc;
                    docViewModel.HeadId = HeadId;
                    if (doc.EditDoc(docViewModel) == true)
                    {
                        MessageBox.Show("ویرایش با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("اطلاعات  ثبت نشد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void GetMoney()
        {
            calcEdit.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            calcEdit.Properties.DisplayFormat.FormatString = "n0";
            calcEdit.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            calcEdit.Properties.EditFormat.FormatString = "n0";
        }

        private void NewOderDoc_Load(object sender, EventArgs e)
        {
            comboBoxCompsny.DataSource = doc.GetTrafId();
            comboBoxCompsny.DisplayMember = "NameTarafHesab";
            comboBoxCompsny.ValueMember = "TarafId";
            var items = new[]
            {
                new {Text = "واریز", Value = 1},
                new { Text = "برداشت", Value = 2 }
            };
            Mahiyat.DataSource = items;
            Mahiyat.DisplayMember = "Text";
            Mahiyat.ValueMember = "Value";
            if (EditDoc != 0)
            {
                var docEdit = doc.GetDocById(EditDoc);
                calcEdit.Value = docEdit.Money;
                comboBoxCompsny.Enabled = false;
                comboBoxCompsny.SelectedValue = docEdit.TarafId;
            }

        }

        private void txtMoney_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
