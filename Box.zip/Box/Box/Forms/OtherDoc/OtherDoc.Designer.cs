﻿namespace Box.Forms.OtherDoc
{
    partial class OtherDoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ribbonPage2 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.textEdit = new DevExpress.XtraEditors.TextEdit();
            this.label1 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.افزودنسربرگToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.حذفسربرگToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ویرایشسربرگToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit.Properties)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "ribbonPage2";
            // 
            // gridControl1
            // 
            this.gridControl1.Location = new System.Drawing.Point(12, 72);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(822, 354);
            this.gridControl1.TabIndex = 0;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.RowCellDefaultAlignment += new DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventHandler(this.gridView1_RowCellDefaultAlignment);
            this.gridView1.DoubleClick += new System.EventHandler(this.gridView1_DoubleClick);
            // 
            // textEdit
            // 
            this.textEdit.Location = new System.Drawing.Point(77, 35);
            this.textEdit.Name = "textEdit";
            this.textEdit.Size = new System.Drawing.Size(203, 22);
            this.textEdit.TabIndex = 1;
            this.textEdit.TextChanged += new System.EventHandler(this.textEdit_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "جستجو:";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.افزودنسربرگToolStripMenuItem,
            this.حذفسربرگToolStripMenuItem,
            this.ویرایشسربرگToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextMenuStrip1.Size = new System.Drawing.Size(170, 76);
            // 
            // افزودنسربرگToolStripMenuItem
            // 
            this.افزودنسربرگToolStripMenuItem.Name = "افزودنسربرگToolStripMenuItem";
            this.افزودنسربرگToolStripMenuItem.Size = new System.Drawing.Size(169, 24);
            this.افزودنسربرگToolStripMenuItem.Text = "افزودن سربرگ";
            this.افزودنسربرگToolStripMenuItem.Click += new System.EventHandler(this.افزودنسربرگToolStripMenuItem_Click);
            // 
            // حذفسربرگToolStripMenuItem
            // 
            this.حذفسربرگToolStripMenuItem.Name = "حذفسربرگToolStripMenuItem";
            this.حذفسربرگToolStripMenuItem.Size = new System.Drawing.Size(169, 24);
            this.حذفسربرگToolStripMenuItem.Text = "حذف سربرگ";
            this.حذفسربرگToolStripMenuItem.Click += new System.EventHandler(this.حذفسربرگToolStripMenuItem_Click);
            // 
            // ویرایشسربرگToolStripMenuItem
            // 
            this.ویرایشسربرگToolStripMenuItem.Name = "ویرایشسربرگToolStripMenuItem";
            this.ویرایشسربرگToolStripMenuItem.Size = new System.Drawing.Size(169, 24);
            this.ویرایشسربرگToolStripMenuItem.Text = "ویرایش سربرگ";
            this.ویرایشسربرگToolStripMenuItem.Click += new System.EventHandler(this.ویرایشسربرگToolStripMenuItem_Click);
            // 
            // OtherDoc
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(846, 438);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textEdit);
            this.Controls.Add(this.gridControl1);
            this.Font = new System.Drawing.Font("Vazir", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "OtherDoc";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "سربرگ اسناد متفرقه";
            this.Load += new System.EventHandler(this.OtherDoc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit.Properties)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage2;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraEditors.TextEdit textEdit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem افزودنسربرگToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ویرایشسربرگToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem حذفسربرگToolStripMenuItem;
    }
}