﻿namespace Box.Forms.OtherDoc
{
    partial class HesabOtherDoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.textEdit1 = new DevExpress.XtraEditors.TextEdit();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lable3 = new System.Windows.Forms.Label();
            this.lableSumOfdocument = new System.Windows.Forms.Label();
            this.labelSumVariz = new System.Windows.Forms.Label();
            this.LableSumBardasht = new System.Windows.Forms.Label();
            this.labelMande = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.تعریفسندجدیدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ویرایشسندToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.حذفسندToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.وروداکسلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.حذفاکسلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(778, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "جمع واریز:";
            // 
            // textEdit1
            // 
            this.textEdit1.Location = new System.Drawing.Point(91, 40);
            this.textEdit1.Name = "textEdit1";
            this.textEdit1.Size = new System.Drawing.Size(254, 22);
            this.textEdit1.TabIndex = 1;
            this.textEdit1.TextChanged += new System.EventHandler(this.textEdit1_TextChanged);
            // 
            // gridControl1
            // 
            this.gridControl1.Location = new System.Drawing.Point(12, 157);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(1122, 495);
            this.gridControl1.TabIndex = 2;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.RowCellDefaultAlignment += new DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventHandler(this.gridView1_RowCellDefaultAlignment);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(795, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 24);
            this.label2.TabIndex = 0;
            this.label2.Text = "مانده:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(778, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 24);
            this.label3.TabIndex = 0;
            this.label3.Text = "جمع برداشت:";
            // 
            // lable3
            // 
            this.lable3.AutoSize = true;
            this.lable3.Location = new System.Drawing.Point(730, 4);
            this.lable3.Name = "lable3";
            this.lable3.Size = new System.Drawing.Size(160, 24);
            this.lable3.TabIndex = 0;
            this.lable3.Text = "تعداد سندهای ثبت شده:";
            // 
            // lableSumOfdocument
            // 
            this.lableSumOfdocument.AutoSize = true;
            this.lableSumOfdocument.Enabled = false;
            this.lableSumOfdocument.Location = new System.Drawing.Point(981, 9);
            this.lableSumOfdocument.Name = "lableSumOfdocument";
            this.lableSumOfdocument.Size = new System.Drawing.Size(18, 24);
            this.lableSumOfdocument.TabIndex = 3;
            this.lableSumOfdocument.Text = "0";
            this.lableSumOfdocument.Click += new System.EventHandler(this.lableSumOfdocument_Click);
            // 
            // labelSumVariz
            // 
            this.labelSumVariz.AutoSize = true;
            this.labelSumVariz.Enabled = false;
            this.labelSumVariz.Location = new System.Drawing.Point(981, 43);
            this.labelSumVariz.Name = "labelSumVariz";
            this.labelSumVariz.Size = new System.Drawing.Size(18, 24);
            this.labelSumVariz.TabIndex = 3;
            this.labelSumVariz.Text = "0";
            // 
            // LableSumBardasht
            // 
            this.LableSumBardasht.AutoSize = true;
            this.LableSumBardasht.Enabled = false;
            this.LableSumBardasht.Location = new System.Drawing.Point(981, 82);
            this.LableSumBardasht.Name = "LableSumBardasht";
            this.LableSumBardasht.Size = new System.Drawing.Size(18, 24);
            this.LableSumBardasht.TabIndex = 3;
            this.LableSumBardasht.Text = "0";
            // 
            // labelMande
            // 
            this.labelMande.AutoSize = true;
            this.labelMande.Enabled = false;
            this.labelMande.Location = new System.Drawing.Point(981, 121);
            this.labelMande.Name = "labelMande";
            this.labelMande.Size = new System.Drawing.Size(18, 24);
            this.labelMande.TabIndex = 3;
            this.labelMande.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(26, 38);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 24);
            this.label9.TabIndex = 4;
            this.label9.Text = "جستجو:";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.تعریفسندجدیدToolStripMenuItem,
            this.ویرایشسندToolStripMenuItem,
            this.حذفسندToolStripMenuItem,
            this.وروداکسلToolStripMenuItem,
            this.حذفاکسلToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextMenuStrip1.Size = new System.Drawing.Size(184, 124);
            // 
            // تعریفسندجدیدToolStripMenuItem
            // 
            this.تعریفسندجدیدToolStripMenuItem.Name = "تعریفسندجدیدToolStripMenuItem";
            this.تعریفسندجدیدToolStripMenuItem.Size = new System.Drawing.Size(183, 24);
            this.تعریفسندجدیدToolStripMenuItem.Text = "تعریف سند جدید";
            this.تعریفسندجدیدToolStripMenuItem.Click += new System.EventHandler(this.تعریفسندجدیدToolStripMenuItem_Click);
            // 
            // ویرایشسندToolStripMenuItem
            // 
            this.ویرایشسندToolStripMenuItem.Name = "ویرایشسندToolStripMenuItem";
            this.ویرایشسندToolStripMenuItem.Size = new System.Drawing.Size(183, 24);
            this.ویرایشسندToolStripMenuItem.Text = "ویرایش سند";
            this.ویرایشسندToolStripMenuItem.Click += new System.EventHandler(this.ویرایشسندToolStripMenuItem_Click);
            // 
            // حذفسندToolStripMenuItem
            // 
            this.حذفسندToolStripMenuItem.Name = "حذفسندToolStripMenuItem";
            this.حذفسندToolStripMenuItem.Size = new System.Drawing.Size(183, 24);
            this.حذفسندToolStripMenuItem.Text = "حذف سند";
            this.حذفسندToolStripMenuItem.Click += new System.EventHandler(this.حذفسندToolStripMenuItem_Click);
            // 
            // وروداکسلToolStripMenuItem
            // 
            this.وروداکسلToolStripMenuItem.Name = "وروداکسلToolStripMenuItem";
            this.وروداکسلToolStripMenuItem.Size = new System.Drawing.Size(183, 24);
            this.وروداکسلToolStripMenuItem.Text = "ورود اکسل";
            // 
            // حذفاکسلToolStripMenuItem
            // 
            this.حذفاکسلToolStripMenuItem.Name = "حذفاکسلToolStripMenuItem";
            this.حذفاکسلToolStripMenuItem.Size = new System.Drawing.Size(183, 24);
            this.حذفاکسلToolStripMenuItem.Text = "خروج اکسل";
            this.حذفاکسلToolStripMenuItem.Click += new System.EventHandler(this.حذفاکسلToolStripMenuItem_Click);
            // 
            // HesabOtherDoc
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1139, 656);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.label9);
            this.Controls.Add(this.labelMande);
            this.Controls.Add(this.LableSumBardasht);
            this.Controls.Add(this.labelSumVariz);
            this.Controls.Add(this.lableSumOfdocument);
            this.Controls.Add(this.gridControl1);
            this.Controls.Add(this.textEdit1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lable3);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Vazir", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "HesabOtherDoc";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "اسناد متفرقه";
            this.Load += new System.EventHandler(this.HesabOtherDoc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private DevExpress.XtraEditors.TextEdit textEdit1;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lable3;
        private System.Windows.Forms.Label lableSumOfdocument;
        private System.Windows.Forms.Label labelSumVariz;
        private System.Windows.Forms.Label LableSumBardasht;
        private System.Windows.Forms.Label labelMande;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem تعریفسندجدیدToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ویرایشسندToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem حذفسندToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem وروداکسلToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem حذفاکسلToolStripMenuItem;
    }
}