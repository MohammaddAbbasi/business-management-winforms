﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.Forms.Hesab;
using DevExpress.XtraGrid;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.OtherDoc
{
    public partial class HesabOtherDoc : DevExpress.XtraEditors.XtraForm
    {
        IDoc doc;
        int HeaderId;
        decimal sum = 0;
        decimal sumvariz1 = 0;
        decimal sumbardasht1 = 0;
        public HesabOtherDoc(int HeaderId)
        {
            doc = new DocServises();
            this.HeaderId = HeaderId;
            InitializeComponent();
        }

        private void HesabOtherDoc_Load(object sender, EventArgs e)
        {

            refresh();

            sumvariz1 = 0;
            sumbardasht1 = 0;

            lableSumOfdocument.Text = gridView1.DataRowCount.ToString();

            for (int A = 0; A < gridView1.DataRowCount; A++)
            {
                string value = Convert.ToString(
                    gridView1.GetRowCellValue(A, "Stats"));

                int money = Convert.ToInt32(
                    gridView1.GetRowCellValue(A, "Mony"));

                if (string.Equals(value?.Trim(), "واریز"))
                {
                    sumvariz1 += money;
                }
                else
                {
                    sumbardasht1 += money;
                }
            }

            labelSumVariz.Text = sumvariz1.ToString();
            LableSumBardasht.Text = sumbardasht1.ToString();

            sum = sumvariz1 - sumbardasht1;
            labelMande.Text = sum.ToString();

        }

        private void refresh()
        {
            gridControl1.DataSource = doc.GetAll(HeaderId, textEdit1.Text.Trim());
            gridView1.Columns[0].Visible = false;
            gridView1.Columns[1].Caption = "نام طرف حساب";
            gridView1.Columns[2].Caption = "وضعیت";
            gridView1.Columns[3].Caption = "مبلغ";
            gridView1.Columns[4].Caption = "شماره حساب";
            gridView1.Columns[5].Caption = "شماره شبا";
            gridView1.Columns["Mony"].DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            gridView1.Columns["Mony"].DisplayFormat.FormatString = "n0";
        }

        private void gridView1_RowCellDefaultAlignment(object sender, DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventArgs e)
        {
            e.HorzAlignment = DevExpress.Utils.HorzAlignment.Center;
        }

        private void تعریفسندجدیدToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewOderDoc newOderDoc = new NewOderDoc(0, HeaderId);
            newOderDoc.Show();
        }

        private void ویرایشسندToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int HesabIdEdit = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "HeaderId"));
            NewOderDoc newOderDoc = new NewOderDoc(HesabIdEdit, HeaderId);
            newOderDoc.Show();
        }

        private void حذفسندToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int HesabIdEdit = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "HeaderId"));
            DialogResult dialog = MessageBox.Show("آیا از حذف این کاربر مطمئن هستید؟", "پیغام", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dialog == DialogResult.OK)
            {
                if (doc.RemoveDoc(HesabIdEdit) == true)
                {
                    MessageBox.Show("کابر با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    refresh();
                }
                else
                {
                    MessageBox.Show("حذف اطلاعات با شکست مواجه شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void textEdit1_TextChanged(object sender, EventArgs e)
        {
            gridControl1.DataSource = doc.GetAll(HeaderId, textEdit1.Text?.Trim());
        }

        private void حذفاکسلToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Excel Files|*.xlsx";
            sfd.Title = "ذخیره فایل اکسل";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string path = sfd.FileName;

                gridView1.ExportToXlsx(path);

                MessageBox.Show("فایل با موفقیت ذخیره شد");
            }
        }

        private void lableSumOfdocument_Click(object sender, EventArgs e)
        {

        }
    }
}
