﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.Forms.Hesab;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.OtherDoc
{
    public partial class OtherDoc : DevExpress.XtraEditors.XtraForm
    {
        IHeaderHesabDoc headerHesab;
        public OtherDoc()
        {
            headerHesab = new HeaderHesabDocServises();
            InitializeComponent();
        }

        private void OtherDoc_Load(object sender, EventArgs e)
        {
            refresh();
        }

        private void refresh()
        {
            gridControl1.DataSource = headerHesab.GetAll(textEdit.Text?.Trim());
            gridView1.Columns[0].Visible = false;
            datatransfer();
            gridView1.Columns[1].Caption = "نام صاحب حساب";
            gridView1.Columns[2].Caption = "تعداد سندهای ثبت شده";
            gridView1.Columns[3].Caption = "مجموع واریز";
            gridView1.Columns[4].Caption = "مجموع برداشت";
            gridView1.Columns[5].Visible = false;
            gridView1.Columns[6].Caption = "تاریخ ثبت";
            gridView1.Columns["bardasht"].DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            gridView1.Columns["bardasht"].DisplayFormat.FormatString = "n0";
            gridView1.Columns["variz"].DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            gridView1.Columns["variz"].DisplayFormat.FormatString = "n0";

        }

        private void datatransfer()
        {
            if (gridView1.DataRowCount > 0)
            {
                for (int i = 0; i < gridView1.DataRowCount; i++)
                {
                    object SellectValue = gridView1.GetRowCellValue(i, "dateTime");
                    DateTime dateTime = Convert.ToDateTime(SellectValue);
                    PersianCalendar persian = new PersianCalendar();
                    string persianDate = persian.GetYear(dateTime) + "/" + persian.GetMonth(dateTime) + "/" + persian.GetDayOfMonth(dateTime);
                    gridView1.SetRowCellValue(i, "dateTimetostring", persianDate);

                }
            }
        }

        private void افزودنسربرگToolStripMenuItem_Click(object sender, EventArgs e)
        {
            New_OtherDoc new_OtherDoc = new New_OtherDoc(0);
            new_OtherDoc.ShowDialog();
        }

        private void ویرایشسربرگToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int HeaderId = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "HeaderId"));
            New_OtherDoc new_OtherDoc = new New_OtherDoc(HeaderId);
            new_OtherDoc.ShowDialog();
        }

        private void حذفسربرگToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int HeaderId = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "HeaderId"));
            DialogResult dialog = MessageBox.Show("آیا از حذف این کاربر مطمئن هستید؟", "پیغام", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dialog == DialogResult.OK)
            {
                if (headerHesab.DeleteHeaderHesabDoc(HeaderId) == true)
                {
                    MessageBox.Show("کابر با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    refresh();
                }
                else
                {
                    MessageBox.Show("حذف اطلاعات با شکست مواجه شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void textEdit_TextChanged(object sender, EventArgs e)
        {
            gridControl1.DataSource = headerHesab.GetAll(textEdit.Text?.Trim());
            gridView1.Columns[0].Visible = false;
            gridView1.Columns[1].Caption = "عنوان";
            gridView1.Columns[2].Caption = "تعداد";
            gridView1.Columns[3].Caption = "مجموع واریز";
            gridView1.Columns[4].Caption = "مجموع برداشت";
            gridView1.Columns[5].Caption = "تاریخ ثبت";
        }

        private void gridView1_DoubleClick(object sender, EventArgs e)
        {
            if (gridView1.DataRowCount > 0)
            {
                try
                {
                    int index = gridView1.FocusedRowHandle;
                    int id = Convert.ToInt32(gridView1.GetRowCellValue(index, "HeaderId"));
                    HesabOtherDoc hesabOtherDoc = new HesabOtherDoc(id);
                    hesabOtherDoc.ShowDialog();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void gridView1_RowCellDefaultAlignment(object sender, DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventArgs e)
        {
            e.HorzAlignment = DevExpress.Utils.HorzAlignment.Center;
        }
    }
}
