﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.OtherDoc
{
    public partial class New_OtherDoc : DevExpress.XtraEditors.XtraForm
    {
        IHeaderHesabDoc headerHesab;
        int EditId;
        public New_OtherDoc(int EditId)
        {
            headerHesab = new HeaderHesabDocServises();
            this.EditId = EditId;
            InitializeComponent();
        }

        private void New_OtherDoc_Load(object sender, EventArgs e)
        {
            if (EditId != 0)
            {
                var getDoc = headerHesab.getHeaderById(EditId);
                textEdit1.Text = getDoc.Title;
                this.Text = "ویرایش سربرگ اسناد متفرقه";
            }
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textEdit1.Text))
            {
                MessageBox.Show("لطفا مقادیر را بصورت کامل پر کنید", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
                if (EditId == 0)
            {
                HeaderDocOdervViewModel headerDocOdervViewModel = new HeaderDocOdervViewModel();
                headerDocOdervViewModel.title = textEdit1.Text;
                headerDocOdervViewModel.dateTime = farsiCalendar1.Value.GregorianSelectedDate;
                if (headerHesab.AddHeaderHesabDoc(headerDocOdervViewModel) == true)
                {
                    MessageBox.Show("ثبت اطلاعات با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("ثبت اطلاعات با شکست مواجه شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
            }
            else
            {
                HeaderDocOdervViewModel headerDocOdervViewModel = new HeaderDocOdervViewModel();
                headerDocOdervViewModel.title = textEdit1.Text;
                headerDocOdervViewModel.dateTime = farsiCalendar1.Value.GregorianSelectedDate;
                headerDocOdervViewModel.Headid = EditId;
                if (headerHesab.EditHeaderHesabDoc(headerDocOdervViewModel) == true)
                {
                    MessageBox.Show("ویرایش اطلاعات با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("ویرایش اطلاعات با شکست مواجه شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
