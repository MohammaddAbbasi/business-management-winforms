﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Semat
{
    public partial class Semat_List : DevExpress.XtraEditors.XtraForm
    {
        ISemat semat;
        public Semat_List()
        {
            semat = new SematServise();
            InitializeComponent();
        }

        private void Semat_List_Load(object sender, EventArgs e)
        {
            gridControl.ContextMenuStrip = contextMenuStrip1;
            refresh();

        }

        private void refresh()
        {
            gridControl.DataSource = semat.GetAll();
            gridView1.Columns[0].Visible = false;
            gridView1.Columns[1].Caption = " سمت:";
            gridView1.Columns[2].Caption = " پرسنل";
            gridView1.Columns[3].Caption = "واحد";
            gridView1.Columns[4].Caption = "وضعیت";

        }

        private void افزودنToolStripMenuItem_Click(object sender, EventArgs e)
        {
            New_Semat new_Semat = new New_Semat(0);
            new_Semat.ShowDialog();
        }

        private void ویرایشToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int SematId = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "sematID"));
            New_Semat new_Semat = new New_Semat(SematId);
            new_Semat.ShowDialog();
        }

        private void حذفToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int SematId = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "sematID"));
            DialogResult dialog = MessageBox.Show("آیا از حذف این کاربر مطمئن هستید؟", "پیغام", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dialog == DialogResult.OK)
            {
                if (semat.DeleteSemat(SematId) == true)
                {
                    MessageBox.Show("کابر با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    refresh();
                }
                else
                {
                    MessageBox.Show("اطلاعات با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void gridView1_RowCellDefaultAlignment(object sender, DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventArgs e)
        {
            e.HorzAlignment = DevExpress.Utils.HorzAlignment.Center;

        }
    }
}
