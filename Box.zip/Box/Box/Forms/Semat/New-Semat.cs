﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.DTOs.ViewModel;
using DevExpress.XtraGrid;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Semat
{
    public partial class New_Semat : DevExpress.XtraEditors.XtraForm
    {
        ISemat Semat;
        int Sematid;
        public New_Semat(int Sematid)
        {
            Semat = new SematServise();
            this.Sematid = Sematid;
            InitializeComponent();
        }

        private void New_Semat_Load(object sender, EventArgs e)
        {
            var res = Semat.GetPersonal();
            var result = Semat.GetVahed();
            if (Sematid == 0)
            {
                comboBox.DataSource = res.ToList(); 
                comboBox.ValueMember = "Id";
                comboBox.DisplayMember = "FullName";
                comboBox1.DataSource = result.ToList();
                comboBox1.ValueMember = "VahedId";
                comboBox1.DisplayMember = "VahedTitle";
            }
            else
            {
                this.Text = "ویرایش سمت";
                var Smt = Semat.GetSemayByID(Sematid);
                txtSematName.Text = Smt.SematName;
                comboBox.Enabled = false;
                comboBox1.DataSource = result.ToList();
                comboBox1.ValueMember = "VahedId";
                comboBox1.DisplayMember = "VahedTitle";

            }
        }

        private void btnSubject_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSematName.Text))
            {
                MessageBox.Show("اطلاعات را کامل وارد کنید", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (Sematid == 0)
                {
                    SematViewModel semat = new SematViewModel();
                    semat.SematName = txtSematName.Text;
                    semat.Vahed_Id = Convert.ToInt32(comboBox1.SelectedValue);
                    semat.PersonalId = Convert.ToInt32(comboBox.SelectedValue);
                    semat.Status = GetState();
                    if (Semat.AddSemat(semat) == true)
                    {
                        MessageBox.Show("ثبت نام با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("اطلاعات  ثبت نشد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    SematViewModel sematViewModel = new SematViewModel();
                    sematViewModel.SematName = txtSematName.Text;
                    sematViewModel.Status = GetState();
                    sematViewModel.PersonalId = Convert.ToInt32(comboBox.SelectedValue);
                    sematViewModel.Vahed_Id = Convert.ToInt32(comboBox.SelectedValue); ;
                    sematViewModel.SematId = Sematid;
                    if (Semat.UpdateSemat(sematViewModel) == true)
                    {
                        MessageBox.Show("ویرایش با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("اطلاعات ویرایش نشد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private int GetState()
        {
            if (radioButtonActive.Checked)
                return 1;
            if (radioButtonDeactive.Checked)
                return 2;
            return 0;
        }
    }
}

