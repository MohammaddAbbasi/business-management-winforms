﻿namespace Box.Forms.Semat
{
    partial class New_Semat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSematName = new DevExpress.XtraEditors.TextEdit();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.radioButtonActive = new System.Windows.Forms.RadioButton();
            this.radioButtonDeactive = new System.Windows.Forms.RadioButton();
            this.comboBox = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.BtnCancell = new DevExpress.XtraEditors.SimpleButton();
            this.btnSubject = new DevExpress.XtraEditors.SimpleButton();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.txtSematName.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSematName
            // 
            this.txtSematName.Location = new System.Drawing.Point(128, 38);
            this.txtSematName.Name = "txtSematName";
            this.txtSematName.Size = new System.Drawing.Size(191, 22);
            this.txtSematName.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "عنوان سمت:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "انتخاب پرسنل:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 208);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 24);
            this.label3.TabIndex = 1;
            this.label3.Text = "وضعیت پرسنل:";
            // 
            // radioButtonActive
            // 
            this.radioButtonActive.AutoSize = true;
            this.radioButtonActive.Location = new System.Drawing.Point(147, 208);
            this.radioButtonActive.Name = "radioButtonActive";
            this.radioButtonActive.Size = new System.Drawing.Size(61, 28);
            this.radioButtonActive.TabIndex = 2;
            this.radioButtonActive.TabStop = true;
            this.radioButtonActive.Text = "فعال";
            this.radioButtonActive.UseVisualStyleBackColor = true;
            // 
            // radioButtonDeactive
            // 
            this.radioButtonDeactive.AutoSize = true;
            this.radioButtonDeactive.Location = new System.Drawing.Point(214, 208);
            this.radioButtonDeactive.Name = "radioButtonDeactive";
            this.radioButtonDeactive.Size = new System.Drawing.Size(84, 28);
            this.radioButtonDeactive.TabIndex = 3;
            this.radioButtonDeactive.TabStop = true;
            this.radioButtonDeactive.Text = " غیرفعال";
            this.radioButtonDeactive.UseVisualStyleBackColor = true;
            // 
            // comboBox
            // 
            this.comboBox.FormattingEnabled = true;
            this.comboBox.Location = new System.Drawing.Point(128, 120);
            this.comboBox.Name = "comboBox";
            this.comboBox.Size = new System.Drawing.Size(191, 32);
            this.comboBox.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 295);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 24);
            this.label4.TabIndex = 1;
            this.label4.Text = "انتخاب واحد:";
            // 
            // BtnCancell
            // 
            this.BtnCancell.Location = new System.Drawing.Point(125, 352);
            this.BtnCancell.Name = "BtnCancell";
            this.BtnCancell.Size = new System.Drawing.Size(94, 29);
            this.BtnCancell.TabIndex = 5;
            this.BtnCancell.Text = "انصراف";
            // 
            // btnSubject
            // 
            this.btnSubject.Location = new System.Drawing.Point(225, 352);
            this.btnSubject.Name = "btnSubject";
            this.btnSubject.Size = new System.Drawing.Size(94, 29);
            this.btnSubject.TabIndex = 4;
            this.btnSubject.Text = "ثبت";
            this.btnSubject.Click += new System.EventHandler(this.btnSubject_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(128, 292);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(191, 32);
            this.comboBox1.TabIndex = 3;
            // 
            // New_Semat
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(357, 406);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btnSubject);
            this.Controls.Add(this.BtnCancell);
            this.Controls.Add(this.comboBox);
            this.Controls.Add(this.radioButtonDeactive);
            this.Controls.Add(this.radioButtonActive);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSematName);
            this.Font = new System.Drawing.Font("Vazir", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "New_Semat";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "اضافه کردن سمت ها";
            this.Load += new System.EventHandler(this.New_Semat_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtSematName.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.TextEdit txtSematName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton radioButtonActive;
        private System.Windows.Forms.RadioButton radioButtonDeactive;
        private System.Windows.Forms.ComboBox comboBox;
        private System.Windows.Forms.Label label4;
        private DevExpress.XtraEditors.SimpleButton BtnCancell;
        private DevExpress.XtraEditors.SimpleButton btnSubject;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}