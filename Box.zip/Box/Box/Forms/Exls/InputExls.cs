﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Exls
{
    public partial class ExportBox : DevExpress.XtraEditors.XtraForm
    {
        public ExportBox()
        {
            InitializeComponent();
        }

        private void ExportBox_Load(object sender, EventArgs e)
        {

        }
    }
}
