﻿using Box.DTOs;
using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.Forms.Box;
using Box.Forms.Company;
using Box.Forms.Employee_form;
using Box.Forms.Exls;
using Box.Forms.Export;
using Box.Forms.ExportNumber1;
using Box.Forms.OtherDoc;
using Box.Forms.Qest;
using Box.Forms.Semat;
using Box.Forms.TarafHesab;
using Box.Forms.Vahed;
using Box.Forms.Vam;
using DevExpress.XtraBars.Ribbon;
using DevExpress.XtraGrid;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box
{
    public partial class Form2 : DevExpress.XtraBars.Ribbon.RibbonForm
    {
        IEmployee employee;
        ICompany company;
        public Form2()
        {
            employee = new EmployeeServise();
            company = new CompanyServise();
            InitializeComponent();
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            //gridControlView.ContextMenuStrip = contextMenuStrip1;
        }


        private void Item_Insert(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Company_Form company_Form = new Company_Form(0);
            company_Form.ShowDialog();
        }

        private void itemshowlistperson(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Employee_lIST employee_LIST = new Employee_lIST();
            employee_LIST.ShowDialog();

        }

        private void Export_List(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        private void ListCompany(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            CompanyList companyList = new CompanyList();
            companyList.ShowDialog();
        }
        private void ListSemat_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Semat_List semat_List = new Semat_List();
            semat_List.ShowDialog();
        }

        private void ButtonListVaheds_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            ListVahed listVahed = new ListVahed();
            listVahed.ShowDialog();
        }

        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            TarafHesabList tarafHesabList = new TarafHesabList();
            tarafHesabList.ShowDialog();
        }

        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Box_list box_List = new Box_list();
            box_List.ShowDialog();
        }

        private void barButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            List_Vam list_Vam = new List_Vam();
            list_Vam.ShowDialog();
        }

        private void barButtonItem4_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Qest_List qest_List = new Qest_List();
            qest_List.ShowDialog();
        }

        private void OtherDocument_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            OtherDoc otherDoc = new OtherDoc();
            otherDoc.ShowDialog();
        }

        private void ButtonExport_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            ExportNumber1 exportNumber1 = new ExportNumber1();
            exportNumber1.ShowDialog();
        }

        private void ButtonExportVam_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            ExporVam exporVam = new ExporVam(2);
            exporVam.ShowDialog();
        }

        private void barButtonItemBox_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            ExporVam exporVam = new ExporVam(1);
            exporVam.ShowDialog();
        }

        private void barButtonItemqest_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            ExporVam exporVam = new ExporVam(3);
            exporVam.ShowDialog();
        }

        private void barButtonItem5_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            ExportAll exportAll = new ExportAll();
            exportAll.ShowDialog();
        }

        private void barButtonItem6_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            ActionExport actionExport = new ActionExport();
            actionExport.ShowDialog();
        }

        private void barButtonItem7_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            ExportVahed exportVahed = new ExportVahed();
            exportVahed.ShowDialog();
        }

        private void barButtonItem8_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            ExportAllsemat exportAllPerPersonall = new ExportAllsemat();
            exportAllPerPersonall.ShowDialog();
        }

        private void barButtonItemBox_ItemDoubleClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }

        private void barButtonItem9_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            TarafHesab tarafHesab = new TarafHesab();
            tarafHesab.ShowDialog();
        }
    }
}

