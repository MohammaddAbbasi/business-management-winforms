﻿namespace Box
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.rControle = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.insertEmployee_btn = new DevExpress.XtraBars.BarButtonItem();
            this.ListEmployeeShow = new DevExpress.XtraBars.BarButtonItem();
            this.Export = new DevExpress.XtraBars.BarButtonItem();
            this.ListShowCompany = new DevExpress.XtraBars.BarButtonItem();
            this.ListCompanyShow = new DevExpress.XtraBars.BarButtonItem();
            this.Btn_ShowList = new DevExpress.XtraBars.BarButtonItem();
            this.ListSemat = new DevExpress.XtraBars.BarButtonItem();
            this.ButtonListVaheds = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem4 = new DevExpress.XtraBars.BarButtonItem();
            this.OtherDocument = new DevExpress.XtraBars.BarButtonItem();
            this.ButtonExport = new DevExpress.XtraBars.BarButtonItem();
            this.ButtonExportVam = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItemBox = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItemqest = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem6 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem7 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem8 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem9 = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPageCategory1 = new DevExpress.XtraBars.Ribbon.RibbonPageCategory();
            this.ribbonPagePersonList = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rBInsert = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.Company = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup3 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage5 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup5 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.گزارشات = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup4 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.toolbarFormManager1 = new DevExpress.XtraBars.ToolbarForm.ToolbarFormManager(this.components);
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.ribbonPage2 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            ((System.ComponentModel.ISupportInitialize)(this.rControle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.toolbarFormManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // rControle
            // 
            this.rControle.EmptyAreaImageOptions.ImagePadding = new System.Windows.Forms.Padding(42, 71, 42, 71);
            this.rControle.ExpandCollapseItem.Id = 0;
            this.rControle.Font = new System.Drawing.Font("Vazir", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rControle.ForeColor = System.Drawing.Color.White;
            this.rControle.HeaderAreaImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("rControle.HeaderAreaImageOptions.SvgImage")));
            this.rControle.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.rControle.ExpandCollapseItem,
            this.insertEmployee_btn,
            this.ListEmployeeShow,
            this.Export,
            this.ListShowCompany,
            this.ListCompanyShow,
            this.Btn_ShowList,
            this.ListSemat,
            this.ButtonListVaheds,
            this.barButtonItem1,
            this.barButtonItem2,
            this.barButtonItem3,
            this.barButtonItem4,
            this.OtherDocument,
            this.ButtonExport,
            this.ButtonExportVam,
            this.barButtonItemBox,
            this.barButtonItemqest,
            this.barButtonItem5,
            this.barButtonItem6,
            this.barButtonItem7,
            this.barButtonItem8,
            this.barButtonItem9});
            this.rControle.Location = new System.Drawing.Point(0, 0);
            this.rControle.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.rControle.MaxItemId = 25;
            this.rControle.Name = "rControle";
            this.rControle.OptionsMenuMinWidth = 471;
            this.rControle.PageCategories.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageCategory[] {
            this.ribbonPageCategory1});
            this.rControle.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPagePersonList,
            this.Company,
            this.ribbonPage,
            this.ribbonPage1,
            this.ribbonPage5,
            this.گزارشات});
            this.rControle.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonControlStyle.OfficeUniversal;
            this.rControle.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.rControle.ShowApplicationButton = DevExpress.Utils.DefaultBoolean.False;
            this.rControle.ShowExpandCollapseButton = DevExpress.Utils.DefaultBoolean.False;
            this.rControle.Size = new System.Drawing.Size(1022, 133);
            // 
            // insertEmployee_btn
            // 
            this.insertEmployee_btn.Caption = " ثبت کاربر جدید";
            this.insertEmployee_btn.Id = 1;
            this.insertEmployee_btn.Name = "insertEmployee_btn";
            this.insertEmployee_btn.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.Item_Insert);
            // 
            // ListEmployeeShow
            // 
            this.ListEmployeeShow.Caption = "نمایش لیست کاربران";
            this.ListEmployeeShow.Id = 2;
            this.ListEmployeeShow.Name = "ListEmployeeShow";
            this.ListEmployeeShow.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemshowlistperson);
            // 
            // Export
            // 
            this.Export.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.Export.Caption = "خروجی لیست";
            this.Export.Id = 3;
            this.Export.Name = "Export";
            this.Export.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.Export_List);
            // 
            // ListShowCompany
            // 
            this.ListShowCompany.Id = 5;
            this.ListShowCompany.Name = "ListShowCompany";
            // 
            // ListCompanyShow
            // 
            this.ListCompanyShow.Id = 7;
            this.ListCompanyShow.Name = "ListCompanyShow";
            // 
            // Btn_ShowList
            // 
            this.Btn_ShowList.Caption = "نمایش لیست شرکت";
            this.Btn_ShowList.Id = 8;
            this.Btn_ShowList.Name = "Btn_ShowList";
            this.Btn_ShowList.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ListCompany);
            // 
            // ListSemat
            // 
            this.ListSemat.Caption = "لیست سمت ها";
            this.ListSemat.Id = 9;
            this.ListSemat.Name = "ListSemat";
            this.ListSemat.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ListSemat_ItemClick);
            // 
            // ButtonListVaheds
            // 
            this.ButtonListVaheds.Caption = "لیست واحدها";
            this.ButtonListVaheds.Id = 10;
            this.ButtonListVaheds.Name = "ButtonListVaheds";
            this.ButtonListVaheds.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ButtonListVaheds_ItemClick);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "لیست طرف حساب";
            this.barButtonItem1.Id = 11;
            this.barButtonItem1.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem1.ImageOptions.SvgImage")));
            this.barButtonItem1.Name = "barButtonItem1";
            this.barButtonItem1.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem1_ItemClick);
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "مدریت صندوق";
            this.barButtonItem2.Id = 12;
            this.barButtonItem2.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem2.ImageOptions.SvgImage")));
            this.barButtonItem2.Name = "barButtonItem2";
            this.barButtonItem2.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem2_ItemClick);
            // 
            // barButtonItem3
            // 
            this.barButtonItem3.Caption = "مدریت وام";
            this.barButtonItem3.Id = 13;
            this.barButtonItem3.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem3.ImageOptions.SvgImage")));
            this.barButtonItem3.Name = "barButtonItem3";
            this.barButtonItem3.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem3_ItemClick);
            // 
            // barButtonItem4
            // 
            this.barButtonItem4.Caption = "مدریت اقساط";
            this.barButtonItem4.Id = 14;
            this.barButtonItem4.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem4.ImageOptions.SvgImage")));
            this.barButtonItem4.Name = "barButtonItem4";
            this.barButtonItem4.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem4_ItemClick);
            // 
            // OtherDocument
            // 
            this.OtherDocument.Caption = "مدریت اسناد متفرقه";
            this.OtherDocument.Id = 15;
            this.OtherDocument.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("OtherDocument.ImageOptions.SvgImage")));
            this.OtherDocument.Name = "OtherDocument";
            this.OtherDocument.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.OtherDocument_ItemClick);
            // 
            // ButtonExport
            // 
            this.ButtonExport.Caption = "گزارش شماره1";
            this.ButtonExport.Id = 16;
            this.ButtonExport.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("ButtonExport.ImageOptions.SvgImage")));
            this.ButtonExport.Name = "ButtonExport";
            this.ButtonExport.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ButtonExport_ItemClick);
            // 
            // ButtonExportVam
            // 
            this.ButtonExportVam.Caption = "گزارش وام";
            this.ButtonExportVam.Id = 17;
            this.ButtonExportVam.Name = "ButtonExportVam";
            this.ButtonExportVam.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ButtonExportVam_ItemClick);
            // 
            // barButtonItemBox
            // 
            this.barButtonItemBox.Caption = "گزارش صندوق";
            this.barButtonItemBox.Id = 18;
            this.barButtonItemBox.Name = "barButtonItemBox";
            this.barButtonItemBox.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItemBox_ItemClick);
            this.barButtonItemBox.ItemDoubleClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItemBox_ItemDoubleClick);
            // 
            // barButtonItemqest
            // 
            this.barButtonItemqest.Caption = "گزارش قسط";
            this.barButtonItemqest.Id = 19;
            this.barButtonItemqest.Name = "barButtonItemqest";
            this.barButtonItemqest.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItemqest_ItemClick);
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Caption = "گزارش جامع";
            this.barButtonItem5.Id = 20;
            this.barButtonItem5.Name = "barButtonItem5";
            this.barButtonItem5.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem5_ItemClick);
            // 
            // barButtonItem6
            // 
            this.barButtonItem6.Caption = "عملیات تسویه";
            this.barButtonItem6.Id = 21;
            this.barButtonItem6.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem6.ImageOptions.SvgImage")));
            this.barButtonItem6.Name = "barButtonItem6";
            this.barButtonItem6.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem6_ItemClick);
            // 
            // barButtonItem7
            // 
            this.barButtonItem7.Caption = "گزارش بر اساس واحد";
            this.barButtonItem7.Id = 22;
            this.barButtonItem7.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem7.ImageOptions.SvgImage")));
            this.barButtonItem7.Name = "barButtonItem7";
            this.barButtonItem7.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem7_ItemClick);
            // 
            // barButtonItem8
            // 
            this.barButtonItem8.Caption = "گزارش کلی";
            this.barButtonItem8.Id = 23;
            this.barButtonItem8.Name = "barButtonItem8";
            this.barButtonItem8.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem8_ItemClick);
            // 
            // barButtonItem9
            // 
            this.barButtonItem9.Caption = "گزارش طرف حساب ها";
            this.barButtonItem9.Id = 24;
            this.barButtonItem9.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem9.ImageOptions.SvgImage")));
            this.barButtonItem9.Name = "barButtonItem9";
            this.barButtonItem9.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem9_ItemClick);
            // 
            // ribbonPageCategory1
            // 
            this.ribbonPageCategory1.Name = "ribbonPageCategory1";
            this.ribbonPageCategory1.Text = "ribbonPageCategory1";
            // 
            // ribbonPagePersonList
            // 
            this.ribbonPagePersonList.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rBInsert});
            this.ribbonPagePersonList.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("ribbonPagePersonList.ImageOptions.SvgImage")));
            this.ribbonPagePersonList.Name = "ribbonPagePersonList";
            this.ribbonPagePersonList.Text = "لیست کاربران";
            // 
            // rBInsert
            // 
            this.rBInsert.ItemLinks.Add(this.ListEmployeeShow, true);
            this.rBInsert.Name = "rBInsert";
            this.rBInsert.Text = "ribbonPageGroup4";
            // 
            // Company
            // 
            this.Company.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup1});
            this.Company.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("Company.ImageOptions.Image")));
            this.Company.Name = "Company";
            this.Company.Text = "شرکت";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.ListShowCompany);
            this.ribbonPageGroup1.ItemLinks.Add(this.Btn_ShowList);
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "ribbonPageGroup1";
            // 
            // ribbonPage
            // 
            this.ribbonPage.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup2});
            this.ribbonPage.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("ribbonPage.ImageOptions.SvgImage")));
            this.ribbonPage.Name = "ribbonPage";
            this.ribbonPage.Text = "واحدها";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.ItemLinks.Add(this.ListSemat);
            this.ribbonPageGroup2.ItemLinks.Add(this.ButtonListVaheds);
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.Text = "ribbonPageGroup2";
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup3});
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "طرف حساب";
            // 
            // ribbonPageGroup3
            // 
            this.ribbonPageGroup3.ItemLinks.Add(this.barButtonItem1);
            this.ribbonPageGroup3.Name = "ribbonPageGroup3";
            this.ribbonPageGroup3.Text = "ribbonPageGroup3";
            // 
            // ribbonPage5
            // 
            this.ribbonPage5.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup5});
            this.ribbonPage5.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("ribbonPage5.ImageOptions.SvgImage")));
            this.ribbonPage5.Name = "ribbonPage5";
            this.ribbonPage5.Text = "عملیات ";
            // 
            // ribbonPageGroup5
            // 
            this.ribbonPageGroup5.ItemLinks.Add(this.barButtonItem2);
            this.ribbonPageGroup5.ItemLinks.Add(this.barButtonItem3);
            this.ribbonPageGroup5.ItemLinks.Add(this.barButtonItem4);
            this.ribbonPageGroup5.ItemLinks.Add(this.OtherDocument);
            this.ribbonPageGroup5.ItemLinks.Add(this.barButtonItem6);
            this.ribbonPageGroup5.Name = "ribbonPageGroup5";
            this.ribbonPageGroup5.Text = "ribbonPageGroup5";
            // 
            // گزارشات
            // 
            this.گزارشات.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup4});
            this.گزارشات.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("گزارشات.ImageOptions.SvgImage")));
            this.گزارشات.Name = "گزارشات";
            this.گزارشات.Text = "گزارشات";
            // 
            // ribbonPageGroup4
            // 
            this.ribbonPageGroup4.ItemLinks.Add(this.ButtonExport);
            this.ribbonPageGroup4.ItemLinks.Add(this.ButtonExportVam);
            this.ribbonPageGroup4.ItemLinks.Add(this.barButtonItemBox);
            this.ribbonPageGroup4.ItemLinks.Add(this.barButtonItemqest);
            this.ribbonPageGroup4.ItemLinks.Add(this.barButtonItem5);
            this.ribbonPageGroup4.ItemLinks.Add(this.barButtonItem7);
            this.ribbonPageGroup4.ItemLinks.Add(this.barButtonItem8);
            this.ribbonPageGroup4.ItemLinks.Add(this.barButtonItem9);
            this.ribbonPageGroup4.Name = "ribbonPageGroup4";
            this.ribbonPageGroup4.Text = "ribbonPageGroup4";
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Manager = this.toolbarFormManager1;
            this.barDockControlTop.Size = new System.Drawing.Size(1022, 0);
            // 
            // toolbarFormManager1
            // 
            this.toolbarFormManager1.DockControls.Add(this.barDockControlTop);
            this.toolbarFormManager1.DockControls.Add(this.barDockControlBottom);
            this.toolbarFormManager1.DockControls.Add(this.barDockControlLeft);
            this.toolbarFormManager1.DockControls.Add(this.barDockControlRight);
            this.toolbarFormManager1.Form = this;
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 693);
            this.barDockControlBottom.Manager = this.toolbarFormManager1;
            this.barDockControlBottom.Size = new System.Drawing.Size(1022, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 0);
            this.barDockControlLeft.Manager = this.toolbarFormManager1;
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 693);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(1022, 0);
            this.barDockControlRight.Manager = this.toolbarFormManager1;
            this.barDockControlRight.Size = new System.Drawing.Size(0, 693);
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "ribbonPage2";
            // 
            // Form2
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1022, 693);
            this.Controls.Add(this.rControle);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Font = new System.Drawing.Font("Vazir", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "Form2";
            this.Ribbon = this.rControle;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم پرسنلی";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.rControle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.toolbarFormManager1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage2;
        private DevExpress.XtraBars.ToolbarForm.ToolbarFormManager toolbarFormManager1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.Ribbon.RibbonControl rControle;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPagePersonList;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rBInsert;
        private DevExpress.XtraBars.Ribbon.RibbonPageCategory ribbonPageCategory1;
        private DevExpress.XtraBars.BarButtonItem insertEmployee_btn;
        private DevExpress.XtraBars.BarButtonItem ListEmployeeShow;
        private DevExpress.XtraBars.BarButtonItem Export;
        private DevExpress.XtraBars.BarButtonItem ListShowCompany;
        private DevExpress.XtraBars.Ribbon.RibbonPage Company;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.BarButtonItem ListCompanyShow;
        private DevExpress.XtraBars.BarButtonItem Btn_ShowList;
        private DevExpress.XtraBars.BarButtonItem ListSemat;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.BarButtonItem ButtonListVaheds;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup3;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage5;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup5;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
        private DevExpress.XtraBars.BarButtonItem barButtonItem4;
        private DevExpress.XtraBars.BarButtonItem OtherDocument;
        private DevExpress.XtraBars.BarButtonItem ButtonExport;
        private DevExpress.XtraBars.Ribbon.RibbonPage گزارشات;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup4;
        private DevExpress.XtraBars.BarButtonItem ButtonExportVam;
        private DevExpress.XtraBars.BarButtonItem barButtonItemBox;
        private DevExpress.XtraBars.BarButtonItem barButtonItemqest;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraBars.BarButtonItem barButtonItem6;
        private DevExpress.XtraBars.BarButtonItem barButtonItem7;
        private DevExpress.XtraBars.BarButtonItem barButtonItem8;
        private DevExpress.XtraBars.BarButtonItem barButtonItem9;
    }
}