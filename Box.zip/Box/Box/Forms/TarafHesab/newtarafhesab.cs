﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.TarafHesab
{
    public partial class newtarafhesab : DevExpress.XtraEditors.XtraForm
    {
        ITarafhesab tarafhesab;
        int TrafId;
        public newtarafhesab(int TrafId)
        {
            this.TrafId = TrafId;
            tarafhesab = new TarafServises();
            InitializeComponent();
        }

        private void ButtonCancell_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void newtarafhesab_Load(object sender, EventArgs e)
        {
            if (TrafId != 0)
            {
                this.Text = "ویرایش";
                 var Taraf=tarafhesab.GetTarafHesabByid(TrafId);
                txtCodeHesab.Text = Taraf.CodeHesab;
                txtName.Text = Taraf.NameTarafHesab;
                txtShebaCode.Text = Taraf.NumberSheba;
                txtShomareHesab.Text = Taraf.NumberHesab;
            }
        }

        private void ButtonSubjet_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodeHesab.Text) || string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtShebaCode.Text) || string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("اطلاعات را کامل وارد کنید", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
             if (TrafId == 0)
            {
                TarafHesabViewModel tarafHesabViewModel = new TarafHesabViewModel();
                tarafHesabViewModel.NameTarafHesab = txtName.Text;
                tarafHesabViewModel.NumberHesab = txtCodeHesab.Text;
                tarafHesabViewModel.CodeHesab = txtCodeHesab.Text;
                tarafHesabViewModel.NumberHesab = txtShomareHesab.Text;
                tarafHesabViewModel.NumberSheba = txtShebaCode.Text;
                if (tarafhesab.AddTarafHesab(tarafHesabViewModel) == true)
                {

                    MessageBox.Show("ثبت نام با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("اطلاعات  ثبت نشد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                TarafHesabViewModel tarafHesabViewModel = new TarafHesabViewModel();
                tarafHesabViewModel.TarafId = TrafId;
                tarafHesabViewModel.NameTarafHesab = txtName.Text;
                tarafHesabViewModel.CodeHesab = txtCodeHesab.Text;
                tarafHesabViewModel.NumberHesab = txtShomareHesab.Text;
                tarafHesabViewModel.NumberSheba = txtShebaCode.Text;
                if (tarafhesab.EditTarafHesab(tarafHesabViewModel) == true)
                {
                    MessageBox.Show("ویرایش با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("اطلاعات  ثبت نشد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
}
