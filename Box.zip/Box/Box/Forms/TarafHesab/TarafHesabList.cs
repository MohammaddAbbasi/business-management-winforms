﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using DevExpress.XtraGrid;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.TarafHesab
{
    public partial class TarafHesabList : DevExpress.XtraEditors.XtraForm
    {
        ITarafhesab tarafhesab;
        public TarafHesabList()
        {
            tarafhesab = new TarafServises();
            InitializeComponent();
        }

        private void TarafHesabList_Load(object sender, EventArgs e)
        {
            gridControl1.ContextMenuStrip = contextMenuStrip1;
            refresh();
            Refresh();

        }

        private void refresh()
        {
            gridControl1.DataSource = tarafhesab.GetAll();
            gridView1.Columns[0].Visible = false;
            gridView1.Columns[1].Caption = "کدحساب";
            gridView1.Columns[2].Caption = "نام طرف حساب";
            gridView1.Columns[3].Caption = "شماره حساب";
            gridView1.Columns[4].Caption = "شماره شبا";
        }

        private void افزودنToolStripMenuItem_Click(object sender, EventArgs e)
        {
            newtarafhesab newtarafhesab = new newtarafhesab(0);
            newtarafhesab.ShowDialog();

        }

        private void ویرایشToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int id = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "TarafId"));
            newtarafhesab newtarafhesab = new newtarafhesab(id);
            newtarafhesab.ShowDialog();
        }

        private void دلیتToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int id = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "TarafId"));
            DialogResult dialog = MessageBox.Show("آیا از حذف این کاربر مطمئن هستید؟", "پیغام", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dialog == DialogResult.OK)
            {
                if (tarafhesab.DeleteTarafHesab(id) == true)
                {
                    MessageBox.Show("کابر با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    refresh();
                }
                else
                {
                    MessageBox.Show("اطلاعات با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }

        }

        private void gridView1_RowCellDefaultAlignment(object sender, DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventArgs e)
        {
            e.HorzAlignment = DevExpress.Utils.HorzAlignment.Center;
        }
    }
}
