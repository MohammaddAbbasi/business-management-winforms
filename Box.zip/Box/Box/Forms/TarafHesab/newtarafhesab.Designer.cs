﻿namespace Box.Forms.TarafHesab
{
    partial class newtarafhesab
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCodeHesab = new DevExpress.XtraEditors.TextEdit();
            this.txtName = new DevExpress.XtraEditors.TextEdit();
            this.txtShebaCode = new DevExpress.XtraEditors.TextEdit();
            this.txtShomareHesab = new DevExpress.XtraEditors.TextEdit();
            this.ButtonSubjet = new DevExpress.XtraEditors.SimpleButton();
            this.ButtonCancell = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.txtCodeHesab.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShebaCode.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShomareHesab.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "شرکت/شخص:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(355, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "کد حساب:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "شماره شبا:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(334, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "شماره حساب:";
            // 
            // txtCodeHesab
            // 
            this.txtCodeHesab.Location = new System.Drawing.Point(449, 45);
            this.txtCodeHesab.Name = "txtCodeHesab";
            this.txtCodeHesab.Size = new System.Drawing.Size(180, 22);
            this.txtCodeHesab.TabIndex = 2;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(118, 45);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(175, 22);
            this.txtName.TabIndex = 1;
            // 
            // txtShebaCode
            // 
            this.txtShebaCode.Location = new System.Drawing.Point(118, 110);
            this.txtShebaCode.Name = "txtShebaCode";
            this.txtShebaCode.Size = new System.Drawing.Size(175, 22);
            this.txtShebaCode.TabIndex = 3;
            // 
            // txtShomareHesab
            // 
            this.txtShomareHesab.Location = new System.Drawing.Point(449, 110);
            this.txtShomareHesab.Name = "txtShomareHesab";
            this.txtShomareHesab.Size = new System.Drawing.Size(180, 22);
            this.txtShomareHesab.TabIndex = 4;
            // 
            // ButtonSubjet
            // 
            this.ButtonSubjet.Location = new System.Drawing.Point(494, 187);
            this.ButtonSubjet.Name = "ButtonSubjet";
            this.ButtonSubjet.Size = new System.Drawing.Size(94, 29);
            this.ButtonSubjet.TabIndex = 6;
            this.ButtonSubjet.Text = "ثبت";
            this.ButtonSubjet.Click += new System.EventHandler(this.ButtonSubjet_Click);
            // 
            // ButtonCancell
            // 
            this.ButtonCancell.Location = new System.Drawing.Point(338, 187);
            this.ButtonCancell.Name = "ButtonCancell";
            this.ButtonCancell.Size = new System.Drawing.Size(94, 29);
            this.ButtonCancell.TabIndex = 5;
            this.ButtonCancell.Text = "انصراف";
            this.ButtonCancell.Click += new System.EventHandler(this.ButtonCancell_Click);
            // 
            // newtarafhesab
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(677, 228);
            this.Controls.Add(this.ButtonCancell);
            this.Controls.Add(this.ButtonSubjet);
            this.Controls.Add(this.txtShomareHesab);
            this.Controls.Add(this.txtShebaCode);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.txtCodeHesab);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Vazir", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "newtarafhesab";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "طرف حساب جدید";
            this.Load += new System.EventHandler(this.newtarafhesab_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtCodeHesab.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShebaCode.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShomareHesab.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private DevExpress.XtraEditors.TextEdit txtCodeHesab;
        private DevExpress.XtraEditors.TextEdit txtName;
        private DevExpress.XtraEditors.TextEdit txtShebaCode;
        private DevExpress.XtraEditors.TextEdit txtShomareHesab;
        private DevExpress.XtraEditors.SimpleButton ButtonSubjet;
        private DevExpress.XtraEditors.SimpleButton ButtonCancell;
    }
}