﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.DTOs.ViewModel;
using Box.Forms.Action;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Export
{
    public partial class ActionExport : DevExpress.XtraEditors.XtraForm
    {
        
        IExport export;
        ITasvieh tasvieh;
        DateTime? fromDate;
        DateTime? toDate;
        public ActionExport()
        {
            export = new ExportServises();
            tasvieh = new TasviehServises();
            InitializeComponent();
        }

        private void checkBoxDate_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxDate.Checked)
            {
                farsiCalendar1.Visible = true;
                farsiCalendar2.Visible = true;
            }
            else
            {
                farsiCalendar1.Visible = false;
                farsiCalendar2.Visible = false;
            }
        }

        private void ActionExport_Load(object sender, EventArgs e)
        {
            var addSemat = export.GetSemat();
            addSemat.Insert(0, new SematShowViewModel
            {
                PersonalName = "همه",
                sematID = 999
            });
            comboBoxPersonall.DataSource = addSemat;
            comboBoxPersonall.DisplayMember = "PersonalName";
            comboBoxPersonall.ValueMember = "sematID";
        }

        private void خروجیاکسلToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Excel Files|*.xlsx";
            sfd.Title = "ذخیره فایل اکسل";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string path = sfd.FileName;

                gridView1.ExportToXlsx(path);

                MessageBox.Show("فایل با موفقیت ذخیره شد");
            }
        }

        private void افزودنتسویهجدیدToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddAction addAction = new AddAction(0);
            addAction.ShowDialog();
        }

        private void simpleButtonShow_Click(object sender, EventArgs e)
        {
            LoadData(checkBoxDate.Checked);
            fromDate = farsiCalendar1.Value?.GregorianSelectedDate;
            toDate = farsiCalendar2.Value?.GregorianSelectedDate;
            decimal SumVariz = 0;
            decimal SumBardasht = 0;
            for (int i = 0; i < gridView1.DataRowCount; i++)
            {
                var valueSumVam = gridView1.GetRowCellValue(i, "SumVariz");
                SumVariz += (decimal)valueSumVam;
                var valueSumBardasht = gridView1.GetRowCellValue(i, "SumBardasht");
                SumBardasht += (decimal)valueSumBardasht;
            }
            labelSumVariz.Text = SumVariz.ToString();
            LableSumBardasht.Text = SumBardasht.ToString();
            decimal Mande = SumVariz + SumBardasht;
            Tasvieh.Text = Mande.ToString();
            NumberFormatInfo nfi = new NumberFormatInfo();
            nfi.NumberGroupSeparator = ".";
            foreach (Control c in this.Controls)
            {
                if (c is Label lbl && long.TryParse(lbl.Text, out long num))
                {
                    lbl.Text = num.ToString("#,0", nfi);
                }
            }
        }

        private void LoadData(bool useDataFilter)
        {
            int personStatus = Convert.ToInt32(comboBoxPersonall.SelectedValue);
            if (personStatus == 999)
            {
                gridControl1.DataSource = useDataFilter
                    ? tasvieh.GetAll(null, fromDate, toDate)
                    : tasvieh.GetAll(null);
            }
            else
            {
                gridControl1.DataSource = useDataFilter
                    ? tasvieh.GetAll(personStatus, fromDate, toDate)
                    : tasvieh.GetAll(personStatus);
            }

            refresh();
        }

        private void refresh()
        {
            datatransfer();
            gridView1.Columns[1].Caption = "نام طرف حسب";
            gridView1.Columns[2].Caption = "عنوان سمت";
            gridView1.Columns[3].Caption = "ماهیت";
            gridView1.Columns[4].Caption = "مبلغ";
            gridView1.Columns[6].Caption = "تاریخ";
            gridView1.Columns["Money"].DisplayFormat.FormatType =
               DevExpress.Utils.FormatType.Numeric;
            gridView1.Columns["Money"].DisplayFormat.FormatString = "n0";
            gridView1.Columns[0].Visible = false;
            gridView1.Columns[5].Visible = false;
            gridView1.Columns[7].Visible = false;
            gridView1.Columns[8].Visible = false;
            gridView1.Columns[9].Visible = false;
            gridView1.Columns[10].Visible = false;
        }

        private void datatransfer()
        {
            if (gridView1.DataRowCount > 0)
            {
                for (int i = 0; i < gridView1.DataRowCount; i++)
                {
                    object SellectValue = gridView1.GetRowCellValue(i, "dateTime");
                    DateTime dateTime = Convert.ToDateTime(SellectValue);
                    PersianCalendar persian = new PersianCalendar();
                    string persianDate = persian.GetYear(dateTime) + "/" + persian.GetMonth(dateTime) + "/" + persian.GetDayOfMonth(dateTime);
                    gridView1.SetRowCellValue(i, "dateTimetostring", persianDate);
                }
            }
        }

        private void gridView1_RowCellDefaultAlignment(object sender, DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventArgs e)
        {
            e.HorzAlignment = DevExpress.Utils.HorzAlignment.Center;
        }

        private void ویرایشتسویهToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int groupid = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "TasvieId"));
            AddAction addAction = new AddAction(groupid);
            addAction.ShowDialog();

        }

        private void حذفتسویهToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int groupid = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "TasvieId"));
            DialogResult dialog = MessageBox.Show("آیا از حذف این کاربر مطمئن هستید؟", "پیغام", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dialog == DialogResult.OK)
            {
                if (tasvieh.DeleteTasvieh(groupid) == true)
                {
                    MessageBox.Show("کابر با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    refresh();
                }
                else
                {
                    MessageBox.Show("اطلاعات با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }
    }
}
