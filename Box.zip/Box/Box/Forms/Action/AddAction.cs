﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Action
{
    public partial class AddAction : DevExpress.XtraEditors.XtraForm
    {
        ITasvieh Tasvieh;
        IExport export;
        ISemat semat;
        int TasviehId;
        public AddAction(int TasviehId)
        {
            export = new ExportServises();
            Tasvieh = new TasviehServises();
            semat = new SematServise();
            this.TasviehId = TasviehId;
            InitializeComponent();
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AddAction_Load(object sender, EventArgs e)
        {
            if (TasviehId != 0)
            {
                var Tasvie = Tasvieh.Get(TasviehId);
                textBoxAbout.Text = Tasvie.DesCription;
                numericUpDownMony.Value = Tasvie.Money;
                comboBoxPersonall.Enabled = false;
            }
            var items = new[]
            {
                new {Text = "واریز", Value = 1},
                new { Text = "برداشت", Value = 2 }
            };
            comboBoxMahiyat.DataSource = items;
            comboBoxMahiyat.DisplayMember = "Text";
            comboBoxMahiyat.ValueMember = "Value";
            comboBoxPersonall.DataSource = export.GetSemat();
            comboBoxPersonall.DisplayMember = "PersonalName";
            comboBoxPersonall.ValueMember = "sematID";
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            if (TasviehId == 0)
            {
                if (numericUpDownMony.Value == 0)
                {
                    MessageBox.Show("مقادیر را کامل کنید", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    TasviehViewModel tasviehView = new TasviehViewModel();
                    tasviehView.DesCription = textBoxAbout.Text;
                    tasviehView.dateTime = DateTime.Now;
                    tasviehView.SematId = Convert.ToInt32(comboBoxPersonall.SelectedValue);
                    var sematName = semat.GetSemayByID(Convert.ToInt32(comboBoxPersonall.SelectedValue));
                    tasviehView.SematName = sematName.SematName;
                    int Mahiyat = Convert.ToInt32(comboBoxMahiyat.SelectedValue);
                    tasviehView.Mahiyat= Mahiyat;
                    if (Mahiyat == 1)
                    {
                        tasviehView.Money = numericUpDownMony.Value;
                    }
                    else
                    {
                        tasviehView.Money -= numericUpDownMony.Value;
                    }
                    if (Tasvieh.AddTasvieh(tasviehView) == true)
                    {
                        MessageBox.Show("ثبت نام با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("ثبت اطلاعات شکست خورد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            else
            {
                TasviehViewModel tasviehView = new TasviehViewModel();
                var Tasvie = Tasvieh.Get(TasviehId);
                tasviehView.DesCription = textBoxAbout.Text;
                tasviehView.dateTime = DateTime.Now;
                tasviehView.SematId = Tasvie.SematId;
                var sematName = semat.GetSemayByID(Convert.ToInt32(comboBoxPersonall.SelectedValue));
                tasviehView.SematName = sematName.SematName;
                tasviehView.TasvieId = TasviehId;
                int Mahiyat = Convert.ToInt32(comboBoxMahiyat.SelectedValue);
                if (Mahiyat == 1)
                {
                    tasviehView.Money = numericUpDownMony.Value;
                }
                else
                {
                    tasviehView.Money -= numericUpDownMony.Value;
                }
                if (Tasvieh.EditTasvieh(tasviehView) == true)
                {
                    MessageBox.Show("ثبت نام با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("ثبت اطلاعات شکست خورد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
}
