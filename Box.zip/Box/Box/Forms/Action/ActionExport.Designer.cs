﻿namespace Box.Forms.Export
{
    partial class ActionExport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            AmirCalendar.FarsiDate farsiDate5 = new AmirCalendar.FarsiDate();
            AmirCalendar.FarsiDate farsiDate6 = new AmirCalendar.FarsiDate();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ActionExport));
            this.ribbonPage2 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.checkAllTasvieh = new System.Windows.Forms.CheckBox();
            this.checkBoxDate = new System.Windows.Forms.CheckBox();
            this.farsiCalendar2 = new AmirCalendar.FarsiCalendar();
            this.farsiCalendar1 = new AmirCalendar.FarsiCalendar();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxPersonall = new System.Windows.Forms.ComboBox();
            this.simpleButtonShow = new DevExpress.XtraEditors.SimpleButton();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelSumVariz = new System.Windows.Forms.Label();
            this.LableSumBardasht = new System.Windows.Forms.Label();
            this.Tasvieh = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.افزودنتسویهجدیدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ویرایشتسویهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.حذفتسویهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ورودیاکسلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.خروجیاکسلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "ribbonPage2";
            // 
            // checkAllTasvieh
            // 
            this.checkAllTasvieh.AutoSize = true;
            this.checkAllTasvieh.Location = new System.Drawing.Point(23, 12);
            this.checkAllTasvieh.Name = "checkAllTasvieh";
            this.checkAllTasvieh.Size = new System.Drawing.Size(118, 28);
            this.checkAllTasvieh.TabIndex = 0;
            this.checkAllTasvieh.Text = "تسویه شده ها";
            this.checkAllTasvieh.UseVisualStyleBackColor = true;
            // 
            // checkBoxDate
            // 
            this.checkBoxDate.AutoSize = true;
            this.checkBoxDate.Location = new System.Drawing.Point(24, 63);
            this.checkBoxDate.Name = "checkBoxDate";
            this.checkBoxDate.Size = new System.Drawing.Size(173, 28);
            this.checkBoxDate.TabIndex = 1;
            this.checkBoxDate.Text = "جستجو بر اساس تاریخ:";
            this.checkBoxDate.UseVisualStyleBackColor = true;
            this.checkBoxDate.CheckedChanged += new System.EventHandler(this.checkBoxDate_CheckedChanged);
            // 
            // farsiCalendar2
            // 
            this.farsiCalendar2.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.farsiCalendar2.Location = new System.Drawing.Point(618, 67);
            this.farsiCalendar2.Name = "farsiCalendar2";
            this.farsiCalendar2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.farsiCalendar2.Size = new System.Drawing.Size(280, 25);
            this.farsiCalendar2.TabIndex = 11;
            farsiDate5.FarsiSelectedDate = "1405/03/26";
            this.farsiCalendar2.Value = farsiDate5;
            this.farsiCalendar2.Visible = false;
            // 
            // farsiCalendar1
            // 
            this.farsiCalendar1.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.farsiCalendar1.Location = new System.Drawing.Point(268, 66);
            this.farsiCalendar1.Name = "farsiCalendar1";
            this.farsiCalendar1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.farsiCalendar1.Size = new System.Drawing.Size(280, 25);
            this.farsiCalendar1.TabIndex = 12;
            farsiDate6.FarsiSelectedDate = "1405/03/26";
            this.farsiCalendar1.Value = farsiDate6;
            this.farsiCalendar1.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(554, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 24);
            this.label3.TabIndex = 10;
            this.label3.Text = "تا تاریخ:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(203, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 24);
            this.label2.TabIndex = 9;
            this.label2.Text = "از تاریخ:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 24);
            this.label1.TabIndex = 13;
            this.label1.Text = "انتخاب پرسنل:";
            // 
            // comboBoxPersonall
            // 
            this.comboBoxPersonall.FormattingEnabled = true;
            this.comboBoxPersonall.Location = new System.Drawing.Point(130, 118);
            this.comboBoxPersonall.Name = "comboBoxPersonall";
            this.comboBoxPersonall.Size = new System.Drawing.Size(277, 32);
            this.comboBoxPersonall.TabIndex = 14;
            // 
            // simpleButtonShow
            // 
            this.simpleButtonShow.Appearance.Font = new System.Drawing.Font("Vazir", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleButtonShow.Appearance.Options.UseFont = true;
            this.simpleButtonShow.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("simpleButtonShow.ImageOptions.SvgImage")));
            this.simpleButtonShow.Location = new System.Drawing.Point(928, 56);
            this.simpleButtonShow.Name = "simpleButtonShow";
            this.simpleButtonShow.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.simpleButtonShow.Size = new System.Drawing.Size(156, 43);
            this.simpleButtonShow.TabIndex = 15;
            this.simpleButtonShow.Text = "نمایش";
            this.simpleButtonShow.Click += new System.EventHandler(this.simpleButtonShow_Click);
            // 
            // gridControl1
            // 
            this.gridControl1.Location = new System.Drawing.Point(16, 164);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(1068, 542);
            this.gridControl1.TabIndex = 16;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.RowCellDefaultAlignment += new DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventHandler(this.gridView1_RowCellDefaultAlignment);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 735);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 24);
            this.label4.TabIndex = 17;
            this.label4.Text = "جمع واریز:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(283, 735);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 24);
            this.label5.TabIndex = 17;
            this.label5.Text = "جمع برداشت:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(539, 735);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 24);
            this.label7.TabIndex = 17;
            this.label7.Text = "مبلغ تسویه:";
            // 
            // labelSumVariz
            // 
            this.labelSumVariz.AutoSize = true;
            this.labelSumVariz.Location = new System.Drawing.Point(147, 735);
            this.labelSumVariz.Name = "labelSumVariz";
            this.labelSumVariz.Size = new System.Drawing.Size(18, 24);
            this.labelSumVariz.TabIndex = 18;
            this.labelSumVariz.Text = "0";
            // 
            // LableSumBardasht
            // 
            this.LableSumBardasht.AutoSize = true;
            this.LableSumBardasht.Location = new System.Drawing.Point(407, 735);
            this.LableSumBardasht.Name = "LableSumBardasht";
            this.LableSumBardasht.Size = new System.Drawing.Size(18, 24);
            this.LableSumBardasht.TabIndex = 18;
            this.LableSumBardasht.Text = "0";
            // 
            // Tasvieh
            // 
            this.Tasvieh.AutoSize = true;
            this.Tasvieh.Location = new System.Drawing.Point(656, 735);
            this.Tasvieh.Name = "Tasvieh";
            this.Tasvieh.Size = new System.Drawing.Size(18, 24);
            this.Tasvieh.TabIndex = 18;
            this.Tasvieh.Text = "0";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.افزودنتسویهجدیدToolStripMenuItem,
            this.ویرایشتسویهToolStripMenuItem,
            this.حذفتسویهToolStripMenuItem,
            this.ورودیاکسلToolStripMenuItem,
            this.خروجیاکسلToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextMenuStrip1.Size = new System.Drawing.Size(211, 152);
            // 
            // افزودنتسویهجدیدToolStripMenuItem
            // 
            this.افزودنتسویهجدیدToolStripMenuItem.Name = "افزودنتسویهجدیدToolStripMenuItem";
            this.افزودنتسویهجدیدToolStripMenuItem.Size = new System.Drawing.Size(199, 24);
            this.افزودنتسویهجدیدToolStripMenuItem.Text = "افزودن تسویه جدید";
            this.افزودنتسویهجدیدToolStripMenuItem.Click += new System.EventHandler(this.افزودنتسویهجدیدToolStripMenuItem_Click);
            // 
            // ویرایشتسویهToolStripMenuItem
            // 
            this.ویرایشتسویهToolStripMenuItem.Name = "ویرایشتسویهToolStripMenuItem";
            this.ویرایشتسویهToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.ویرایشتسویهToolStripMenuItem.Text = "ویرایش تسویه";
            this.ویرایشتسویهToolStripMenuItem.Click += new System.EventHandler(this.ویرایشتسویهToolStripMenuItem_Click);
            // 
            // حذفتسویهToolStripMenuItem
            // 
            this.حذفتسویهToolStripMenuItem.Name = "حذفتسویهToolStripMenuItem";
            this.حذفتسویهToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.حذفتسویهToolStripMenuItem.Text = "حذف تسویه";
            this.حذفتسویهToolStripMenuItem.Click += new System.EventHandler(this.حذفتسویهToolStripMenuItem_Click);
            // 
            // ورودیاکسلToolStripMenuItem
            // 
            this.ورودیاکسلToolStripMenuItem.Name = "ورودیاکسلToolStripMenuItem";
            this.ورودیاکسلToolStripMenuItem.Size = new System.Drawing.Size(199, 24);
            this.ورودیاکسلToolStripMenuItem.Text = "ورودی اکسل";
            // 
            // خروجیاکسلToolStripMenuItem
            // 
            this.خروجیاکسلToolStripMenuItem.Name = "خروجیاکسلToolStripMenuItem";
            this.خروجیاکسلToolStripMenuItem.Size = new System.Drawing.Size(199, 24);
            this.خروجیاکسلToolStripMenuItem.Text = "خروجی اکسل";
            this.خروجیاکسلToolStripMenuItem.Click += new System.EventHandler(this.خروجیاکسلToolStripMenuItem_Click);
            // 
            // ActionExport
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1096, 799);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.Tasvieh);
            this.Controls.Add(this.LableSumBardasht);
            this.Controls.Add(this.labelSumVariz);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.gridControl1);
            this.Controls.Add(this.simpleButtonShow);
            this.Controls.Add(this.comboBoxPersonall);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.farsiCalendar2);
            this.Controls.Add(this.farsiCalendar1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.checkBoxDate);
            this.Controls.Add(this.checkAllTasvieh);
            this.Font = new System.Drawing.Font("Vazir", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "ActionExport";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "تسویه حساب پرسنل";
            this.Load += new System.EventHandler(this.ActionExport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage2;
        private System.Windows.Forms.CheckBox checkAllTasvieh;
        private System.Windows.Forms.CheckBox checkBoxDate;
        private AmirCalendar.FarsiCalendar farsiCalendar2;
        private AmirCalendar.FarsiCalendar farsiCalendar1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxPersonall;
        private DevExpress.XtraEditors.SimpleButton simpleButtonShow;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelSumVariz;
        private System.Windows.Forms.Label LableSumBardasht;
        private System.Windows.Forms.Label Tasvieh;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem افزودنتسویهجدیدToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ویرایشتسویهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem حذفتسویهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ورودیاکسلToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem خروجیاکسلToolStripMenuItem;
    }
}