﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.Forms.Box;
using DevExpress.XtraGrid;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Hesab
{
    public partial class Hesab_List : DevExpress.XtraEditors.XtraForm
    {
        IHesab hesab;
        int TypeID;
        int HeaderId;
        public Hesab_List(int TypeId, int HeaderId)
        {
            this.HeaderId = HeaderId;
            hesab = new HesabServises();
            this.TypeID = TypeId;
            InitializeComponent();
        }

        private void Hesab_List_Load(object sender, EventArgs e)
        {
            
            decimal Sum = 0;
            refreshBox();
            for (int i = 0; i < gridView1.DataRowCount; i++)
            {
                var value = gridView1.GetRowCellValue(i, "Money");
                Sum += (decimal)value;
            }
            lableSumMoney.Text = Convert.ToString(Sum);
            int rowCount = gridView1.RowCount;
            lableSumdoc.Text = Convert.ToString(rowCount);
            this.Text = "لیست حساب صندوق";
            if (TypeID == 1)
            {
               
            }
            else if (TypeID == 2)
            {
                this.Text = "لیست حساب وام";

            }
            else if (TypeID == 3)
            {
                this.Text = "لیست حساب قسط ";
            }
            NumberFormatInfo nfi = new NumberFormatInfo();
            nfi.NumberGroupSeparator = ".";
            foreach (Control c in this.Controls)
            {
                if (c is Label lbl && long.TryParse(lbl.Text, out long num))
                {
                    lbl.Text = num.ToString("#,0", nfi);
                }
            }
        }
        private void refreshBox()
        {
            gridControl.DataSource = hesab.GetAll(HeaderId, textEdit1.Text?.Trim());
            gridView1.Columns[0].Visible = false;
            gridView1.Columns[1].Caption = "نام پرسنل";
            gridView1.Columns[2].Caption = "سمت"; 
            gridView1.Columns[3].Caption = "مبلغ";
            gridView1.Columns["Money"].DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            gridView1.Columns["Money"].DisplayFormat.FormatString = "n0";
        }

        private void ویرایشToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int HesabIdEdit = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "HesabId"));
            NewHesab new_Box = new NewHesab(HeaderId, HesabIdEdit);
            new_Box.ShowDialog();
        }

        private void حذفToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int HesabIdDelete = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "HesabId"));
            DialogResult dialog = MessageBox.Show("آیا از حذف این کاربر مطمئن هستید؟", "پیغام", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dialog == DialogResult.OK)
            {
                if (hesab.DeleteHesab(HesabIdDelete) == true)
                {
                    MessageBox.Show("کابر با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    refreshBox();
                }
                else
                {
                    MessageBox.Show("اطلاعات  حذف نشد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void افزودنToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewHesab new_Box = new NewHesab(HeaderId, 0);
            new_Box.ShowDialog();
        }

        private void gridView1_RowCellDefaultAlignment(object sender, DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventArgs e)
        {
            e.HorzAlignment = DevExpress.Utils.HorzAlignment.Center;
        }

        private void textEdit1_TextChanged(object sender, EventArgs e)
        {
            gridControl.DataSource = hesab.GetAll(HeaderId, textEdit1.Text?.Trim());
        }

        private void خروجیاکسلToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Excel Files|*.xlsx";
            sfd.Title = "ذخیره فایل اکسل";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string path = sfd.FileName;

                gridView1.ExportToXlsx(path);

                MessageBox.Show("فایل با موفقیت ذخیره شد");
            }
        }
    }
}
