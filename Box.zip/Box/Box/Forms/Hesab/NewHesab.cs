﻿using AmirCalendar;
using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Hesab
{
    public partial class NewHesab : DevExpress.XtraEditors.XtraForm
    {

        IHesab hesabservise;
        int HederId;
        int? HesabIdEdit;
        public NewHesab(int HeaderId, int? HesabIdEdit)
        {
            hesabservise = new HesabServises();
            this.HederId = HeaderId;
            this.HesabIdEdit = HesabIdEdit;
            InitializeComponent();
        }

        private void textEdit1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void NewHesab_Load(object sender, EventArgs e)
        {
            var RES = hesabservise.GetSemat();
            comboBox1.DataSource = RES;
            comboBox1.DisplayMember = "PersonalName";
            comboBox1.ValueMember = "sematID";
            if (HesabIdEdit != 0)
            {
                this.Text = " ویرایش حساب";
                var hesab = hesabservise.GetHsab((int)HesabIdEdit);
                textEdit1.Text = Convert.ToString(hesab.Money);
            }
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(textEdit1.Text))
            {
                MessageBox.Show("اطلاعات را کامل وارد کنید", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (HesabIdEdit == 0)
            {
                HesabViewModel hesab = new HesabViewModel();
                hesab.Money = Convert.ToDecimal((textEdit1.Text));
                hesab.SematId = Convert.ToInt32(comboBox1.SelectedValue);
                hesab.HeaderId = HederId;
                if (hesabservise.AddHesab(hesab) == true)
                {
                    MessageBox.Show("ثبت نام با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("اطلاعات  ثبت نشد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                HesabViewModel hesab = new HesabViewModel();
                hesab.Money = Convert.ToDecimal((textEdit1.Text));
                hesab.SematId = Convert.ToInt32(comboBox1.SelectedValue);
                hesab.HeaderId = HederId;
                hesab.HesabId = (int)HesabIdEdit;
                if (hesabservise.EditHesab(hesab) == true)
                {
                    MessageBox.Show("ویرایش با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("اطلاعات  ثبت نشد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
}
