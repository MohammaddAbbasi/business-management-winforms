﻿namespace Box.Forms.Hesab
{
    partial class Hesab_List
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gridControl = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.textEdit1 = new DevExpress.XtraEditors.TextEdit();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.افزودنToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.حذفToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ویرایشToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.وروداکسلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.خروجیاکسلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lableSumdoc = new System.Windows.Forms.Label();
            this.lableSumMoney = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gridControl
            // 
            this.gridControl.Location = new System.Drawing.Point(8, 79);
            this.gridControl.MainView = this.gridView1;
            this.gridControl.Name = "gridControl";
            this.gridControl.Size = new System.Drawing.Size(766, 288);
            this.gridControl.TabIndex = 0;
            this.gridControl.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.gridControl;
            this.gridView1.Name = "gridView1";
            this.gridView1.RowCellDefaultAlignment += new DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventHandler(this.gridView1_RowCellDefaultAlignment);
            // 
            // textEdit1
            // 
            this.textEdit1.Location = new System.Drawing.Point(66, 16);
            this.textEdit1.Name = "textEdit1";
            this.textEdit1.Size = new System.Drawing.Size(211, 22);
            this.textEdit1.TabIndex = 1;
            this.textEdit1.TextChanged += new System.EventHandler(this.textEdit1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "جستجو:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(325, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 22);
            this.label2.TabIndex = 3;
            this.label2.Text = "تعداد سندهای ثبت شده:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(361, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 22);
            this.label3.TabIndex = 4;
            this.label3.Text = "جمع مبالغ:";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.افزودنToolStripMenuItem,
            this.حذفToolStripMenuItem,
            this.ویرایشToolStripMenuItem,
            this.وروداکسلToolStripMenuItem,
            this.خروجیاکسلToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextMenuStrip1.Size = new System.Drawing.Size(211, 152);
            // 
            // افزودنToolStripMenuItem
            // 
            this.افزودنToolStripMenuItem.Name = "افزودنToolStripMenuItem";
            this.افزودنToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.افزودنToolStripMenuItem.Text = "افزودن حساب";
            this.افزودنToolStripMenuItem.Click += new System.EventHandler(this.افزودنToolStripMenuItem_Click);
            // 
            // حذفToolStripMenuItem
            // 
            this.حذفToolStripMenuItem.Name = "حذفToolStripMenuItem";
            this.حذفToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.حذفToolStripMenuItem.Text = "حذف حساب";
            this.حذفToolStripMenuItem.Click += new System.EventHandler(this.حذفToolStripMenuItem_Click);
            // 
            // ویرایشToolStripMenuItem
            // 
            this.ویرایشToolStripMenuItem.Name = "ویرایشToolStripMenuItem";
            this.ویرایشToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.ویرایشToolStripMenuItem.Text = "ویرایش حساب";
            this.ویرایشToolStripMenuItem.Click += new System.EventHandler(this.ویرایشToolStripMenuItem_Click);
            // 
            // وروداکسلToolStripMenuItem
            // 
            this.وروداکسلToolStripMenuItem.Name = "وروداکسلToolStripMenuItem";
            this.وروداکسلToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.وروداکسلToolStripMenuItem.Text = "ورود اکسل";
            // 
            // خروجیاکسلToolStripMenuItem
            // 
            this.خروجیاکسلToolStripMenuItem.Name = "خروجیاکسلToolStripMenuItem";
            this.خروجیاکسلToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.خروجیاکسلToolStripMenuItem.Text = "خروجی اکسل";
            this.خروجیاکسلToolStripMenuItem.Click += new System.EventHandler(this.خروجیاکسلToolStripMenuItem_Click);
            // 
            // lableSumdoc
            // 
            this.lableSumdoc.AutoSize = true;
            this.lableSumdoc.Location = new System.Drawing.Point(603, 9);
            this.lableSumdoc.Name = "lableSumdoc";
            this.lableSumdoc.Size = new System.Drawing.Size(18, 22);
            this.lableSumdoc.TabIndex = 7;
            this.lableSumdoc.Text = "0";
            // 
            // lableSumMoney
            // 
            this.lableSumMoney.AutoSize = true;
            this.lableSumMoney.Location = new System.Drawing.Point(603, 44);
            this.lableSumMoney.Name = "lableSumMoney";
            this.lableSumMoney.Size = new System.Drawing.Size(18, 22);
            this.lableSumMoney.TabIndex = 8;
            this.lableSumMoney.Text = "0";
            // 
            // Hesab_List
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(780, 370);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.lableSumMoney);
            this.Controls.Add(this.lableSumdoc);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textEdit1);
            this.Controls.Add(this.gridControl);
            this.Font = new System.Drawing.Font("Vazir", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Hesab_List";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "لیست حساب";
            this.Load += new System.EventHandler(this.Hesab_List_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraGrid.GridControl gridControl;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraEditors.TextEdit textEdit1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem افزودنToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem حذفToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ویرایشToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem وروداکسلToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem خروجیاکسلToolStripMenuItem;
        private System.Windows.Forms.Label lableSumdoc;
        private System.Windows.Forms.Label lableSumMoney;
    }
}