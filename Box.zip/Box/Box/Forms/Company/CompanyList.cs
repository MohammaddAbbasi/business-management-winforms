﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using DevExpress.Utils.CodedUISupport;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraRichEdit;
using DevExpress.XtraRichEdit.API.Native;
using DevExpress.Utils;
using DevExpress.XtraRichEdit.API.Native;
using DevExpress.Utils;
namespace Box.Forms.Company
{
    public partial class CompanyList : DevExpress.XtraEditors.XtraForm
    {
        ICompany company;

        public CompanyList()
        {
            company = new CompanyServise();
            InitializeComponent();
        }

        private void ListCompany_Load(object sender, EventArgs e)
        {
            refresh();
            


        }

        private void refresh()
        {
            gridControl.DataSource = company.getAll();
            gridView1.Columns[0].Visible = false;
            gridView1.Columns[1].Caption = "نام شرکت";
            gridView1.Columns[2].Caption = "شماره اقتصادی";
            gridView1.Columns[3].Caption = "شماره تلفن";
            gridView1.Columns[4].Caption = "آدرس";
            gridView1.Columns[5].Caption = "نام مدیرعامل";
            gridView1.Columns[6].Visible = false;
        }

        private void افزودنToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Company_Form company_Form = new Company_Form(0);
            company_Form.ShowDialog();
        }

        private void DeleteCompany(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int groupid = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "CompanyId"));
            DialogResult dialog = MessageBox.Show("آیا از حذف این کاربر مطمئن هستید؟", "پیغام", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dialog == DialogResult.OK)
            {
                if (company.DeleteCompany(groupid) == true)
                {
                    MessageBox.Show("کابر با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    refresh();
                }
                else
                {
                    MessageBox.Show("اطلاعات با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void EditCompany(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int groupid = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "CompanyId"));
            Company_Form company_Form = new Company_Form(groupid);
            company_Form.ShowDialog();

        }

        private void gridView1_RowCellDefaultAlignment(object sender, DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventArgs e)
        {
            e.HorzAlignment = DevExpress.Utils.HorzAlignment.Center;
        }

        private void richEditControl1_Click(object sender, EventArgs e)
        {

        }

        private void toggleParagraphAlignmentRightItem1_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
    }
}
