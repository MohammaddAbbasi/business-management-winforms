﻿namespace Box.Forms.Company
{
    partial class Company_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ribbonPage2 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.label1 = new System.Windows.Forms.Label();
            this.textCompanyName = new DevExpress.XtraEditors.TextEdit();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtShomareEqtesadi = new DevExpress.XtraEditors.TextEdit();
            this.txtShomareTelfone = new DevExpress.XtraEditors.TextEdit();
            this.txtAddress = new DevExpress.XtraEditors.TextEdit();
            this.txtModirAmel = new DevExpress.XtraEditors.TextEdit();
            this.BtnSubject = new DevExpress.XtraEditors.SimpleButton();
            this.BtnCancell = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButtonUpload = new DevExpress.XtraEditors.SimpleButton();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.textCompanyName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShomareEqtesadi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShomareTelfone.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddress.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtModirAmel.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "ribbonPage2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(78, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "نام شرکت:";
            // 
            // textCompanyName
            // 
            this.textCompanyName.Location = new System.Drawing.Point(201, 16);
            this.textCompanyName.Margin = new System.Windows.Forms.Padding(4);
            this.textCompanyName.Name = "textCompanyName";
            this.textCompanyName.Size = new System.Drawing.Size(294, 22);
            this.textCompanyName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(100, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 22);
            this.label2.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(66, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 22);
            this.label3.TabIndex = 0;
            this.label3.Text = "شماره اقتصادی:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(85, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 22);
            this.label4.TabIndex = 0;
            this.label4.Text = "شماره تلفن:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(100, 153);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 22);
            this.label5.TabIndex = 0;
            this.label5.Text = "آدرس:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(78, 200);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 22);
            this.label6.TabIndex = 0;
            this.label6.Text = "نام مدیرعامل:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(100, 250);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 22);
            this.label7.TabIndex = 0;
            this.label7.Text = "لوگو:";
            // 
            // txtShomareEqtesadi
            // 
            this.txtShomareEqtesadi.Location = new System.Drawing.Point(201, 68);
            this.txtShomareEqtesadi.Margin = new System.Windows.Forms.Padding(4);
            this.txtShomareEqtesadi.Name = "txtShomareEqtesadi";
            this.txtShomareEqtesadi.Size = new System.Drawing.Size(294, 22);
            this.txtShomareEqtesadi.TabIndex = 2;
            // 
            // txtShomareTelfone
            // 
            this.txtShomareTelfone.Location = new System.Drawing.Point(201, 125);
            this.txtShomareTelfone.Margin = new System.Windows.Forms.Padding(4);
            this.txtShomareTelfone.Name = "txtShomareTelfone";
            this.txtShomareTelfone.Size = new System.Drawing.Size(294, 22);
            this.txtShomareTelfone.TabIndex = 3;
            this.txtShomareTelfone.EditValueChanged += new System.EventHandler(this.txtShomareTelfone_EditValueChanged);
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(201, 189);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(4);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(294, 22);
            this.txtAddress.TabIndex = 4;
            // 
            // txtModirAmel
            // 
            this.txtModirAmel.Location = new System.Drawing.Point(201, 250);
            this.txtModirAmel.Margin = new System.Windows.Forms.Padding(4);
            this.txtModirAmel.Name = "txtModirAmel";
            this.txtModirAmel.Size = new System.Drawing.Size(294, 22);
            this.txtModirAmel.TabIndex = 5;
            // 
            // BtnSubject
            // 
            this.BtnSubject.Location = new System.Drawing.Point(401, 496);
            this.BtnSubject.Margin = new System.Windows.Forms.Padding(4);
            this.BtnSubject.Name = "BtnSubject";
            this.BtnSubject.Size = new System.Drawing.Size(94, 29);
            this.BtnSubject.TabIndex = 8;
            this.BtnSubject.Text = "ثبت";
            this.BtnSubject.Click += new System.EventHandler(this.BtnSubject_Click);
            // 
            // BtnCancell
            // 
            this.BtnCancell.Location = new System.Drawing.Point(201, 496);
            this.BtnCancell.Margin = new System.Windows.Forms.Padding(4);
            this.BtnCancell.Name = "BtnCancell";
            this.BtnCancell.Size = new System.Drawing.Size(94, 29);
            this.BtnCancell.TabIndex = 7;
            this.BtnCancell.Text = "انصراف";
            this.BtnCancell.Click += new System.EventHandler(this.BtnCancell_Click);
            // 
            // simpleButtonUpload
            // 
            this.simpleButtonUpload.Location = new System.Drawing.Point(201, 434);
            this.simpleButtonUpload.Margin = new System.Windows.Forms.Padding(4);
            this.simpleButtonUpload.Name = "simpleButtonUpload";
            this.simpleButtonUpload.Size = new System.Drawing.Size(294, 26);
            this.simpleButtonUpload.TabIndex = 6;
            this.simpleButtonUpload.Text = "آپلود عکس";
            this.simpleButtonUpload.Click += new System.EventHandler(this.simpleButtonUpload_Click);
            // 
            // pictureBox
            // 
            this.pictureBox.Location = new System.Drawing.Point(201, 292);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(294, 113);
            this.pictureBox.TabIndex = 11;
            this.pictureBox.TabStop = false;
            // 
            // Company_Form
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(525, 561);
            this.Controls.Add(this.pictureBox);
            this.Controls.Add(this.simpleButtonUpload);
            this.Controls.Add(this.BtnCancell);
            this.Controls.Add(this.BtnSubject);
            this.Controls.Add(this.txtModirAmel);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtShomareTelfone);
            this.Controls.Add(this.txtShomareEqtesadi);
            this.Controls.Add(this.textCompanyName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Vazir", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Company_Form";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ثبت شرکت";
            this.Load += new System.EventHandler(this.Company_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.textCompanyName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShomareEqtesadi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShomareTelfone.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddress.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtModirAmel.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage2;
        private System.Windows.Forms.Label label1;
        private DevExpress.XtraEditors.TextEdit textCompanyName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private DevExpress.XtraEditors.TextEdit txtShomareEqtesadi;
        private DevExpress.XtraEditors.TextEdit txtShomareTelfone;
        private DevExpress.XtraEditors.TextEdit txtAddress;
        private DevExpress.XtraEditors.TextEdit txtModirAmel;
        private DevExpress.XtraEditors.SimpleButton BtnSubject;
        private DevExpress.XtraEditors.SimpleButton BtnCancell;
        private DevExpress.XtraEditors.SimpleButton simpleButtonUpload;
        private System.Windows.Forms.PictureBox pictureBox;
    }
}