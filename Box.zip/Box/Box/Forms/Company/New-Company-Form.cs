﻿using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static DevExpress.Skins.SolidColorHelper;

namespace Box.Forms.Company
{
    public partial class Company_Form : DevExpress.XtraEditors.XtraForm
    {
        int companyid;
        ICompany icompany;
        private string imagePath = "";
        private string Real_Image_Name = "";
        public Company_Form(int CompanyId)
        {
            InitializeComponent();
            this.companyid = CompanyId;
            icompany = new CompanyServise();
        }

        private void BtnCancell_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Company_Form_Load(object sender, EventArgs e)
        {
            if (companyid != 0)
            {
                this.Text = "ویرایش";
                BtnSubject.Text = "ویرایش";
                var user = icompany.GetCompanyById(companyid);
                txtAddress.Text = user.Address;
                textCompanyName.Text = user.Name_Modir;
                txtModirAmel.Text = user.Name_Modir;
                txtShomareEqtesadi.Text = user.Sh_Eqtesadi;
                txtShomareTelfone.Text = user.Shomare_Telofon;
                pictureBox.Image = Image.FromFile(Path.Combine(Environment.CurrentDirectory, "Pictures", user.Logo));

            }
        }

        private void BtnSubject_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textCompanyName.Text) || string.IsNullOrWhiteSpace(txtAddress.Text) || string.IsNullOrWhiteSpace(txtShomareEqtesadi.Text) || string.IsNullOrWhiteSpace(txtShomareTelfone.Text) || string.IsNullOrEmpty(txtModirAmel.Text) || (pictureBox.Image == null))
            {
                MessageBox.Show("اطلاعات را کامل وارد کنید", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (companyid == 0)
            {
                CompanyViewModel companyViewModel = new CompanyViewModel();

                companyViewModel.CompanyName = textCompanyName.Text;
                companyViewModel.Addrs = txtAddress.Text;
                companyViewModel.ShomareTelefon = txtShomareTelfone.Text;
                companyViewModel.ShomareEqtesadi = txtShomareEqtesadi.Text;
                companyViewModel.ModirAmel = txtModirAmel.Text;

                string folder = Path.Combine(Environment.CurrentDirectory, "Pictures");

                if (!Directory.Exists(folder))
                    Directory.CreateDirectory(folder);

                // اگر عکس انتخاب نشده بود
                if (pictureBox.Image == null || string.IsNullOrEmpty(imagePath))
                {
                    companyViewModel.Pictrue = "Screenshot2026-05-30144337.png";
                }
                else
                {
                    string fullPath = Path.Combine(folder, imagePath);

                    using (Bitmap bmp = new Bitmap(pictureBox.Image))
                    {
                        if (File.Exists(fullPath))
                            File.Delete(fullPath);

                        bmp.Save(fullPath, System.Drawing.Imaging.ImageFormat.Png);
                    }

                    companyViewModel.Pictrue = imagePath;
                }

                if (icompany.AddCompany(companyViewModel))
                {
                    MessageBox.Show("ثبت نام با موفقیت انجام شد", "پیغام",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.Close();
                }
                else
                {
                    MessageBox.Show("اطلاعات ثبت نشد", "پیغام",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                CompanyViewModel companyViewModel = new CompanyViewModel();

                companyViewModel.Id = companyid;
                companyViewModel.CompanyName = textCompanyName.Text;
                companyViewModel.Addrs = txtAddress.Text;
                companyViewModel.ShomareTelefon = txtShomareTelfone.Text;
                companyViewModel.ShomareEqtesadi = txtShomareEqtesadi.Text;
                companyViewModel.ModirAmel = txtModirAmel.Text;

                string folder = Path.Combine(Environment.CurrentDirectory, "Pictures");

                if (!Directory.Exists(folder))
                    Directory.CreateDirectory(folder);

                if (pictureBox.Image != null && !string.IsNullOrEmpty(imagePath))
                {
                    string fullPath = Path.Combine(folder, imagePath);

                    using (Bitmap bmp = new Bitmap(pictureBox.Image))
                    {
                        if (File.Exists(fullPath))
                            File.Delete(fullPath);

                        bmp.Save(fullPath, System.Drawing.Imaging.ImageFormat.Png);
                    }

                    companyViewModel.Pictrue = imagePath;
                }

                if (icompany.EditCompany(companyViewModel))
                {
                    MessageBox.Show("ویرایش با موفقیت انجام شد", "پیغام",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.Close();
                }
                else
                {
                    MessageBox.Show("اطلاعات ثبت نشد", "پیغام",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void simpleButtonUpload_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    pictureBox.BackgroundImage = null;
                    pictureBox.Image = Image.FromFile(openFileDialog.FileName);
                    Real_Image_Name = openFileDialog.SafeFileName;
                    string j = GeneratorUniqCode();
                    string extesion = Path.GetExtension(openFileDialog.FileName);
                    imagePath = j + extesion;
                }
            }
            catch (Exception)
            {
                throw;
            }

        }

        private string GeneratorUniqCode()
        {
            return Guid.NewGuid().ToString().Replace("_", "");
        }

        private void txtShomareTelfone_EditValueChanged(object sender, EventArgs e)
        {

        }
    }
}
