﻿using Box.DTOs;
using Box.DTOs.IServise;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Box.Forms.Employee_form
{
    public partial class Employee_lIST : DevExpress.XtraEditors.XtraForm
    {
        IEmployee employee;
        public Employee_lIST()
        {
            employee = new EmployeeServise();
            InitializeComponent();
        }

        private void Employee_lIST_Load(object sender, EventArgs e)
        {
            refresh();
            gridControl.ContextMenuStrip = contextMenuStrip1;
        }

        private void refresh()
        {
            gridControl.DataSource = employee.GetAll();
            dataTransfer();

            gridView1.Columns[0].Visible = false;
            gridView1.Columns[4].Visible = false;
            gridView1.Columns[5].Visible = false;
            gridView1.Columns[7].Visible = false;
            gridView1.Columns[8].Visible = false;
            gridView1.Columns[9].Visible = false;
            gridView1.Columns[1].Caption = "شماره پرسنلی";
            gridView1.Columns[2].Caption = "نام";
            gridView1.Columns[3].Caption = "نام شرکت";
            gridView1.Columns[6].Caption = "تاریخ استخدام";


        }
        private void dataTransfer()
        {
            if (gridView1.DataRowCount > 0)
            {
                for (int i = 0; i < gridView1.DataRowCount; i++)
                {
                    object SellectValue = gridView1.GetRowCellValue(i, "Estekhdam_Date");
                    DateTime dateTime = Convert.ToDateTime(SellectValue);
                    PersianCalendar persian = new PersianCalendar();
                    string persianDate = persian.GetYear(dateTime) + "/" + persian.GetMonth(dateTime) + "/" + persian.GetDayOfMonth(dateTime);
                    gridView1.SetRowCellValue(i, "dateTimetostring", persianDate);

                }
            }
        }

        private void افزودنToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewEmployee_Form newEmployee_Form = new NewEmployee_Form(0);
            newEmployee_Form.ShowDialog();
        }

        private void ویرایشToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int id = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "Id"));
            NewEmployee_Form newEmployee_Form = new NewEmployee_Form(id);
            newEmployee_Form.ShowDialog();

        }

        private void حذفToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int indexer = gridView1.FocusedRowHandle;
            int id = Convert.ToInt32(gridView1.GetRowCellValue(indexer, "Id"));
            DialogResult dialog = MessageBox.Show("آیا از حذف این کاربر مطمئن هستید؟", "پیغام", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dialog == DialogResult.OK)
            {
                if (employee.DeletePerson(id) == true)
                {
                    MessageBox.Show("کابر با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    refresh();
                }
                else
                {
                    MessageBox.Show("اطلاعات با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void gridView1_RowCellDefaultAlignment(object sender, DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventArgs e)
        {
            e.HorzAlignment = DevExpress.Utils.HorzAlignment.Center;
        }
    }
}
