﻿using Box.DTOs;
using Box.DTOs.IServise;
using Box.DTOs.Servise;
using Box.DTOs.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static DevExpress.XtraEditors.Mask.MaskSettings;

namespace Box.Forms.Employee_form
{

    public partial class NewEmployee_Form : DevExpress.XtraBars.ToolbarForm.ToolbarForm
    {
        IEmployee employee;
        ISemat semat;
        int PersonalId;
        public NewEmployee_Form(int personalId)
        {
            semat = new SematServise();
            employee = new EmployeeServise();
            this.PersonalId = personalId;
            InitializeComponent();
        }

        private void NewEmployee_Form_Load(object sender, EventArgs e)
        {

            var res = employee.GetcompanyById().ToList();
            var result = semat.GetVahed().ToList();
            if (PersonalId != 0)
            {

                var Employee = employee.GetUserById(PersonalId);
                this.Text = "ویرایش";
                txtName.Text = Employee.Name;
                txtSh_Personal.Enabled = false;
                txtSh_Personal.Text = Employee.Sh_Personal;
                txtPassword.Text = Employee.Password;
                txtUserName.Text = Employee.Username;
                comboBox1.DataSource = res;
                comboBox1.DisplayMember = "CompanyName";
                comboBox1.ValueMember = "Id";
                comboBox1.SelectedValue = Employee.CompanyId;
                comboBox2.DataSource = result;
                comboBox2.ValueMember = "VahedId";
                comboBox2.DisplayMember = "VahedTitle";

            }
            else
            {
                comboBox1.DataSource = res;
                comboBox1.DisplayMember = "CompanyName";
                comboBox1.ValueMember = "Id";
                comboBox2.DataSource = result;
                comboBox2.ValueMember = "VahedId";
                comboBox2.DisplayMember = "VahedTitle";
            }
        }

        private void simpleButtonCancell_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void simpleButtonSubject_Click(object sender, EventArgs e)
        {
            if (PersonalId == 0)
            {
                if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtSh_Personal.Text) || string.IsNullOrWhiteSpace(txtUserName.Text) || string.IsNullOrWhiteSpace(txtUserName.Text))
                {
                    MessageBox.Show("اطلاعات را کامل وارد کنید", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    var Employee = new EmployeeViewModel();
                    Employee.FullName = txtName.Text;
                    Employee.PersonalNumber = txtSh_Personal.Text;
                    Employee.Estekhdam_Date = farsiCalendar1.Value.GregorianSelectedDate;
                    Employee.IdCompany = Convert.ToInt32(comboBox1.SelectedValue);
                    Employee.VahedId = Convert.ToInt32(comboBox2.SelectedValue);
                    Employee.Usernamee = txtUserName.Text;
                    Employee.Password = txtPassword.Text;
                    if (employee.AddPerson(Employee) == true)
                    {
                        MessageBox.Show("ثبت نام با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("اطلاعات  ثبت نشد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
            }
            else
            {
                EmployeeViewModel Employee = new EmployeeViewModel();
                Employee.FullName = txtName.Text;
                Employee.IdCompany = Convert.ToInt32(comboBox1.SelectedValue);
                Employee.Id = PersonalId;
                Employee.Usernamee = txtUserName.Text;
                Employee.Password = txtPassword.Text;
                Employee.VahedId = Convert.ToInt32(comboBox2.SelectedValue);
                Employee.Estekhdam_Date = farsiCalendar1.Value.GregorianSelectedDate;
                if (employee.EditPerson(Employee) == true)
                {
                    MessageBox.Show("ویرایش با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("اطلاعات  ثبت نشد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) &&
        !char.IsLetterOrDigit(e.KeyChar))
            {
                e.Handled = true;
            }

            // جلوگیری از حروف غیرانگلیسی
            if (e.KeyChar > 127)
            {
                e.Handled = true;
            }
        }
    }
}