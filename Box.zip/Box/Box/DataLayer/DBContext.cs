﻿using DevExpress.ClipboardSource.SpreadsheetML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static DevExpress.XtraEditors.Mask.MaskSettings;

namespace Box.DataLayer
{
    public class DBContext
    {
        public static string ConectionString = " Data Source=Mohammad\\MOHAMMAD;Initial Catalog = bx; User ID = sa; Password=Mohammad45;Integrated Security = False;";
    }
}
