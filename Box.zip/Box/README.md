\# Business Management Desktop Application



A desktop business management application developed with C# and Windows Forms. The application uses SQL Server for data storage and provides screens for managing company records, personnel, account-related records, documents, and reports.



\## Technologies

\- C#

\- .NET Framework 4.7.2

\- Windows Forms

\- SQL Server

\- LINQ to SQL

\- DevExpress WinForms



\## Project Structure

\- Forms: User interface

\- Interfaces and Services: Application operations and business logic

\- ViewModels: Data used between application layers

\- DataLayer: Database mapping and data access



\## Notes

This project requires the appropriate development environment and licensed third-party dependencies. Database connection settings must be configured locally before running the application.

